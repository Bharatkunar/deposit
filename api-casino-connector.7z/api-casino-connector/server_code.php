<?php
header('Content-Type: application/json');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Log the URL hit at the very beginning
$access_time = date("Y-m-d H:i:s");
$client_ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
$request_uri = $_SERVER['REQUEST_URI'] ?? 'Unknown';
$request_method = $_SERVER['REQUEST_METHOD'] ?? 'Unknown';

// Capture request data
$json_data = file_get_contents('php://input');
$data = $json_data ?: json_encode($_REQUEST, true); // Prefer JSON input, fallback to request data

// Decode data
$decoded_data = json_decode($data, true) ?? [];
if (!$decoded_data) {
    parse_str($data, $decoded_data);
}

// Validate data decoding
if (!is_array($decoded_data)) {
    $log_data = "Access Time: $access_time, IP: $client_ip, Invalid data format: $data\n";
    file_put_contents("access_log.txt", $log_data, FILE_APPEND);
    die(json_encode(["error" => "Invalid data format."]));
}

// Database connection settings
$servername = "localhost";
$username = "u802361505_abmkoders";
$password = "U802361505_abmkoders";
$dbname = "u802361505_abmkoders";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Log request data
$log_data = "Access Time: $access_time, IP: $client_ip, Request Method: $request_method, Data: " . json_encode($decoded_data) . "\n";
file_put_contents("access_log.txt", $log_data, FILE_APPEND);

// Insert data into database
$sql = "INSERT INTO captured_data (request_method, request_data) VALUES (?, ?)";
$stmt = $conn->prepare($sql);

if ($stmt && $stmt->bind_param("ss", $request_method, $data) && $stmt->execute()) {
    $stmt->close();
} else {
    $log_data = "Database insert failed: " . ($stmt ? $stmt->error : $conn->error) . "\n";
    file_put_contents("access_log.txt", $log_data, FILE_APPEND);
}

// Extract 'player_id' and handle attributes
$player_id = $decoded_data['player_id'] ?? null;

if ($player_id) {
    $underscore_pos = explode('_', $player_id);
    $player_id = $underscore_pos[0];
    $ip = $underscore_pos[1] ?? null;

    if ($ip) {
        $ip = mysqli_real_escape_string($conn, $ip);

        $getServer = "SELECT callback_url FROM vendors WHERE ip_address = '$ip'";
        $log_data = "Access Time: $access_time, IP: $client_ip, Query: $getServer\n";
        file_put_contents("access_log.txt", $log_data, FILE_APPEND);

        $getQuery = mysqli_query($conn, $getServer);
        $row = mysqli_fetch_assoc($getQuery);

        if ($row && isset($row['callback_url'])) {
            $decoded_data['player_id'] = $player_id;
            $url = $row['callback_url'] . "?" . http_build_query($decoded_data);

            $log_data = "Access Time: $access_time, Callback URL: $url\n";
            file_put_contents("access_log.txt", $log_data, FILE_APPEND);

            // Send request to callback URL
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);

            if (curl_errno($ch)) {
                $log_data = "Curl error: " . curl_error($ch) . "\n";
                file_put_contents("access_log.txt", $log_data, FILE_APPEND);
                echo json_encode(["error" => "Curl error: " . curl_error($ch)]);
            } else {
                $response_data = json_decode($response, true);
                $log_data = "Callback Response: $response\n";
                file_put_contents("access_log.txt", $log_data, FILE_APPEND);
                echo json_encode($response_data);
            }

            curl_close($ch);
        } else {
            $log_data = "No callback URL found for IP: $ip\n";
            file_put_contents("access_log.txt", $log_data, FILE_APPEND);
            echo json_encode(["error" => "No callback URL found for IP: $ip"]);
        }
    } else {
        echo json_encode(["error" => "Invalid player_id format."]);
    }
} else {
    echo json_encode(["error" => "Missing player_id."]);
}

// Close database connection
$conn->close();
?>

<style>
    .page-id-6296 {
        font-family: Montserrat, Arial, Helvetica, sans-serif !important;
    }

    /*.page-id-6296 .fusion-builder-row.fusion-row.fusion-flex-align-items-stretch {
    display: none !important;
}*/
    .page-id-6296 #main .fusion-row {
        max-width: unset !important;
        margin-left: 20px;
        margin-right: 20px;
    }

    .page-id-6296 main#main {
        padding-left: 0px !important;
        padding-right: 0px !important;
    }

    .page-id-6296 #main .fusion-row .fusion-builder-row {
        margin-left: 0px !important;
        margin-right: 0px !important;
    }

    .page-id-6296 #main .fusion-row .fusion-layout-column {
        position: unset !important
    }

    .page-id-6296 #main .fusion-row .fusion-column-wrapper {
        margin: 0px !important;
    }

    .transaction-history-white-block {
        background-color: white;
        max-width: 1200px;
        margin: auto;
        padding: 20px;
        margin-top: 10px;
    }

    .transaction-history-white-button-block {
        max-width: 96% !important;
        width: 100% !important
    }

    .transaction-history-white-button-block .fusion-builder-row.fusion-builder-row-inner.fusion-row.fusion-flex-align-items-flex-start {
        display: block !important;
    }

    .transaction-history-white-button-block .fusion-column-wrapper.fusion-column-has-shadow.fusion-flex-justify-content-flex-start.fusion-content-layout-column {
        display: flex;
        flex-direction: row !important;
        justify-content: space-between;
    }

    .history-left-bar-content .showing-filter span.text-format {
        font-size: 14px !important;
        padding-left: 10px;
        e padding-right: 10px;
        color: #666;
    }

    .history-left-bar-content .showing-filter select {
        height: 30px !important;
        background-color: #f8f8f8 !important;
        color: #666;
        border: 1px solid #ccc;
        border-radius: 5px;
        width: 100px;
    }

    .history-right-bar-content input {
        height: 30px !important;
        background-color: #f8f8f8 !important;
        color: #666;
        border: 1px solid #ccc !important;
        border-radius: 5px !important;
        width: 100px;
    }


    .history-right-bar-content {
        display: flex;
        gap: 10px;
    }

    .history-right-bar-content:before {
        content: "Search";
        font-size: 14px !important;
        color: #666;
    }

    .history-right-bar-content .search-button {
        display: none;
    }

    .heading-transaction-history td span {
        color: rgb(102, 102, 102);
    }

    .transaction-history-table-column span.icon-sorting {
        display: flex;
        justify-content: right;
        margin-top: -30px;
    }

    .transaction-history-table-column span.icon-sorting span {
        position: relative;
    }

    .transaction-history-table-column span.icon-sorting span.exchange-icon {
        color: white;
    }

    .transaction-history-table-column span.icon-sorting span.exchange-icon:before {
        color: rgb(102, 102, 102);
        content: "\f0ec";
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        font-size: 14px;
        right: 0px;
        position: absolute;
        transform: rotate(90deg);
    }

    .transaction-history-table-column span.icon-sorting span.down-sort-icon {
        color: white;
    }

    .transaction-history-table-column span.icon-sorting span.down-sort-icon:before {
        color: rgb(102, 102, 102);
        content: "\f161";
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        font-size: 14px;
        right: 0px;
        position: absolute;
        transform: rotate(180deg) scaleX(-1);
    }

    .transaction-history-table-column span.icon-sorting span.up-sort-icon {
        color: white;
    }

    .transaction-history-table-column span.icon-sorting span.up-sort-icon:before {
        color: rgb(102, 102, 102);
        content: "\f161";
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        font-size: 14px;
        right: 0px;
        position: absolute;
        transform: rotate(0deg);
    }

    .transaction-history-table-column tr td {
        border-color: white !important;
        border-bottom: 1px solid lightgrey !important;
        padding: 5px !important;
        padding-left: 8px !important;
        padding-right: 8px !important;
    }

    .transaction-history-table-column span.icon-sorting .exchange-icon {
        display: none
    }

    .transaction-history-table-column span.icon-sorting .down-sort-icon {
        display: none;
    }

    .transaction-history-table-column span.icon-sorting .up-sort-icon {
        display: none
    }

    .transaction-history-table-column span.icon-sorting .exchange-icon.active {
        display: block
    }

    .transaction-history-table-column span.icon-sorting .down-sort-icon.active {
        display: block;
    }

    .transaction-history-table-column span.icon-sorting .up-sort-icon.active {
        display: block
    }

    .transaction-history-table-column span.icon-sorting {
        height: 30px;
    }

    .transaction-history-table-column tbody tr:nth-child(odd) {
        background-color: #f9f9f9
    }

    .transaction-history-table-column tbody tr:nth-child(even) {
        background-color: #fff
    }

    .transaction-history-white-pagination-block {
        margin-top: 10px !important;
    }

    .transaction-history-white-pagination-block .fusion-column-wrapper.fusion-column-has-shadow.fusion-flex-justify-content-flex-start.fusion-content-layout-column {
        flex-direction: row !important;
        justify-content: space-between;
        width: 96%;
    }

    .transaction-history-white-pagination-block .history-right-bar-content:before {
        display: none;
    }

    .showing-filter-padination input {
        color: rgba(238, 96, 89) !important;
        width: max-content !important;
        padding-left: 10px;
        padding-right: 10px;
    }

    .showing-filter-padination input.page-numbers {
        background-color: rgba(238, 96, 89) !important;
        border: none !important;
        border-radius: 0px !important;
        color: white !important;
        width: 30px;
    }

    .transaction-history-table-column td.plus-content {
        font-size: 20px !important;
        font-weight: 700;
        height: 14px !important;
        padding: 0px !important;
    }

    .transaction-history-table-column td.status-content {
        color: #337ab7 !important;
    }

    .transaction-history-table-column td.points-content {
        color: green !important
    }

    @media(max-width:767px) {
        .transaction-history-table-column .table-content {
            padding-right: 20px;
        }
    }

    .history-right-bar-content .showing-filter-padination input {
        border-radius: 0px !important;
    }

    input.custom-search-input {
        font-size: 16px;
        line-height: 1.5;
        border: 1px solid #ccc;
        border-radius: 4px;
        background-color: #fff;
        color: #333;
        box-sizing: border-box;
        outline: none;
        transition: border-color 0.3s ease-in-out;
    }

    input.custom-search-input:focus {
        border-color: #0073e6;
        /* Fusion focus color */
        box-shadow: 0 0 0 1px #0073e6;
    }

    .search-wrapper {
        display: flex;
        align-items: center;
        gap: 10px;
        /* Space between label and input */
    }

    .search-label {
        font-size: 16px;
        color: #333;
        white-space: nowrap;
    }

    .custom-search-input {
        flex: 1;
        /* Input takes remaining space */
        padding: 10px 12px;
        font-size: 16px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
</style>
<?php
echo do_shortcode('
[fusion_builder_container type="flex" hundred_percent="no" hundred_percent_height="no" min_height_medium="" min_height_small="" min_height="" hundred_percent_height_scroll="no" align_content="stretch" flex_align_items="flex-start" flex_justify_content="flex-start" flex_column_spacing="" hundred_percent_height_center_content="yes" equal_height_columns="no" container_tag="div" menu_anchor="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" status="published" publish_date="" class="survey-head both-pd-sp1" id="" margin_top_medium="" margin_bottom_medium="" margin_top_small="" margin_bottom_small="" margin_top="" margin_bottom="" padding_top_medium="" padding_right_medium="" padding_bottom_medium="" padding_left_medium="" padding_top_small="" padding_right_small="" padding_bottom_small="" padding_left_small="" padding_top="" padding_right="" padding_bottom="" padding_left="" link_color="" hue="" saturation="" lightness="" alpha="" link_hover_color="" border_sizes_top="" border_sizes_right="" border_sizes_bottom="" border_sizes_left="" border_color="" border_style="solid" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" box_shadow="no" box_shadow_vertical="" box_shadow_horizontal="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index="" overflow="" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" skip_lazy_load="" background_position="center center" background_repeat="no-repeat" fade="no" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_blend_mode="none" video_mp4="" video_webm="" video_ogv="" video_url="" video_aspect_ratio="16:9" video_loop="yes" video_mute="yes" video_preview_image="" pattern_bg="none" pattern_custom_bg="" pattern_bg_color="" pattern_bg_style="default" pattern_bg_opacity="100" pattern_bg_size="" pattern_bg_blend_mode="normal" mask_bg="none" mask_custom_bg="" mask_bg_color="" mask_bg_accent_color="" mask_bg_style="default" mask_bg_opacity="100" mask_bg_transform="left" mask_bg_blend_mode="normal" render_logics="" absolute="off" absolute_devices="small,medium,large" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_background_color="" sticky_height="" sticky_offset="" sticky_transition_offset="0" scroll_offset="0" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" align_self="auto" content_layout="column" align_content="flex-start" valign_content="flex-start" content_wrap="wrap" spacing="" center_content="no" column_tag="div" link="" target="_self" link_description="" min_height="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="" id="" type_medium="" type_small="" order_medium="0" order_small="0" dimension_spacing_medium="" dimension_spacing_small="" dimension_spacing="" dimension_margin_medium="" dimension_margin_small="" margin_top="" margin_bottom="" padding_medium="" padding_small="" padding_top="" padding_right="" padding_bottom="" padding_left="" hover_type="none" border_sizes="" border_color="" border_style="solid" border_radius="" box_shadow="no" dimension_box_shadow="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index_subgroup="regular" z_index="" z_index_hover="" overflow="" background_type="single" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" background_image_id="" lazy_load="avada" skip_lazy_load="" background_position="left top" background_repeat="no-repeat" background_blend_mode="none" render_logics="" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_offset="" absolute="off" absolute_props="" filter_type="regular" filter_hover_element="self" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0" transform_type="regular" transform_hover_element="self" transform_scale_x="1" transform_scale_y="1" transform_translate_x="0" transform_translate_y="0" transform_rotate="0" transform_skew_x="0" transform_skew_y="0" transform_scale_x_hover="1" transform_scale_y_hover="1" transform_translate_x_hover="0" transform_translate_y_hover="0" transform_rotate_hover="0" transform_skew_x_hover="0" transform_skew_y_hover="0" transform_origin="" transition_duration="300" transition_easing="ease" transition_custom_easing="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" last="true" border_position="all" first="true"][fusion_builder_row_inner][fusion_builder_column_inner type="1_1" layout="1_1" align_self="auto" content_layout="column" align_content="flex-start" valign_content="flex-start" content_wrap="wrap" spacing="" center_content="no" column_tag="div" link="" target="_self" link_description="" min_height="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="" id="" type_medium="" type_small="" order_medium="0" order_small="0" dimension_spacing_medium="" dimension_spacing_small="" dimension_spacing="" dimension_margin_medium="" dimension_margin_small="" dimension_margin="" padding_medium="" padding_small="" padding_top="" padding_right="" padding_bottom="" padding_left="" hover_type="none" border_sizes="" border_color="" border_style="solid" border_radius="" box_shadow="no" dimension_box_shadow="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index_subgroup="regular" z_index="" z_index_hover="" overflow="" background_type="single" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" background_image_id="" lazy_load="avada" skip_lazy_load="" background_position="left top" background_repeat="no-repeat" background_blend_mode="none" render_logics="" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_offset="" absolute="off" absolute_props="" filter_type="regular" filter_hover_element="self" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0" transform_type="regular" transform_hover_element="self" transform_scale_x="1" transform_scale_y="1" transform_translate_x="0" transform_translate_y="0" transform_rotate="0" transform_skew_x="0" transform_skew_y="0" transform_scale_x_hover="1" transform_scale_y_hover="1" transform_translate_x_hover="0" transform_translate_y_hover="0" transform_rotate_hover="0" transform_skew_x_hover="0" transform_skew_y_hover="0" transform_origin="" transition_duration="300" transition_easing="ease" transition_custom_easing="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" last="true" border_position="all" element_content="" first="true"][fusion_button link="#" title="" target="_self" link_attributes="" alignment_medium="" alignment_small="" alignment="" modal="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="user-minus-icon" id="" color="default" button_gradient_top_color="" hue="" saturation="" lightness="" alpha="" button_gradient_bottom_color="" button_gradient_top_color_hover="" button_gradient_bottom_color_hover="" gradient_start_position="" gradient_end_position="" gradient_type="" radial_direction="" linear_angle="180" accent_color="" accent_hover_color="" type="" bevel_color="" bevel_color_hover="" border_top="" border_right="" border_bottom="" border_left="" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" border_color="" border_hover_color="" size="" padding_top="" padding_right="" padding_bottom="" padding_left="" fusion_font_family_button_font="" fusion_font_variant_button_font="" font_size="" line_height="" letter_spacing="" text_transform="" stretch="default" margin_top="" margin_right="" margin_bottom="" margin_left="" icon="" icon_position="left" icon_divider="no" hover_transition="none" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]Profile[/fusion_button][fusion_button link="#" title="" target="_self" link_attributes="" alignment_medium="" alignment_small="" alignment="" modal="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="user-minus-icon" id="" color="default" button_gradient_top_color="" hue="" saturation="" lightness="" alpha="" button_gradient_bottom_color="" button_gradient_top_color_hover="" button_gradient_bottom_color_hover="" gradient_start_position="" gradient_end_position="" gradient_type="" radial_direction="" linear_angle="180" accent_color="" accent_hover_color="" type="" bevel_color="" bevel_color_hover="" border_top="" border_right="" border_bottom="" border_left="" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" border_color="" border_hover_color="" size="" padding_top="" padding_right="" padding_bottom="" padding_left="" fusion_font_family_button_font="" fusion_font_variant_button_font="" font_size="" line_height="" letter_spacing="" text_transform="" stretch="default" margin_top="" margin_right="" margin_bottom="" margin_left="" icon="" icon_position="left" icon_divider="no" hover_transition="none" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]Ways To Earn[/fusion_button][fusion_button link="#" title="" target="_self" link_attributes="" alignment_medium="" alignment_small="" alignment="" modal="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="list-icon" id="" color="default" button_gradient_top_color="" hue="" saturation="" lightness="" alpha="" button_gradient_bottom_color="" button_gradient_top_color_hover="" button_gradient_bottom_color_hover="" gradient_start_position="" gradient_end_position="" gradient_type="" radial_direction="" linear_angle="180" accent_color="" accent_hover_color="" type="" bevel_color="" bevel_color_hover="" border_top="" border_right="" border_bottom="" border_left="" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" border_color="" border_hover_color="" size="" padding_top="" padding_right="" padding_bottom="" padding_left="" fusion_font_family_button_font="" fusion_font_variant_button_font="" font_size="" line_height="" letter_spacing="" text_transform="" stretch="default" margin_top="" margin_right="" margin_bottom="" margin_left="" icon="" icon_position="left" icon_divider="no" hover_transition="none" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]Transaction History[/fusion_button][fusion_button link="#" title="" target="_self" link_attributes="" alignment_medium="" alignment_small="" alignment="" modal="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="shopping-icon" id="" color="default" button_gradient_top_color="" hue="" saturation="" lightness="" alpha="" button_gradient_bottom_color="" button_gradient_top_color_hover="" button_gradient_bottom_color_hover="" gradient_start_position="" gradient_end_position="" gradient_type="" radial_direction="" linear_angle="180" accent_color="" accent_hover_color="" type="" bevel_color="" bevel_color_hover="" border_top="" border_right="" border_bottom="" border_left="" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" border_color="" border_hover_color="" size="" padding_top="" padding_right="" padding_bottom="" padding_left="" fusion_font_family_button_font="" fusion_font_variant_button_font="" font_size="" line_height="" letter_spacing="" text_transform="" stretch="default" margin_top="" margin_right="" margin_bottom="" margin_left="" icon="" icon_position="left" icon_divider="no" hover_transition="none" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]Reward Point Goals[/fusion_button][fusion_button link="#" title="" target="_self" link_attributes="" alignment_medium="" alignment_small="" alignment="" modal="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="lock-icon" id="" color="default" button_gradient_top_color="" hue="" saturation="" lightness="" alpha="" button_gradient_bottom_color="" button_gradient_top_color_hover="" button_gradient_bottom_color_hover="" gradient_start_position="" gradient_end_position="" gradient_type="" radial_direction="" linear_angle="180" accent_color="" accent_hover_color="" type="" bevel_color="" bevel_color_hover="" border_top="" border_right="" border_bottom="" border_left="" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" border_color="" border_hover_color="" size="" padding_top="" padding_right="" padding_bottom="" padding_left="" fusion_font_family_button_font="" fusion_font_variant_button_font="" font_size="" line_height="" letter_spacing="" text_transform="" stretch="default" margin_top="" margin_right="" margin_bottom="" margin_left="" icon="" icon_position="left" icon_divider="no" hover_transition="none" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]Update Profile[/fusion_button][/fusion_builder_column_inner][/fusion_builder_row_inner][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container type="flex" hundred_percent="no" hundred_percent_height="no" min_height_medium="" min_height_small="" min_height="" hundred_percent_height_scroll="no" align_content="stretch" flex_align_items="flex-start" flex_justify_content="flex-start" flex_column_spacing="" hundred_percent_height_center_content="yes" equal_height_columns="no" container_tag="div" menu_anchor="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" status="published" publish_date="" class="heading-box-container both-pd-sp1" id="" margin_top_medium="" margin_bottom_medium="" margin_top_small="" margin_bottom_small="" margin_top="" margin_bottom="" padding_top_medium="" padding_right_medium="" padding_bottom_medium="" padding_left_medium="" padding_top_small="" padding_right_small="" padding_bottom_small="" padding_left_small="" padding_top="" padding_right="" padding_bottom="" padding_left="" link_color="" hue="" saturation="" lightness="" alpha="" link_hover_color="" border_sizes_top="" border_sizes_right="" border_sizes_bottom="" border_sizes_left="" border_color="" border_style="solid" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" box_shadow="no" box_shadow_vertical="" box_shadow_horizontal="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index="" overflow="" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" skip_lazy_load="" background_position="center center" background_repeat="no-repeat" fade="no" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_blend_mode="none" video_mp4="" video_webm="" video_ogv="" video_url="" video_aspect_ratio="16:9" video_loop="yes" video_mute="yes" video_preview_image="" pattern_bg="none" pattern_custom_bg="" pattern_bg_color="" pattern_bg_style="default" pattern_bg_opacity="100" pattern_bg_size="" pattern_bg_blend_mode="normal" mask_bg="none" mask_custom_bg="" mask_bg_color="" mask_bg_accent_color="" mask_bg_style="default" mask_bg_opacity="100" mask_bg_transform="left" mask_bg_blend_mode="normal" render_logics="" absolute="off" absolute_devices="small,medium,large" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_background_color="" sticky_height="" sticky_offset="" sticky_transition_offset="0" scroll_offset="0" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" align_self="auto" content_layout="column" align_content="flex-start" valign_content="flex-start" content_wrap="wrap" spacing="" center_content="no" column_tag="div" link="" target="_self" link_description="" min_height="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="" id="" type_medium="" type_small="" order_medium="0" order_small="0" dimension_spacing_medium="" dimension_spacing_small="" dimension_spacing="" dimension_margin_medium="" dimension_margin_small="" margin_top="" margin_bottom="" padding_medium="" padding_small="" padding_top="" padding_right="" padding_bottom="" padding_left="" hover_type="none" border_sizes="" border_color="" border_style="solid" border_radius="" box_shadow="no" dimension_box_shadow="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index_subgroup="regular" z_index="" z_index_hover="" overflow="" background_type="single" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" background_image_id="" lazy_load="avada" skip_lazy_load="" background_position="left top" background_repeat="no-repeat" background_blend_mode="none" render_logics="" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_offset="" absolute="off" absolute_props="" filter_type="regular" filter_hover_element="self" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0" transform_type="regular" transform_hover_element="self" transform_scale_x="1" transform_scale_y="1" transform_translate_x="0" transform_translate_y="0" transform_rotate="0" transform_skew_x="0" transform_skew_y="0" transform_scale_x_hover="1" transform_scale_y_hover="1" transform_translate_x_hover="0" transform_translate_y_hover="0" transform_rotate_hover="0" transform_skew_x_hover="0" transform_skew_y_hover="0" transform_origin="" transition_duration="300" transition_easing="ease" transition_custom_easing="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" last="true" border_position="all" first="true"][fusion_text columns="" column_min_width="" column_spacing="" rule_style="" rule_size="" rule_color="" hue="" saturation="" lightness="" alpha="" content_alignment_medium="" content_alignment_small="" content_alignment="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="" id="" margin_top="" margin_right="" margin_bottom="" margin_left="" fusion_font_family_text_font="" fusion_font_variant_text_font="" font_size="" line_height="" letter_spacing="" text_transform="" text_color="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]

Transaction History

[/fusion_text][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container type="flex" hundred_percent="no" hundred_percent_height="no" min_height_medium="" min_height_small="" min_height="" hundred_percent_height_scroll="no" align_content="stretch" flex_align_items="flex-start" flex_justify_content="flex-start" flex_column_spacing="" hundred_percent_height_center_content="yes" equal_height_columns="no" container_tag="div" menu_anchor="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" status="published" publish_date="" class="transaction-history-white-block both-pd-sp1" id="" margin_top_medium="" margin_bottom_medium="" margin_top_small="" margin_bottom_small="" margin_top="" margin_bottom="" padding_top_medium="" padding_right_medium="" padding_bottom_medium="" padding_left_medium="" padding_top_small="" padding_right_small="" padding_bottom_small="" padding_left_small="" padding_top="" padding_right="" padding_bottom="" padding_left="" link_color="" hue="" saturation="" lightness="" alpha="" link_hover_color="" border_sizes_top="" border_sizes_right="" border_sizes_bottom="" border_sizes_left="" border_color="" border_style="solid" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" box_shadow="no" box_shadow_vertical="" box_shadow_horizontal="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index="" overflow="" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" skip_lazy_load="" background_position="center center" background_repeat="no-repeat" fade="no" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_blend_mode="none" video_mp4="" video_webm="" video_ogv="" video_url="" video_aspect_ratio="16:9" video_loop="yes" video_mute="yes" video_preview_image="" pattern_bg="none" pattern_custom_bg="" pattern_bg_color="" pattern_bg_style="default" pattern_bg_opacity="100" pattern_bg_size="" pattern_bg_blend_mode="normal" mask_bg="none" mask_custom_bg="" mask_bg_color="" mask_bg_accent_color="" mask_bg_style="default" mask_bg_opacity="100" mask_bg_transform="left" mask_bg_blend_mode="normal" render_logics="" absolute="off" absolute_devices="small,medium,large" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_background_color="" sticky_height="" sticky_offset="" sticky_transition_offset="0" scroll_offset="0" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" align_self="auto" content_layout="column" align_content="flex-start" valign_content="flex-start" content_wrap="wrap" spacing="" center_content="no" column_tag="div" link="" target="_self" link_description="" min_height="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="survey-white-block-inner" id="" background_image_id="" type_medium="" type_small="" order_medium="0" order_small="0" spacing_left_medium="" spacing_right_medium="" spacing_left_small="" spacing_right_small="" spacing_left="" spacing_right="" margin_top_medium="" margin_bottom_medium="" margin_top_small="" margin_bottom_small="" margin_top="" margin_bottom="" padding_top_medium="" padding_right_medium="" padding_bottom_medium="" padding_left_medium="" padding_top_small="" padding_right_small="" padding_bottom_small="" padding_left_small="" padding_top="" padding_right="" padding_bottom="" padding_left="" hover_type="none" border_sizes_top="" border_sizes_right="" border_sizes_bottom="" border_sizes_left="" border_color="" hue="" saturation="" lightness="" alpha="" border_style="solid" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" box_shadow="no" box_shadow_vertical="" box_shadow_horizontal="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index_subgroup="regular" z_index="" z_index_hover="" overflow="" background_type="single" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" lazy_load="avada" skip_lazy_load="" background_position="left top" background_repeat="no-repeat" background_blend_mode="none" render_logics="" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_offset="" absolute="off" absolute_top="" absolute_right="" absolute_bottom="" absolute_left="" filter_type="regular" filter_hover_element="self" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0" transform_type="regular" transform_hover_element="self" transform_scale_x="1" transform_scale_y="1" transform_translate_x="0" transform_translate_y="0" transform_rotate="0" transform_skew_x="0" transform_skew_y="0" transform_origin="" transform_scale_x_hover="1" transform_scale_y_hover="1" transform_translate_x_hover="0" transform_translate_y_hover="0" transform_rotate_hover="0" transform_skew_x_hover="0" transform_skew_y_hover="0" transition_duration="300" transition_easing="ease" transition_custom_easing="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" last="true" border_position="all" first="true"][fusion_builder_row_inner][fusion_builder_column_inner type="1_1" layout="1_1" align_self="auto" content_layout="column" align_content="flex-start" valign_content="flex-start" content_wrap="wrap" spacing="" center_content="no" column_tag="div" link="" target="_self" link_description="" min_height="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="transaction-history-white-button-block" id="" background_image_id="" type_medium="" type_small="" order_medium="0" order_small="0" spacing_left_medium="" spacing_right_medium="" spacing_left_small="" spacing_right_small="" spacing_left="" spacing_right="" margin_top_medium="" margin_bottom_medium="" margin_top_small="" margin_bottom_small="" margin_top="" margin_bottom="" padding_top_medium="" padding_right_medium="" padding_bottom_medium="" padding_left_medium="" padding_top_small="" padding_right_small="" padding_bottom_small="" padding_left_small="" padding_top="" padding_right="" padding_bottom="" padding_left="" hover_type="none" border_sizes_top="" border_sizes_right="" border_sizes_bottom="" border_sizes_left="" border_color="" hue="" saturation="" lightness="" alpha="" border_style="solid" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" box_shadow="no" box_shadow_vertical="" box_shadow_horizontal="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index_subgroup="regular" z_index="" z_index_hover="" overflow="" background_type="single" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" lazy_load="avada" skip_lazy_load="" background_position="left top" background_repeat="no-repeat" background_blend_mode="none" render_logics="" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_offset="" absolute="off" absolute_top="" absolute_right="" absolute_bottom="" absolute_left="" filter_type="regular" filter_hover_element="self" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0" transform_type="regular" transform_hover_element="self" transform_scale_x="1" transform_scale_y="1" transform_translate_x="0" transform_translate_y="0" transform_rotate="0" transform_skew_x="0" transform_skew_y="0" transform_origin="" transform_scale_x_hover="1" transform_scale_y_hover="1" transform_translate_x_hover="0" transform_translate_y_hover="0" transform_rotate_hover="0" transform_skew_x_hover="0" transform_skew_y_hover="0" transition_duration="300" transition_easing="ease" transition_custom_easing="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" last="true" border_position="all" first="true"][fusion_text columns="" column_min_width="" column_spacing="" rule_style="" rule_size="" rule_color="" hue="" saturation="" lightness="" alpha="" content_alignment_medium="" content_alignment_small="" content_alignment="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="history-left-bar-content" id="" margin_top="" margin_right="" margin_bottom="" margin_left="" fusion_font_family_text_font="" fusion_font_variant_text_font="" font_size="" line_height="" letter_spacing="" text_transform="" text_color="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]
<div class="showing-filter">
                <span class="text-format">Show</span>
                <select id="transactionEntriesPerPage">
                    <option>10</option>
                    <option>25</option>
                    <option>50</option>
                    <option>100</option>
                </select>
                <span class="text-format">entries</span>
            </div>
[/fusion_text]<div class="search-wrapper">
  <label for="balanceSearch" class="search-label">Search:</label>
  <input type="search" id="balanceSearch" class="history-right-bar-content custom-search-input" placeholder="Search by balance">
</div>
[/fusion_builder_column_inner][/fusion_builder_row_inner][fusion_table fusion_table_type="1" fusion_table_rows="1" fusion_table_columns="0" margin_top="" margin_right="" margin_bottom="" margin_left="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" class="transaction-history-table-column" id="" animation_type="" animation_direction="left" animation_color="" hue="" saturation="" lightness="" alpha="" animation_speed="0.3" animation_delay="0" animation_offset=""]
<div class="transaction-history-table-div">
<table width="100%">
<thead>
<tr class="heading-transaction-history">
<td class="date-icon"><span class="table-content">Date</span>
<span class="icon-sorting">
<span class="exchange-icon">e</span>
<span class="down-sort-icon">d</span>
<span class="up-sort-icon">u</span>
</span></td>
<td class="type-icon"><span class="table-content">Type</span>
<span class="icon-sorting">
<span class="exchange-icon">e</span>
<span class="down-sort-icon">d</span>
<span class="up-sort-icon">u</span>
</span></td>
<td class="status-icon"><span class="table-content">Status</span>
<span class="icon-sorting">
<span class="exchange-icon">e</span>
<span class="down-sort-icon">d</span>
<span class="up-sort-icon">u</span>
</span></td>
<td class="points-icon"><span class="table-content">Points</span>
<span class="icon-sorting">
<span class="exchange-icon">e</span>
<span class="down-sort-icon">d</span>
<span class="up-sort-icon">u</span>
</span></td>
<td class="balance-icon"><span class="table-content">Balance</span>
<span class="icon-sorting">
<span class="exchange-icon">e</span>
<span class="down-sort-icon">d</span>
<span class="up-sort-icon">u</span>
</span></td>
<td class="plus-icon"></td>
</tr>
</thead>
<tbody id="transactionHistoryBody"></tbody>
</table>
</div>
[/fusion_table][fusion_builder_row_inner][fusion_builder_column_inner type="1_1" layout="1_1" align_self="auto" content_layout="column" align_content="flex-start" valign_content="flex-start" content_wrap="wrap" spacing="" center_content="no" column_tag="div" link="" target="_self" link_description="" min_height="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="transaction-history-white-pagination-block" id="" background_image_id="" type_medium="" type_small="" order_medium="0" order_small="0" spacing_left_medium="" spacing_right_medium="" spacing_left_small="" spacing_right_small="" spacing_left="" spacing_right="" margin_top_medium="" margin_bottom_medium="" margin_top_small="" margin_bottom_small="" margin_top="" margin_bottom="" padding_top_medium="" padding_right_medium="" padding_bottom_medium="" padding_left_medium="" padding_top_small="" padding_right_small="" padding_bottom_small="" padding_left_small="" padding_top="" padding_right="" padding_bottom="" padding_left="" hover_type="none" border_sizes_top="" border_sizes_right="" border_sizes_bottom="" border_sizes_left="" border_color="" hue="" saturation="" lightness="" alpha="" border_style="solid" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" box_shadow="no" box_shadow_vertical="" box_shadow_horizontal="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index_subgroup="regular" z_index="" z_index_hover="" overflow="" background_type="single" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" lazy_load="avada" skip_lazy_load="" background_position="left top" background_repeat="no-repeat" background_blend_mode="none" render_logics="" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_offset="" absolute="off" absolute_top="" absolute_right="" absolute_bottom="" absolute_left="" filter_type="regular" filter_hover_element="self" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0" transform_type="regular" transform_hover_element="self" transform_scale_x="1" transform_scale_y="1" transform_translate_x="0" transform_translate_y="0" transform_rotate="0" transform_skew_x="0" transform_skew_y="0" transform_origin="" transform_scale_x_hover="1" transform_scale_y_hover="1" transform_translate_x_hover="0" transform_translate_y_hover="0" transform_rotate_hover="0" transform_skew_x_hover="0" transform_skew_y_hover="0" transition_duration="300" transition_easing="ease" transition_custom_easing="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" last="true" border_position="all" first="true"][fusion_text columns="" column_min_width="" column_spacing="" rule_style="" rule_size="" rule_color="" hue="" saturation="" lightness="" alpha="" content_alignment_medium="" content_alignment_small="" content_alignment="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="history-left-bar-content" id="" margin_top="" margin_right="" margin_bottom="" margin_left="" fusion_font_family_text_font="" fusion_font_variant_text_font="" font_size="" line_height="" letter_spacing="" text_transform="" text_color="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]
<div class="showing-filter"><span class="text-format">Showing 1 to 1 of 1 entries</span></div>
[/fusion_text][fusion_text columns="" column_min_width="" column_spacing="" rule_style="" rule_size="" rule_color="" hue="" saturation="" lightness="" alpha="" content_alignment_medium="" content_alignment_small="" content_alignment="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="history-right-bar-content" id="" margin_top="" margin_right="" margin_bottom="" margin_left="" fusion_font_family_text_font="" fusion_font_variant_text_font="" font_size="" line_height="" letter_spacing="" text_transform="" text_color="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]
<div class="history-right-bar-content">
                <div class="showing-filter-padination transaction-pagination"><input type="button" value="Previous" id="prevTransactionPage"><input type="button" value="Next" id="nextTransactionPage"></div>
            </div>
[/fusion_text][/fusion_builder_column_inner][/fusion_builder_row_inner][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container]
');

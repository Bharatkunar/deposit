<style>
    .page-id-6232 {
        font-family: Montserrat, Arial, Helvetica, sans-serif !important;
    }

    /*.page-id-6232 .fusion-builder-row.fusion-row.fusion-flex-align-items-stretch {
    display: none;
}*/
    .page-id-6232 #main .fusion-row {
        max-width: unset !important;
        margin-left: 20px;
        margin-right: 20px;
    }

    .page-id-6232 main#main {
        padding-left: 0px !important;
        padding-right: 0px !important;
    }

    .page-id-6232 #main .fusion-row .fusion-builder-row {
        margin-left: 0px !important;
        margin-right: 0px !important;
    }

    .page-id-6232 #main .fusion-row .fusion-layout-column {
        position: unset !important
    }

    .page-id-6232 #main .fusion-row .fusion-column-wrapper {
        margin: 0px !important;
    }


    .survey-white-block {
        background-color: white;
        max-width: 1200px;
        margin: auto;
        padding: 20px;
        margin-top: 10px;
    }

    .survey-white-block-inner {
        background: #f9f9f9;
        padding: 20px 12px 20px 12px;
        margin-bottom: 0px;
    }

    .survey-white-button-block {
        width: 96%;
        border-bottom: 1px solid #ddd;
    }

    .survey-white-button-block .fusion-column-wrapper {
        flex-direction: row !important;
        gap: 30px;
    }

    .survey-white-button-block a.fusion-button {
        display: inline-block;
        padding: 0px !important;
        background-color: transparent;
        border: 0;
        padding-top: 35px !important;
        padding-bottom: 25px !important;
    }

    .survey-white-button-block a.fusion-button span {
        color: #555 !important;
        font-size: 14px;
        text-transform: capitalize;
        font-weight: 600;
    }

    .available-button.onbutton {
        border-bottom: 1px solid rgba(238, 96, 89) !important;
    }

    .complete-button.onbutton {
        border-bottom: 1px solid rgba(238, 96, 89) !important;
    }

    .survey-title-font {
        font-weight: 700
    }

    .survey-title-font p {
        margin-bottom: 0px;

    }

    .survey-data {
        border: 1px solid #ddd;
        justify-items: center;
        padding-top: 18px;
        padding-bottom: 18px;
        background-color: white;
        font-size: 18px;
        font-family: Poppins, Helvetica, sans-serif;
        color: black;
    }

    .survey-data-completed {
        border: 1px solid #ddd;
        justify-items: center;
        padding-top: 18px;
        padding-bottom: 18px;
        background-color: white;
        font-size: 18px;
        font-family: Poppins, Helvetica, sans-serif;
        color: black;
    }

    .survey-title-font .fusion-content-layout-row {
        gap: 100px;
    }

    .survey-white-block .survey-white-block-inner .fusion-row:nth-child(2) {
        display: none !important;
    }

    .survey-white-block .survey-data {
        display: none !important;
    }

    .survey-white-block .survey-white-block-inner .fusion-row:nth-child(4) {
        display: none !important;
    }

    .survey-white-block .survey-data-completed {
        display: none !important;
    }

    .survey-white-block-inner .fusion-row.showing:nth-child(2) {
        display: block !important;
    }

    .survey-data.showing {
        display: block !important;
    }

    .survey-white-block-inner .fusion-row.showing:nth-child(4) {
        display: block !important;
    }

    .survey-data-completed.showing {
        display: block !important;
    }

    .survey-white-block-inner .fusion-row:nth-child(2) {
        display: flex !important;
        flex-direction: row !important;
    }

    .survey-title-font:nth-child(1) {
        width: 40%;
    }

    .survey-title-font:nth-child(2) {
        width: 55%;
    }

    .survey-flex-box {
        width: 100%;
        display: flex;
    }

    .survey-flex-box .survey-title-font:nth-child(1) {
        width: 40%;
        padding-left: 10px;
        padding-right: 20px;
    }

    .survey-flex-box .survey-title-font:nth-child(2) {
        width: 55%;
        padding-left: 20px;
        padding-right: 20px;
    }

    .survey-flex-box .fusion-content-layout-row {
        display: flex;
        gap: 100px;
    }

    .survey-flex-box .fusion-content-layout-row a {
        background-color: rgba(238, 96, 89);
        padding: 8px;
        border-radius: 5px;
    }

    .take-survey {
        color: white;
        cursor: pointer !important;
        text-decoration: unset !important;
        background-color: rgba(238, 96, 89);
        padding: 8px;
        border-radius: 5px;
        font-weight: 500;
        text-transform: capitalize;
    }

    .take-survey:hover {
        color: white !important;
        cursor: pointer !important;

    }

    .survey-flex-box .survey-title-font ul {
        font-size: 16px;
        margin-bottom: 0px;
    }

    .survey-flex-box .survey-title-font:nth-child(2) div {
        font-size: 16px;
        color: #c5c5c5
    }

    .survey-data-completed .fusion-content-layout-row {
        gap: 110px;
    }

    @media only screen and (max-width: 767px) {
        .survey-data.showing {
            overflow-x: auto;
        }

        .survey-flex-box .survey-title-font:nth-child(1) {
            width: 100%;
        }

        .survey-flex-box .fusion-content-layout-row {
            gap: 20px;
        }

        .survey-flex-box .survey-title-font:nth-child(2) {
            width: 100%;
        }
    }
</style>
<?php
echo do_shortcode('
[fusion_builder_container type="flex" hundred_percent="no" hundred_percent_height="no" min_height_medium="" min_height_small="" min_height="" hundred_percent_height_scroll="no" align_content="stretch" flex_align_items="flex-start" flex_justify_content="flex-start" flex_column_spacing="" hundred_percent_height_center_content="yes" equal_height_columns="no" container_tag="div" menu_anchor="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" status="published" publish_date="" class="survey-head both-pd-sp1" id="" margin_top_medium="" margin_bottom_medium="" margin_top_small="" margin_bottom_small="" margin_top="" margin_bottom="" padding_top_medium="" padding_right_medium="" padding_bottom_medium="" padding_left_medium="" padding_top_small="" padding_right_small="" padding_bottom_small="" padding_left_small="" padding_top="" padding_right="" padding_bottom="" padding_left="" link_color="" hue="" saturation="" lightness="" alpha="" link_hover_color="" border_sizes_top="" border_sizes_right="" border_sizes_bottom="" border_sizes_left="" border_color="" border_style="solid" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" box_shadow="no" box_shadow_vertical="" box_shadow_horizontal="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index="" overflow="" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" skip_lazy_load="" background_position="center center" background_repeat="no-repeat" fade="no" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_blend_mode="none" video_mp4="" video_webm="" video_ogv="" video_url="" video_aspect_ratio="16:9" video_loop="yes" video_mute="yes" video_preview_image="" pattern_bg="none" pattern_custom_bg="" pattern_bg_color="" pattern_bg_style="default" pattern_bg_opacity="100" pattern_bg_size="" pattern_bg_blend_mode="normal" mask_bg="none" mask_custom_bg="" mask_bg_color="" mask_bg_accent_color="" mask_bg_style="default" mask_bg_opacity="100" mask_bg_transform="left" mask_bg_blend_mode="normal" render_logics="" absolute="off" absolute_devices="small,medium,large" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_background_color="" sticky_height="" sticky_offset="" sticky_transition_offset="0" scroll_offset="0" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" align_self="auto" content_layout="column" align_content="flex-start" valign_content="flex-start" content_wrap="wrap" spacing="" center_content="no" column_tag="div" link="" target="_self" link_description="" min_height="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="" id="" type_medium="" type_small="" order_medium="0" order_small="0" dimension_spacing_medium="" dimension_spacing_small="" dimension_spacing="" dimension_margin_medium="" dimension_margin_small="" margin_top="" margin_bottom="" padding_medium="" padding_small="" padding_top="" padding_right="" padding_bottom="" padding_left="" hover_type="none" border_sizes="" border_color="" border_style="solid" border_radius="" box_shadow="no" dimension_box_shadow="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index_subgroup="regular" z_index="" z_index_hover="" overflow="" background_type="single" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" background_image_id="" lazy_load="avada" skip_lazy_load="" background_position="left top" background_repeat="no-repeat" background_blend_mode="none" render_logics="" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_offset="" absolute="off" absolute_props="" filter_type="regular" filter_hover_element="self" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0" transform_type="regular" transform_hover_element="self" transform_scale_x="1" transform_scale_y="1" transform_translate_x="0" transform_translate_y="0" transform_rotate="0" transform_skew_x="0" transform_skew_y="0" transform_scale_x_hover="1" transform_scale_y_hover="1" transform_translate_x_hover="0" transform_translate_y_hover="0" transform_rotate_hover="0" transform_skew_x_hover="0" transform_skew_y_hover="0" transform_origin="" transition_duration="300" transition_easing="ease" transition_custom_easing="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" last="true" border_position="all" first="true"][fusion_builder_row_inner][fusion_builder_column_inner type="1_1" layout="1_1" align_self="auto" content_layout="column" align_content="flex-start" valign_content="flex-start" content_wrap="wrap" spacing="" center_content="no" column_tag="div" link="" target="_self" link_description="" min_height="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="" id="" type_medium="" type_small="" order_medium="0" order_small="0" dimension_spacing_medium="" dimension_spacing_small="" dimension_spacing="" dimension_margin_medium="" dimension_margin_small="" dimension_margin="" padding_medium="" padding_small="" padding_top="" padding_right="" padding_bottom="" padding_left="" hover_type="none" border_sizes="" border_color="" border_style="solid" border_radius="" box_shadow="no" dimension_box_shadow="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index_subgroup="regular" z_index="" z_index_hover="" overflow="" background_type="single" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" background_image_id="" lazy_load="avada" skip_lazy_load="" background_position="left top" background_repeat="no-repeat" background_blend_mode="none" render_logics="" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_offset="" absolute="off" absolute_props="" filter_type="regular" filter_hover_element="self" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0" transform_type="regular" transform_hover_element="self" transform_scale_x="1" transform_scale_y="1" transform_translate_x="0" transform_translate_y="0" transform_rotate="0" transform_skew_x="0" transform_skew_y="0" transform_scale_x_hover="1" transform_scale_y_hover="1" transform_translate_x_hover="0" transform_translate_y_hover="0" transform_rotate_hover="0" transform_skew_x_hover="0" transform_skew_y_hover="0" transform_origin="" transition_duration="300" transition_easing="ease" transition_custom_easing="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" last="true" border_position="all" element_content="" first="true"][fusion_button link="#" title="" target="_self" link_attributes="" alignment_medium="" alignment_small="" alignment="" modal="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="user-minus-icon" id="" color="default" button_gradient_top_color="" hue="" saturation="" lightness="" alpha="" button_gradient_bottom_color="" button_gradient_top_color_hover="" button_gradient_bottom_color_hover="" gradient_start_position="" gradient_end_position="" gradient_type="" radial_direction="" linear_angle="180" accent_color="" accent_hover_color="" type="" bevel_color="" bevel_color_hover="" border_top="" border_right="" border_bottom="" border_left="" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" border_color="" border_hover_color="" size="" padding_top="" padding_right="" padding_bottom="" padding_left="" fusion_font_family_button_font="" fusion_font_variant_button_font="" font_size="" line_height="" letter_spacing="" text_transform="" stretch="default" margin_top="" margin_right="" margin_bottom="" margin_left="" icon="" icon_position="left" icon_divider="no" hover_transition="none" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]Profile[/fusion_button][fusion_button link="#" title="" target="_self" link_attributes="" alignment_medium="" alignment_small="" alignment="" modal="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="user-minus-icon" id="" color="default" button_gradient_top_color="" hue="" saturation="" lightness="" alpha="" button_gradient_bottom_color="" button_gradient_top_color_hover="" button_gradient_bottom_color_hover="" gradient_start_position="" gradient_end_position="" gradient_type="" radial_direction="" linear_angle="180" accent_color="" accent_hover_color="" type="" bevel_color="" bevel_color_hover="" border_top="" border_right="" border_bottom="" border_left="" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" border_color="" border_hover_color="" size="" padding_top="" padding_right="" padding_bottom="" padding_left="" fusion_font_family_button_font="" fusion_font_variant_button_font="" font_size="" line_height="" letter_spacing="" text_transform="" stretch="default" margin_top="" margin_right="" margin_bottom="" margin_left="" icon="" icon_position="left" icon_divider="no" hover_transition="none" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]Ways To Earn[/fusion_button][fusion_button link="#" title="" target="_self" link_attributes="" alignment_medium="" alignment_small="" alignment="" modal="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="list-icon" id="" color="default" button_gradient_top_color="" hue="" saturation="" lightness="" alpha="" button_gradient_bottom_color="" button_gradient_top_color_hover="" button_gradient_bottom_color_hover="" gradient_start_position="" gradient_end_position="" gradient_type="" radial_direction="" linear_angle="180" accent_color="" accent_hover_color="" type="" bevel_color="" bevel_color_hover="" border_top="" border_right="" border_bottom="" border_left="" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" border_color="" border_hover_color="" size="" padding_top="" padding_right="" padding_bottom="" padding_left="" fusion_font_family_button_font="" fusion_font_variant_button_font="" font_size="" line_height="" letter_spacing="" text_transform="" stretch="default" margin_top="" margin_right="" margin_bottom="" margin_left="" icon="" icon_position="left" icon_divider="no" hover_transition="none" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]Transaction History[/fusion_button][fusion_button link="#" title="" target="_self" link_attributes="" alignment_medium="" alignment_small="" alignment="" modal="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="shopping-icon" id="" color="default" button_gradient_top_color="" hue="" saturation="" lightness="" alpha="" button_gradient_bottom_color="" button_gradient_top_color_hover="" button_gradient_bottom_color_hover="" gradient_start_position="" gradient_end_position="" gradient_type="" radial_direction="" linear_angle="180" accent_color="" accent_hover_color="" type="" bevel_color="" bevel_color_hover="" border_top="" border_right="" border_bottom="" border_left="" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" border_color="" border_hover_color="" size="" padding_top="" padding_right="" padding_bottom="" padding_left="" fusion_font_family_button_font="" fusion_font_variant_button_font="" font_size="" line_height="" letter_spacing="" text_transform="" stretch="default" margin_top="" margin_right="" margin_bottom="" margin_left="" icon="" icon_position="left" icon_divider="no" hover_transition="none" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]Reward Point Goals[/fusion_button][fusion_button link="#" title="" target="_self" link_attributes="" alignment_medium="" alignment_small="" alignment="" modal="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="lock-icon" id="" color="default" button_gradient_top_color="" hue="" saturation="" lightness="" alpha="" button_gradient_bottom_color="" button_gradient_top_color_hover="" button_gradient_bottom_color_hover="" gradient_start_position="" gradient_end_position="" gradient_type="" radial_direction="" linear_angle="180" accent_color="" accent_hover_color="" type="" bevel_color="" bevel_color_hover="" border_top="" border_right="" border_bottom="" border_left="" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" border_color="" border_hover_color="" size="" padding_top="" padding_right="" padding_bottom="" padding_left="" fusion_font_family_button_font="" fusion_font_variant_button_font="" font_size="" line_height="" letter_spacing="" text_transform="" stretch="default" margin_top="" margin_right="" margin_bottom="" margin_left="" icon="" icon_position="left" icon_divider="no" hover_transition="none" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]Update Profile[/fusion_button][/fusion_builder_column_inner][/fusion_builder_row_inner][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container type="flex" hundred_percent="no" hundred_percent_height="no" min_height_medium="" min_height_small="" min_height="" hundred_percent_height_scroll="no" align_content="stretch" flex_align_items="flex-start" flex_justify_content="flex-start" flex_column_spacing="" hundred_percent_height_center_content="yes" equal_height_columns="no" container_tag="div" menu_anchor="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" status="published" publish_date="" class="heading-box-container both-pd-sp1" id="" margin_top_medium="" margin_bottom_medium="" margin_top_small="" margin_bottom_small="" margin_top="" margin_bottom="" padding_top_medium="" padding_right_medium="" padding_bottom_medium="" padding_left_medium="" padding_top_small="" padding_right_small="" padding_bottom_small="" padding_left_small="" padding_top="" padding_right="" padding_bottom="" padding_left="" link_color="" hue="" saturation="" lightness="" alpha="" link_hover_color="" border_sizes_top="" border_sizes_right="" border_sizes_bottom="" border_sizes_left="" border_color="" border_style="solid" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" box_shadow="no" box_shadow_vertical="" box_shadow_horizontal="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index="" overflow="" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" skip_lazy_load="" background_position="center center" background_repeat="no-repeat" fade="no" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_blend_mode="none" video_mp4="" video_webm="" video_ogv="" video_url="" video_aspect_ratio="16:9" video_loop="yes" video_mute="yes" video_preview_image="" pattern_bg="none" pattern_custom_bg="" pattern_bg_color="" pattern_bg_style="default" pattern_bg_opacity="100" pattern_bg_size="" pattern_bg_blend_mode="normal" mask_bg="none" mask_custom_bg="" mask_bg_color="" mask_bg_accent_color="" mask_bg_style="default" mask_bg_opacity="100" mask_bg_transform="left" mask_bg_blend_mode="normal" render_logics="" absolute="off" absolute_devices="small,medium,large" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_background_color="" sticky_height="" sticky_offset="" sticky_transition_offset="0" scroll_offset="0" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" align_self="auto" content_layout="column" align_content="flex-start" valign_content="flex-start" content_wrap="wrap" spacing="" center_content="no" column_tag="div" link="" target="_self" link_description="" min_height="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="" id="" type_medium="" type_small="" order_medium="0" order_small="0" dimension_spacing_medium="" dimension_spacing_small="" dimension_spacing="" dimension_margin_medium="" dimension_margin_small="" margin_top="" margin_bottom="" padding_medium="" padding_small="" padding_top="" padding_right="" padding_bottom="" padding_left="" hover_type="none" border_sizes="" border_color="" border_style="solid" border_radius="" box_shadow="no" dimension_box_shadow="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index_subgroup="regular" z_index="" z_index_hover="" overflow="" background_type="single" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" background_image_id="" lazy_load="avada" skip_lazy_load="" background_position="left top" background_repeat="no-repeat" background_blend_mode="none" render_logics="" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_offset="" absolute="off" absolute_props="" filter_type="regular" filter_hover_element="self" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0" transform_type="regular" transform_hover_element="self" transform_scale_x="1" transform_scale_y="1" transform_translate_x="0" transform_translate_y="0" transform_rotate="0" transform_skew_x="0" transform_skew_y="0" transform_scale_x_hover="1" transform_scale_y_hover="1" transform_translate_x_hover="0" transform_translate_y_hover="0" transform_rotate_hover="0" transform_skew_x_hover="0" transform_skew_y_hover="0" transform_origin="" transition_duration="300" transition_easing="ease" transition_custom_easing="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" last="true" border_position="all" first="true"][fusion_text columns="" column_min_width="" column_spacing="" rule_style="" rule_size="" rule_color="" hue="" saturation="" lightness="" alpha="" content_alignment_medium="" content_alignment_small="" content_alignment="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="" id="" margin_top="" margin_right="" margin_bottom="" margin_left="" fusion_font_family_text_font="" fusion_font_variant_text_font="" font_size="" line_height="" letter_spacing="" text_transform="" text_color="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]

Survey List

[/fusion_text][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container type="flex" hundred_percent="no" hundred_percent_height="no" min_height_medium="" min_height_small="" min_height="" hundred_percent_height_scroll="no" align_content="stretch" flex_align_items="flex-start" flex_justify_content="flex-start" flex_column_spacing="" hundred_percent_height_center_content="yes" equal_height_columns="no" container_tag="div" menu_anchor="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" status="published" publish_date="" class="survey-white-block both-pd-sp1" id="" margin_top_medium="" margin_bottom_medium="" margin_top_small="" margin_bottom_small="" margin_top="" margin_bottom="" padding_top_medium="" padding_right_medium="" padding_bottom_medium="" padding_left_medium="" padding_top_small="" padding_right_small="" padding_bottom_small="" padding_left_small="" padding_top="" padding_right="" padding_bottom="" padding_left="" link_color="" hue="" saturation="" lightness="" alpha="" link_hover_color="" border_sizes_top="" border_sizes_right="" border_sizes_bottom="" border_sizes_left="" border_color="" border_style="solid" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" box_shadow="no" box_shadow_vertical="" box_shadow_horizontal="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index="" overflow="" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" skip_lazy_load="" background_position="center center" background_repeat="no-repeat" fade="no" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_blend_mode="none" video_mp4="" video_webm="" video_ogv="" video_url="" video_aspect_ratio="16:9" video_loop="yes" video_mute="yes" video_preview_image="" pattern_bg="none" pattern_custom_bg="" pattern_bg_color="" pattern_bg_style="default" pattern_bg_opacity="100" pattern_bg_size="" pattern_bg_blend_mode="normal" mask_bg="none" mask_custom_bg="" mask_bg_color="" mask_bg_accent_color="" mask_bg_style="default" mask_bg_opacity="100" mask_bg_transform="left" mask_bg_blend_mode="normal" render_logics="" absolute="off" absolute_devices="small,medium,large" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_background_color="" sticky_height="" sticky_offset="" sticky_transition_offset="0" scroll_offset="0" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" align_self="auto" content_layout="column" align_content="flex-start" valign_content="flex-start" content_wrap="wrap" spacing="" center_content="no" column_tag="div" link="" target="_self" link_description="" min_height="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="survey-white-block-inner" id="" background_image_id="" type_medium="" type_small="" order_medium="0" order_small="0" spacing_left_medium="" spacing_right_medium="" spacing_left_small="" spacing_right_small="" spacing_left="" spacing_right="" margin_top_medium="" margin_bottom_medium="" margin_top_small="" margin_bottom_small="" margin_top="" margin_bottom="" padding_top_medium="" padding_right_medium="" padding_bottom_medium="" padding_left_medium="" padding_top_small="" padding_right_small="" padding_bottom_small="" padding_left_small="" padding_top="" padding_right="" padding_bottom="" padding_left="" hover_type="none" border_sizes_top="" border_sizes_right="" border_sizes_bottom="" border_sizes_left="" border_color="" hue="" saturation="" lightness="" alpha="" border_style="solid" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" box_shadow="no" box_shadow_vertical="" box_shadow_horizontal="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index_subgroup="regular" z_index="" z_index_hover="" overflow="" background_type="single" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" lazy_load="avada" skip_lazy_load="" background_position="left top" background_repeat="no-repeat" background_blend_mode="none" render_logics="" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_offset="" absolute="off" absolute_top="" absolute_right="" absolute_bottom="" absolute_left="" filter_type="regular" filter_hover_element="self" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0" transform_type="regular" transform_hover_element="self" transform_scale_x="1" transform_scale_y="1" transform_translate_x="0" transform_translate_y="0" transform_rotate="0" transform_skew_x="0" transform_skew_y="0" transform_origin="" transform_scale_x_hover="1" transform_scale_y_hover="1" transform_translate_x_hover="0" transform_translate_y_hover="0" transform_rotate_hover="0" transform_skew_x_hover="0" transform_skew_y_hover="0" transition_duration="300" transition_easing="ease" transition_custom_easing="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" last="true" border_position="all" first="true"][fusion_builder_row_inner][fusion_builder_column_inner type="1_1" layout="1_1" align_self="auto" content_layout="column" align_content="flex-start" valign_content="flex-start" content_wrap="wrap" spacing="" center_content="no" column_tag="div" link="" target="_self" link_description="" min_height="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="survey-white-button-block" id="" background_image_id="" type_medium="" type_small="" order_medium="0" order_small="0" spacing_left_medium="" spacing_right_medium="" spacing_left_small="" spacing_right_small="" spacing_left="" spacing_right="" margin_top_medium="" margin_bottom_medium="" margin_top_small="" margin_bottom_small="" margin_top="" margin_bottom="" padding_top_medium="" padding_right_medium="" padding_bottom_medium="" padding_left_medium="" padding_top_small="" padding_right_small="" padding_bottom_small="" padding_left_small="" padding_top="" padding_right="" padding_bottom="" padding_left="" hover_type="none" border_sizes_top="" border_sizes_right="" border_sizes_bottom="" border_sizes_left="" border_color="" hue="" saturation="" lightness="" alpha="" border_style="solid" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" box_shadow="no" box_shadow_vertical="" box_shadow_horizontal="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index_subgroup="regular" z_index="" z_index_hover="" overflow="" background_type="single" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" lazy_load="avada" skip_lazy_load="" background_position="left top" background_repeat="no-repeat" background_blend_mode="none" render_logics="" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_offset="" absolute="off" absolute_top="" absolute_right="" absolute_bottom="" absolute_left="" filter_type="regular" filter_hover_element="self" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0" transform_type="regular" transform_hover_element="self" transform_scale_x="1" transform_scale_y="1" transform_translate_x="0" transform_translate_y="0" transform_rotate="0" transform_skew_x="0" transform_skew_y="0" transform_origin="" transform_scale_x_hover="1" transform_scale_y_hover="1" transform_translate_x_hover="0" transform_translate_y_hover="0" transform_rotate_hover="0" transform_skew_x_hover="0" transform_skew_y_hover="0" transition_duration="300" transition_easing="ease" transition_custom_easing="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" last="true" border_position="all" first="true"][fusion_button link="" title="" target="_self" link_attributes="" alignment_medium="" alignment_small="" alignment="" modal="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="available-button onbutton" id="" color="default" button_gradient_top_color="" hue="" saturation="" lightness="" alpha="" button_gradient_bottom_color="" button_gradient_top_color_hover="" button_gradient_bottom_color_hover="" gradient_start_position="" gradient_end_position="" gradient_type="" radial_direction="" linear_angle="180" accent_color="" accent_hover_color="" type="" bevel_color="" bevel_color_hover="" border_top="" border_right="" border_bottom="" border_left="" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" border_color="" border_hover_color="" size="" padding_top="" padding_right="" padding_bottom="" padding_left="" fusion_font_family_button_font="" fusion_font_variant_button_font="" font_size="" line_height="" letter_spacing="" text_transform="" stretch="default" margin_top="" margin_right="" margin_bottom="" margin_left="" icon="" icon_position="left" icon_divider="no" hover_transition="none" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]Available Surveys[/fusion_button][fusion_button link="" title="" target="_self" link_attributes="" alignment_medium="" alignment_small="" alignment="" modal="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="complete-button" id="" color="default" button_gradient_top_color="" hue="" saturation="" lightness="" alpha="" button_gradient_bottom_color="" button_gradient_top_color_hover="" button_gradient_bottom_color_hover="" gradient_start_position="" gradient_end_position="" gradient_type="" radial_direction="" linear_angle="180" accent_color="" accent_hover_color="" type="" bevel_color="" bevel_color_hover="" border_top="" border_right="" border_bottom="" border_left="" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" border_color="" border_hover_color="" size="" padding_top="" padding_right="" padding_bottom="" padding_left="" fusion_font_family_button_font="" fusion_font_variant_button_font="" font_size="" line_height="" letter_spacing="" text_transform="" stretch="default" margin_top="" margin_right="" margin_bottom="" margin_left="" icon="" icon_position="left" icon_divider="no" hover_transition="none" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]Completed Surveys[/fusion_button][/fusion_builder_column_inner][/fusion_builder_row_inner][fusion_builder_row_inner][fusion_builder_column_inner type="1_2" layout="1_2" align_self="auto" content_layout="column" align_content="flex-start" valign_content="flex-start" content_wrap="wrap" spacing="" center_content="no" column_tag="div" link="" target="_self" link_description="" min_height="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="survey-title-font" id="" background_image_id="" type_medium="" type_small="" order_medium="0" order_small="0" spacing_left_medium="" spacing_right_medium="" spacing_left_small="" spacing_right_small="" spacing_left="" spacing_right="" margin_top_medium="" margin_bottom_medium="" margin_top_small="" margin_bottom_small="" margin_top="" margin_bottom="" padding_top_medium="" padding_right_medium="" padding_bottom_medium="" padding_left_medium="" padding_top_small="" padding_right_small="" padding_bottom_small="" padding_left_small="" padding_top="" padding_right="15" padding_bottom="" padding_left="15" hover_type="none" border_sizes_top="" border_sizes_right="" border_sizes_bottom="" border_sizes_left="" border_color="" hue="" saturation="" lightness="" alpha="" border_style="solid" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" box_shadow="no" box_shadow_vertical="" box_shadow_horizontal="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index_subgroup="regular" z_index="" z_index_hover="" overflow="" background_type="single" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" lazy_load="avada" skip_lazy_load="" background_position="left top" background_repeat="no-repeat" background_blend_mode="none" render_logics="" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_offset="" absolute="off" absolute_top="" absolute_right="" absolute_bottom="" absolute_left="" filter_type="regular" filter_hover_element="self" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0" transform_type="regular" transform_hover_element="self" transform_scale_x="1" transform_scale_y="1" transform_translate_x="0" transform_translate_y="0" transform_rotate="0" transform_skew_x="0" transform_skew_y="0" transform_origin="" transform_scale_x_hover="1" transform_scale_y_hover="1" transform_translate_x_hover="0" transform_translate_y_hover="0" transform_rotate_hover="0" transform_skew_x_hover="0" transform_skew_y_hover="0" transition_duration="300" transition_easing="ease" transition_custom_easing="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" last="false" border_position="all" first="true"][fusion_text columns="" column_min_width="" column_spacing="" rule_style="" rule_size="" rule_color="" hue="" saturation="" lightness="" alpha="" content_alignment_medium="" content_alignment_small="" content_alignment="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="" id="" margin_top="" margin_right="" margin_bottom="" margin_left="" fusion_font_family_text_font="" fusion_font_variant_text_font="" font_size="14" line_height="" letter_spacing="" text_transform="" text_color="#a6a6a6" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]

Survey Title

[/fusion_text][/fusion_builder_column_inner][fusion_builder_column_inner type="1_2" layout="1_2" align_self="auto" content_layout="column" align_content="flex-start" valign_content="flex-start" content_wrap="wrap" spacing="" center_content="no" column_tag="div" link="" target="_self" link_description="" min_height="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="survey-title-font" id="" background_image_id="" type_medium="" type_small="" order_medium="0" order_small="0" spacing_left_medium="" spacing_right_medium="" spacing_left_small="" spacing_right_small="" spacing_left="" spacing_right="" margin_top_medium="" margin_bottom_medium="" margin_top_small="" margin_bottom_small="" margin_top="" margin_bottom="" padding_top_medium="" padding_right_medium="" padding_bottom_medium="" padding_left_medium="" padding_top_small="" padding_right_small="" padding_bottom_small="" padding_left_small="" padding_top="" padding_right="15" padding_bottom="" padding_left="15" hover_type="none" border_sizes_top="" border_sizes_right="" border_sizes_bottom="" border_sizes_left="" border_color="" hue="" saturation="" lightness="" alpha="" border_style="solid" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" box_shadow="no" box_shadow_vertical="" box_shadow_horizontal="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index_subgroup="regular" z_index="" z_index_hover="" overflow="" background_type="single" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" lazy_load="avada" skip_lazy_load="" background_position="left top" background_repeat="no-repeat" background_blend_mode="none" render_logics="" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_offset="" absolute="off" absolute_top="" absolute_right="" absolute_bottom="" absolute_left="" filter_type="regular" filter_hover_element="self" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0" transform_type="regular" transform_hover_element="self" transform_scale_x="1" transform_scale_y="1" transform_translate_x="0" transform_translate_y="0" transform_rotate="0" transform_skew_x="0" transform_skew_y="0" transform_origin="" transform_scale_x_hover="1" transform_scale_y_hover="1" transform_translate_x_hover="0" transform_translate_y_hover="0" transform_rotate_hover="0" transform_skew_x_hover="0" transform_skew_y_hover="0" transition_duration="300" transition_easing="ease" transition_custom_easing="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" last="true" border_position="all" first="false"][fusion_text columns="" column_min_width="" column_spacing="" rule_style="" rule_size="" rule_color="" hue="" saturation="" lightness="" alpha="" content_alignment_medium="" content_alignment_small="" content_alignment="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="" id="" margin_top="" margin_right="" margin_bottom="" margin_left="" fusion_font_family_text_font="" fusion_font_variant_text_font="" font_size="14" line_height="" letter_spacing="" text_transform="" text_color="#a6a6a6" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]

Date Sent

[/fusion_text][/fusion_builder_column_inner][/fusion_builder_row_inner][fusion_text columns="" column_min_width="" column_spacing="" rule_style="" rule_size="" rule_color="" hue="" saturation="" lightness="" alpha="" content_alignment_medium="" content_alignment_small="" content_alignment="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="survey-data" id="available-surveys-container" margin_top="" margin_right="" margin_bottom="" margin_left="" fusion_font_family_text_font="" fusion_font_variant_text_font="" font_size="" line_height="" letter_spacing="" text_transform="" text_color="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]
<div class="survey-flex-box">
    <div class="survey-title-font">
        <ul>
            <li>We value your feedback</li>
        </ul>
    </div>
    <div class="survey-title-font">
        <div class="fusion-content-layout-row">
            <div>07-Mar-2025</div>
            <div><a class="take-survey" href="#">Take survey</a></div>
        </div>
    </div>
</div>
[/fusion_text][fusion_builder_row_inner][fusion_builder_column_inner type="1_2" layout="1_2" align_self="auto" content_layout="column" align_content="flex-start" valign_content="flex-start" content_wrap="wrap" spacing="" center_content="no" column_tag="div" link="" target="_self" link_description="" min_height="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="survey-title-font" id="" background_image_id="" type_medium="" type_small="" order_medium="0" order_small="0" spacing_left_medium="" spacing_right_medium="" spacing_left_small="" spacing_right_small="" spacing_left="" spacing_right="" margin_top_medium="" margin_bottom_medium="" margin_top_small="" margin_bottom_small="" margin_top="" margin_bottom="" padding_top_medium="" padding_right_medium="" padding_bottom_medium="" padding_left_medium="" padding_top_small="" padding_right_small="" padding_bottom_small="" padding_left_small="" padding_top="" padding_right="15" padding_bottom="" padding_left="15" hover_type="none" border_sizes_top="" border_sizes_right="" border_sizes_bottom="" border_sizes_left="" border_color="" hue="" saturation="" lightness="" alpha="" border_style="solid" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" box_shadow="no" box_shadow_vertical="" box_shadow_horizontal="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index_subgroup="regular" z_index="" z_index_hover="" overflow="" background_type="single" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" lazy_load="avada" skip_lazy_load="" background_position="left top" background_repeat="no-repeat" background_blend_mode="none" render_logics="" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_offset="" absolute="off" absolute_top="" absolute_right="" absolute_bottom="" absolute_left="" filter_type="regular" filter_hover_element="self" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0" transform_type="regular" transform_hover_element="self" transform_scale_x="1" transform_scale_y="1" transform_translate_x="0" transform_translate_y="0" transform_rotate="0" transform_skew_x="0" transform_skew_y="0" transform_origin="" transform_scale_x_hover="1" transform_scale_y_hover="1" transform_translate_x_hover="0" transform_translate_y_hover="0" transform_rotate_hover="0" transform_skew_x_hover="0" transform_skew_y_hover="0" transition_duration="300" transition_easing="ease" transition_custom_easing="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" last="false" border_position="all" first="true"][fusion_text columns="" column_min_width="" column_spacing="" rule_style="" rule_size="" rule_color="" hue="" saturation="" lightness="" alpha="" content_alignment_medium="" content_alignment_small="" content_alignment="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="" id="" margin_top="" margin_right="" margin_bottom="" margin_left="" fusion_font_family_text_font="" fusion_font_variant_text_font="" font_size="14" line_height="" letter_spacing="" text_transform="" text_color="#a6a6a6" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]

Survey Title

[/fusion_text][/fusion_builder_column_inner][fusion_builder_column_inner type="1_2" layout="1_2" align_self="auto" content_layout="row" align_content="flex-start" valign_content="flex-start" content_wrap="wrap" spacing="" center_content="no" column_tag="div" link="" target="_self" link_description="" min_height="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="survey-title-font" id="" background_image_id="" type_medium="" type_small="" order_medium="0" order_small="0" spacing_left_medium="" spacing_right_medium="" spacing_left_small="" spacing_right_small="" spacing_left="" spacing_right="" margin_top_medium="" margin_bottom_medium="" margin_top_small="" margin_bottom_small="" margin_top="" margin_bottom="" padding_top_medium="" padding_right_medium="" padding_bottom_medium="" padding_left_medium="" padding_top_small="" padding_right_small="" padding_bottom_small="" padding_left_small="" padding_top="" padding_right="15" padding_bottom="" padding_left="15" hover_type="none" border_sizes_top="" border_sizes_right="" border_sizes_bottom="" border_sizes_left="" border_color="" hue="" saturation="" lightness="" alpha="" border_style="solid" border_radius_top_left="" border_radius_top_right="" border_radius_bottom_right="" border_radius_bottom_left="" box_shadow="no" box_shadow_vertical="" box_shadow_horizontal="" box_shadow_blur="0" box_shadow_spread="0" box_shadow_color="" box_shadow_style="" z_index_subgroup="regular" z_index="" z_index_hover="" overflow="" background_type="single" gradient_start_color="" gradient_end_color="" gradient_start_position="0" gradient_end_position="100" gradient_type="linear" radial_direction="center center" linear_angle="180" background_color="" background_image="" lazy_load="avada" skip_lazy_load="" background_position="left top" background_repeat="no-repeat" background_blend_mode="none" render_logics="" sticky="off" sticky_devices="small-visibility,medium-visibility,large-visibility" sticky_offset="" absolute="off" absolute_top="" absolute_right="" absolute_bottom="" absolute_left="" filter_type="regular" filter_hover_element="self" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0" transform_type="regular" transform_hover_element="self" transform_scale_x="1" transform_scale_y="1" transform_translate_x="0" transform_translate_y="0" transform_rotate="0" transform_skew_x="0" transform_skew_y="0" transform_origin="" transform_scale_x_hover="1" transform_scale_y_hover="1" transform_translate_x_hover="0" transform_translate_y_hover="0" transform_rotate_hover="0" transform_skew_x_hover="0" transform_skew_y_hover="0" transition_duration="300" transition_easing="ease" transition_custom_easing="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" last="true" border_position="all" first="false"][fusion_text columns="" column_min_width="" column_spacing="" rule_style="" rule_size="" rule_color="" hue="" saturation="" lightness="" alpha="" content_alignment_medium="" content_alignment_small="" content_alignment="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="" id="" margin_top="" margin_right="" margin_bottom="" margin_left="" fusion_font_family_text_font="" fusion_font_variant_text_font="" font_size="14" line_height="" letter_spacing="" text_transform="" text_color="#a6a6a6" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]

Date Sent

[/fusion_text][fusion_text columns="" column_min_width="" column_spacing="" rule_style="" rule_size="" rule_color="" hue="" saturation="" lightness="" alpha="" content_alignment_medium="" content_alignment_small="" content_alignment="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="" id="" margin_top="" margin_right="" margin_bottom="" margin_left="" fusion_font_family_text_font="" fusion_font_variant_text_font="" font_size="14" line_height="" letter_spacing="" text_transform="" text_color="#a6a6a6" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]

Date Completed

[/fusion_text][fusion_text columns="" column_min_width="" column_spacing="" rule_style="" rule_size="" rule_color="" hue="" saturation="" lightness="" alpha="" content_alignment_medium="" content_alignment_small="" content_alignment="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="" id="" margin_top="" margin_right="" margin_bottom="" margin_left="" fusion_font_family_text_font="" fusion_font_variant_text_font="" font_size="14" line_height="" letter_spacing="" text_transform="" text_color="#a6a6a6" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]

Points

[/fusion_text][/fusion_builder_column_inner][/fusion_builder_row_inner][fusion_text columns="" column_min_width="" column_spacing="" rule_style="" rule_size="" rule_color="" hue="" saturation="" lightness="" alpha="" content_alignment_medium="" content_alignment_small="" content_alignment="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="survey-data-completed" id="completed-surveys-container" margin_top="" margin_right="" margin_bottom="" margin_left="" fusion_font_family_text_font="" fusion_font_variant_text_font="" font_size="" line_height="" letter_spacing="" text_transform="" text_color="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset=""]
<div class="survey-flex-box">
    <div class="survey-title-font">
        <ul>
            <li>We value your feedback</li>
        </ul>
    </div>
    <div class="survey-title-font">
        <div class="fusion-content-layout-row">
            <div>07-Mar-2025</div>
            <div>08-Mar-2025</div>
            <div>000</div>
        </div>
    </div>
</div>
[/fusion_text][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container]'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transfer Points</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .profile {
            width: 100%;
            max-width: 900px;
            margin: 50px auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        .profile h3 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
        }

        /* Grid Layout */
        .transfer-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .left-section, .right-section {
            width: 48%;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 8px;
        }

        /* Left Section (Points Display) */
        .pointsblock {
            text-align: center;
            font-size: 28px;
            font-weight: bold;
            color: #28a745;
            padding: 20px;
            border: 2px solid #28a745;
            border-radius: 8px;
            background: #fff;
        }

        /* Right Section (Transfer Form) */
        .form-group {
            margin-bottom: 20px;
        }

        .input-group {
            display: flex;
            align-items: center;
            border: 1px solid #ccc;
            border-radius: 5px;
            overflow: hidden;
            background: #fff;
        }

        .input-group .input-group-addon {
            background: #007bff;
            color: #fff;
            padding: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-right: 1px solid #ccc;
        }

        .form-control {
            padding: 12px 15px;
            font-size: 16px;
            border: none;
            outline: none;
            flex: 1;
        }

        .btn-transfer {
            width: 100%;
            padding: 12px;
            background: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-transfer:hover {
            background: #0056b3;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .transfer-container {
                flex-direction: column;
                gap: 20px;
            }

            .left-section, .right-section {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<section class="profile">
    <h3>Transfer Points</h3>
    <div class="transfer-container">
        <!-- Left: Points Widget -->
        <div class="left-section">
            <p class="text-center"><strong>Point Balance</strong></p>
            <div class="pointsblock">
                <span id="pointsBalance">1000</span> Points
            </div>
        </div>

        <!-- Right: Form Section -->
        <div class="right-section">
            <p class="text-center"><strong>Move My Points to</strong></p>
            <form>
                <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-user"></i></span>
                        <input type="text" class="form-control" id="txtcontact" placeholder="Email, Mobile, or Member ID">
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-exchange"></i></span>
                        <input type="text" class="form-control" id="txtamount" placeholder="Points to Transfer">
                    </div>
                </div>
                <button   type="button" class="btn-transfer">Transfer Points</button>
            </form>
        </div>
    </div>
</section>

</body>
</html>

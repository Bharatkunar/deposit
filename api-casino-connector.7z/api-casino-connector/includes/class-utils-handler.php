<?php

class Utils
{
    public function __construct()
    {

    }
    public static function paginate($query_game) {
        
        $page = isset($_REQUEST['currentPage']) ? max(1, intval($_REQUEST['currentPage'])) : 1;
        $per_page = isset($_REQUEST['per_page']) ? max(1, intval($_REQUEST['per_page'])) : 250;
        $offset = ($page - 1) * $per_page;
    
        // Add LIMIT and OFFSET to the query
        $query_game .= " LIMIT $per_page OFFSET $offset";
        return $query_game;
    }

}


?>
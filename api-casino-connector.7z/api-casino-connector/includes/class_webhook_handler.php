<?php

class Webhook_Handler
{
    public static function handle_webhook($request)
    {
        // Try to parse as JSON
        $raw_body = $request->get_body();
        $json_data = json_decode($raw_body, true);

        // Plugin log path
        $plugin_dir = plugin_dir_path(__FILE__);
        $log_file = $plugin_dir . '../order.log';

        // Try to extract order fields
        $order_id = $json_data['id'] ?? ($json_data['order']['id'] ?? null);
        $status = $json_data['status'] ?? ($json_data['order']['status'] ?? null);

        // Dump full payload for inspection
        $log_entry = "[" . date('Y-m-d H:i:s') . "] Webhook Hit\n";
        $log_entry .= "Raw Body:\n" . $raw_body . "\n";
        $log_entry .= "Parsed Order ID: " . $order_id . "\n";
        $log_entry .= "Order Status: " . $status . "\n";
        $log_entry .= "Parsed JSON:\n" . print_r($json_data, true) . "\n\n";

        file_put_contents($log_file, $log_entry, FILE_APPEND);

        // Forward raw body exactly as received
        $forward_url = 'https://alpha.roborewards.net/api/WooCommerce/CallBack?action=woocommerce';
        $response = wp_remote_post($forward_url, [
            'method'    => 'POST',
            'headers'   => ['Content-Type' => 'application/json'],
            'body'      => $raw_body,
            'timeout'   => 10,
        ]);

        $log_entry .= "Loyalty Response: " . json_encode($response, true) . "\n";
        file_put_contents($log_file, $log_entry, FILE_APPEND);



        return rest_ensure_response([
            'status'        => 'received',
            'order_id'      => $order_id,
            'response_code' => wp_remote_retrieve_response_code($response),
        ]);
    }


}

<?php

class Game_Controller
{
    public function __construct()
    {

    }

    // 
    public function getTotalGamesByStatus($status)
    {
        global $wpdb;
        $games_table = $wpdb->prefix . "casino_games";
        $query = "select count(id) as totalGames from {$games_table} where enabled = '$status'";
        $runQuery = $wpdb->get_results($query);
        return $runQuery;
    }

    public function getFilteredGames($filters = [], $offset = 0, $limit = 250) {
        global $wpdb;

        $game_table = $wpdb->prefix . "casino_games";
        $game_type = $wpdb->prefix . "casino_game_type";
        $game_provider = $wpdb->prefix . "casino_game_provider";
        $game_technology = $wpdb->prefix . "casino_game_technology";
        $game_lobby = $wpdb->prefix . "casino_game_lobby";
    
        $query_game = "SELECT 
                        g.*, 
                        COUNT(l.id) AS totalLobby, 
                        t.name AS type_name, 
                        p.name AS provider_name, 
                        tech.name AS technology_name
                    FROM $game_table g
                    LEFT JOIN $game_type t ON g.type = t.id
                    LEFT JOIN $game_provider p ON g.provider = p.id
                    LEFT JOIN $game_technology tech ON g.technology = tech.id
                    LEFT JOIN $game_lobby l ON g.id = l.local_game_id";
    
        $where_clauses = [];
        $params = [];
    
        // Apply filters dynamically
        if (!empty($filters['type'])) {
            $where_clauses[] = "g.type IN (%s)";
            $params[] = $filters['type'];
        }
        if (!empty($filters['provider'])) {
            $where_clauses[] = "g.provider IN (%s)";
            $params[] = $filters['provider'];
        }
        if (!empty($filters['technology'])) {
            $where_clauses[] = "g.technology IN (%s)";
            $params[] = $filters['technology'];
        }
    
        // Apply enabled filter only if 'live' filter is set
        if (isset($filters['live'])) {
            $enabled_value = filter_var($filters['live'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
            if ($enabled_value !== null) {
                $where_clauses[] = "g.enabled = %d";
                $params[] = $enabled_value ? 1 : 0;
            }
        }
    
        // Apply WHERE clause if there are any filters
        if (!empty($where_clauses)) {
            $query_game .= " WHERE " . implode(" AND ", $where_clauses);
        }
    
        // Group by necessary columns
        $query_game .= " GROUP BY 
                        g.id, g.name, g.type, g.provider, g.technology, 
                        t.name, p.name, tech.name";
    
        // Set limit and offset
        $limit = isset($filters['games']) ? absint($filters['games']) : 250;
        $offset = isset($offset) ? absint($offset) : 0;
    
        $query_game .= " LIMIT %d OFFSET %d";
        $params[] = $limit;
        $params[] = $offset;
    
        // Prepare and execute query
        $prepared_query = $wpdb->prepare($query_game, $params);
        $results = $wpdb->get_results($prepared_query);
    
        return $results;
    }
    
    

}

?>
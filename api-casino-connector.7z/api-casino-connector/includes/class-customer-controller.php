<?php
// echo "saima";
// exit;

class CustomerController {
    public $loyalty;
    function __construct()
    {
        $this->loyalty = new LoyaltyApiHanlder();
    }

    public function customerDashboard()
    {
        global $wpdb;


        $results = $this->loyalty->dashboard();

        // Get the user ID
        $user_id = get_current_user_id(); // ✅ Correct function to get user ID
        if (!$user_id) {
            return "User is not logged in.";
        }
   

        // Table name
        $table = $wpdb->prefix . 'casino_customer_played_game_logs';
        $games_played = $wpdb->prefix . 'casino_customer_play_game';

        // Secure SQL Query using $wpdb->prepare()
        $queryWin = $wpdb->prepare(
            "SELECT COUNT(type) AS totalWins FROM {$table} WHERE type='win' and player_id = %d",
            $user_id
        );
        // Execute the query
        $totalWins = $wpdb->get_var($queryWin);
   

        $queryBet = $wpdb->prepare(
            "SELECT COUNT(type) AS totalWins FROM {$table} WHERE type='bet' and player_id = %d",
            $user_id
        );
        $totalBets = $wpdb->get_var($queryBet);

       
        $queryTotalGames = $wpdb->prepare(
            "SELECT COUNT(id) AS totalGamesPlayed FROM {$games_played} WHERE player_id = %d",
            $user_id
        );
        // Execute the query
        $totalGamesPlayed = $wpdb->get_var($queryTotalGames);

        $customer = "
            SELECT u.*, cb.current_balance AS customer_balance FROM wp_users AS u INNER JOIN wp_usermeta AS um ON u.ID = um.user_id LEFT JOIN {$wpdb->prefix}casino_balance AS cb ON u.ID = cb.player_id WHERE um.meta_key = 'wp_capabilities' AND um.meta_value LIKE '%game_customer%' and u.ID = '$user_id' GROUP by u.ID ORDER BY u.user_registered DESC limit 10;
        ";
        $runCustomerQuery = $wpdb->get_results($customer);
        $customerBalance = isset($runCustomerQuery[0]) && isset($runCustomerQuery[0]->customer_balance) 
            ? $runCustomerQuery[0]->customer_balance 
            : 0;


        $recentTransactions = $wpdb->prepare(
            "SELECT * FROM {$table} WHERE player_id = %d group by transaction_id limit 20",
            $user_id
        );
        // Execute the query
        $recentTransactions = $wpdb->get_results($recentTransactions);


        $customerWinningRatio = 
        "
            SELECT 
            (SUM(CASE WHEN type = 'win' THEN amount ELSE 0 END) / 
            SUM(amount)) * 100 AS winning_ratio
            FROM {$table}
            WHERE player_id = '$user_id';
        ";
        $runCustomerWinningRatio = $wpdb->get_var($customerWinningRatio);


        return array(
            'totalWin' => $results['winLossSummary']['totalWinAmount'], //$totalWins,
            'totalBets' => $totalBets,
            'totalGamesPlayed' => $results['winLossSummary']['totalGamesPlayed'],
            'customerBalance' => $results['winLossSummary']['currentBalance'],
            'latestTransactions' => $results['recentTransactions'],
            'ratio' => $results['winLossSummary']['winLossRatio'],
        );
    }
    
    public function dashboard()
    {   
        global $wpdb;


        $games_table = $wpdb->prefix . "casino_games";
        $casino_customer_played_game_logs = $wpdb->prefix . "casino_customer_played_game_logs";
        $users = $wpdb->prefix . "users";
        $casino_customer_play_game = $wpdb->prefix . "casino_customer_play_game";
        $casino_balance = $wpdb->prefix . 'casino_balance';

        // Total Active Games
        $totalActive  = "select COUNT(id) as totalGames from {$games_table} where enabled = 1";
        $runTotalActive = $wpdb->get_results($totalActive);

        $totalInActive  = "select COUNT(id) as totalGames from {$games_table} where enabled = 0";
        $runTotalInActive = $wpdb->get_results($totalInActive);


        $customer = "
            SELECT u.*, cb.current_balance AS customer_balance FROM wp_users AS u INNER JOIN wp_usermeta AS um ON u.ID = um.user_id LEFT JOIN {$wpdb->prefix}casino_balance AS cb ON u.ID = cb.player_id WHERE um.meta_key = 'wp_capabilities' AND um.meta_value LIKE '%game_customer%' GROUP by u.ID ORDER BY u.user_registered DESC limit 10;
        ";
        $runCustomerQuery = $wpdb->get_results($customer);
        
   
        // Total Games Played

        $query = "
            SELECT 
                {$wpdb->prefix}casino_customer_played_game_logs.*,
                wp_users.*
            FROM 
                {$wpdb->prefix}casino_customer_played_game_logs
            JOIN 
                wp_users 
            ON 
                wp_users.ID = {$wpdb->prefix}casino_customer_played_game_logs.player_id
            WHERE 
                {$wpdb->prefix}casino_customer_played_game_logs.created_at <= NOW()
            GROUP BY 
                {$wpdb->prefix}casino_customer_played_game_logs.transaction_id, 
                {$wpdb->prefix}casino_customer_played_game_logs.type;
            limit 10
        ";
   
    
         
        $recentTransactions = $wpdb->get_results($query);

   
        return array(
            'totalActiveGames' => $runTotalActive[0]->totalGames,
            'totalInactiveGames' => $runTotalInActive[0]->totalGames,
            'totalUserRegistered' => count($runCustomerQuery),
            'totalMerchantLimit' => 12,
            'totalTransactionsRecent' => $recentTransactions,
            'latestCustomersRegistered' => $runCustomerQuery,
        );
    }
    
}
new CustomerController();
?>
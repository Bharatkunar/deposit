<?php
class Schema_Handler {
    public function create_or_update_tables() {
        global $wpdb;
        // Define plugin version
        $current_version = get_option('casino_plugin_version', '1.1');
        // Check if an update is needed
        $this->create_tables();
        update_option('casino_plugin_version', '1.2');
    }
    // Method to handle schema updates
    private function create_tables() {
        global $wpdb;
        // Get charset collate
        $charset_collate = $wpdb->get_charset_collate();
        // Define the table schemas
        $tables = [
            'casino_customer_play_game' => $this->get_casino_customer_play_games_schema($charset_collate),
            'casino_customer_played_game_logs' => $this->get_casino_customer_played_game_logs_schema($charset_collate),
            'casino_games' => $this->get_casino_games_schema($charset_collate),
            'casino_balance' => $this->get_casino_balance_schema($charset_collate),
            'casino_game_type' => $this->get_casino_game_type_schema($charset_collate),
            'casino_game_provider' => $this->get_casino__game_provider_schema($charset_collate),
            'casino_game_technology' => $this->get_casino__game_technology_schema($charset_collate),
            'casino_game_lobby' => $this->get_casino__game_lobby_schema($charset_collate),
            'casino_game_short_codes' => $this->get_casino__casino_game_short_codes_schema($charset_collate),
            'loyalty_game_short_codes' => $this->get_loyalty_game_short_codes_schema($charset_collate),
            'casino_game_cronjob_pagination' => $this->get_casino__game_cronjob_pagination_schema($charset_collate),
            'casino_api_logs' => $this->get_casino_api_logs_schema($charset_collate),
            'casino_roborewards_token' => $this->get_casino_roborewards_token_schema($charset_collate),
        ];
        // Execute dbDelta for each table
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        foreach ($tables as $table_name => $schema) {
            $full_table_name = $wpdb->prefix . $table_name;
            $sql = str_replace('{table_name}', $full_table_name, $schema);
            dbDelta($sql);
        }
    }
    // Games Table
    private function get_casino_games_schema($charset_collate) {
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            uuid VARCHAR(255)  NULL,
            name VARCHAR(255)  NULL,
            image VARCHAR(255)  NULL,
            type INT(100)  NULL,
            provider INT(100)  NULL,
            technology INT(100)  NULL,
            has_lobby INT(1)  NULL DEFAULT 0,
            is_mobile INT(1)  NULL DEFAULT 0,
            has_freespins INT(1)  NULL DEFAULT 0,
            has_tables INT(1) NULL DEFAULT 0,
            images LONGTEXT NULL, 
            related_games LONGTEXT NULL,   tags LONGTEXT NULL, 
            enabled  Bool NOT NULL  DEFAULT 0,
            freespin_valid_until_full_day INT(1)  NULL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uuid (uuid)
        ) $charset_collate;";
    }

    // Game Cronjob Pagination

    private function get_casino__game_cronjob_pagination_schema($charset_collate)
    {
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            page INT UNSIGNED NULL,
            totalPages INT UNSIGNED NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }

    private function get_casino__casino_game_short_codes_schema($charset_collate)
    {
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            shortcode_title VARCHAR(255) NULL,
            show_title BOOLEAN NULL,
            active BOOLEAN NULL,
            shortcode VARCHAR(255) NULL,
            json_attributes JSON NULL,  -- Store all dynamic data as JSON here
            use_slider Boolean NULL,
            slider_type_auto Boolean NULL,
            num_of_columns INT(11) NULL,
            num_of_rows INT(11) NULL,
            total_records INT(11) NULL,
            size_of_images INT(11) NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }
    
    private function get_loyalty_game_short_codes_schema($charset_collate)
    {
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            shortcode_title VARCHAR(255) NOT NULL,       -- Title for the shortcode
            shortcode VARCHAR(255) NOT NULL,             -- Actual shortcode string
            description TEXT NULL,                       -- Description of the shortcode
            active BOOLEAN NOT NULL DEFAULT 1,           -- Active status: 1 for active, 0 for inactive
            json_attributes JSON NULL,                   -- Store dynamic API response data as JSON
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;
        ";
    }

    // Game Lobby
    
    private function get_casino__game_lobby_schema($charset_collate) {
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            uuid VARCHAR(255)  NULL,
            local_game_id VARCHAR(255)  NULL,
            lobbyData LONGTEXT  NULL,
            name VARCHAR(255)  NULL,
            dealerName VARCHAR(255)  NULL,
            dealerAvatar VARCHAR(255)  NULL,
            isOpen INT(100)  NULL,
            device VARCHAR(255)  NULL,
            openTime VARCHAR(255)  NULL,
            closeTime VARCHAR(255)  NULL,
            technology VARCHAR(255) NULL,   
            limits    LONGTEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uuid (uuid)
        ) $charset_collate;";
    }
    // Customer Joining the Game Table
    private function get_casino_customer_play_games_schema($charset_collate) {
        global $wpdb;
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            game_id INT(11) NULL,
            api_game_id VARCHAR(255) NULL,
            player_id INT NOT NULL,
            session_id VARCHAR(255) NULL,
            device VARCHAR(255) NULL,
            status VARCHAR(255) NULL DEFAULT 'started',
            return_url VARCHAR(255) NULL,
            language VARCHAR(255) NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }

    private function get_casino_customer_played_game_logs_schema($charset_collate) {
        global $wpdb;
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            play_game_id INT NULL,
            game_id INT(11) NULL,
            api_game_id VARCHAR(255) NULL,
            type VARCHAR(255) NULL,
            action VARCHAR(255) NULL,
            amount DECIMAL(10, 2) NOT NULL,
            currency VARCHAR(255) NULL,
            transaction_id VARCHAR(255) NULL,
            player_id INT NOT NULL,
            session_id VARCHAR(255) NULL,
            round_id VARCHAR(255) NULL,
            finish Boolean NULL DEFAULT false,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }

    private function get_casino_balance_schema($charset_collate)
    {
        global $wpdb;
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            player_id INT NOT NULL,
            last_balance DECIMAL(10, 2) NOT NULL,
            current_balance DECIMAL(10, 2) NOT NULL,
            balance_in DECIMAL(10, 2) NOT NULL,
            type VARCHAR(255) NULL DEFAULT 'free_registration_balance',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }
    private function get_casino_game_type_schema($charset_collate)
    {
        global $wpdb;
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }
    private function get_casino__game_provider_schema($charset_collate)
    {
        global $wpdb;
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }

    private function get_casino__game_technology_schema($charset_collate)
    {
        global $wpdb;
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }

    private function get_casino_api_logs_schema($charset_collate)
    {
        global $wpdb;
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }

    private function get_casino_roborewards_token_schema($charset_collate)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'casino_roborewards_token';

        return "CREATE TABLE $table_name (
            id INT NOT NULL AUTO_INCREMENT,
            rewardProgramToken LONGTEXT NULL,
            username VARCHAR(255) NOT NULL,
            password VARCHAR(255) NOT NULL,
            jwtToken LONGTEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }


}

$schemaHanlder = new Schema_Handler();

<?php
class RoboRewardRoyalityShortCodeHandler
{
    public function __construct()
    {

    }
    public function createShortCode($type="",$data,$endpoint)
    {
        global $wpdb;
        if($endpoint == 'transferPoints')
        {
            
        }

    }
    public function transferPointsShortCode($data)
    {

    }
}

new RoboRewardRoyalityShortCodeHandler();
?>
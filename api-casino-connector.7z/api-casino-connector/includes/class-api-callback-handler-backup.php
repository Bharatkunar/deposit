<?php

class API_Callback_Handler
{
    private $callBackUrl;
    private $loyaltyController;
    public function __construct()
    {
        add_action('wp_ajax_play_game', [$this, 'handle_play_game']);
        add_action('wp_ajax_nopriv_play_game', [$this, 'handle_play_game']);
        $this->callBackUrl  = get_option('casino_callback_url');
    }
    // // Function to Play The Game
    public  function handle_play_game()
    {
        global $wpdb;
        // Verify the AJAX request is valid
        // check_ajax_referer('play_game_nonce', 'security');
        $game_uuid = isset($_POST['game_uuid']) ? sanitize_text_field($_POST['game_uuid']) : null;
        $game_id = isset($_POST['game_id']) ? sanitize_text_field($_POST['game_id']) : null;
        $game_name = isset($_POST['game_name']) ? sanitize_text_field($_POST['game_name']) : null;
        if (!$game_id) {
            wp_send_json_error(['message' => 'Game ID is required.']);
        }

        try {
            // Instantiate the API class and call the initGame method
            // Get current user details
            $current_user = wp_get_current_user();
            $user_id = $current_user->ID; // WordPress User ID
            $username = $current_user->user_login; // WordPress Username
            $server_ip = get_site_url();
            $game_player_id = $user_id . "_" . $server_ip;

            // Generate a unique session ID (or retrieve the existing session)
            $session_id = bin2hex(random_bytes(16)); // Generates a 32-character random string

            // if($user_id == 0)
            // {
            //     wp_
            // }

            // Check if session ID is already set; if not, start the session with the custom ID
            if (empty($session_id)) {
                session_id($session_id);  // Set the custom session ID
                session_start();           // Start the session
            }
            // Construct the data array
            $data = [
                'game_uuid' => $game_uuid,
                'player_id' => $game_player_id, // Concatenate WordPress User ID with a prefix
                'player_name' => $username, // Use WordPress Username
                'currency' => 'EUR',
                'session_id' => $session_id, // Use the generated session ID
                'return_url' => "$this->callBackUrl?action=game_ended&currency=USD&game_id=$game_id&session_id=$session_id&player_id=$user_id",
                'language' => 'English',
                'client_callback_endpoint' => "$this->callBackUrl"
            ];

            // Game Initiated by User
            $table_name = $wpdb->prefix . 'casino_customer_play_game'; // Replace 'documents' with your table's name


            $tableArray = [
                'game_id'      => $game_id,
                'api_game_id'  => $game_uuid,
                'player_id'    => $user_id,
                'session_id'  => $session_id, // Example: ID of the logged-in user
                'device' => 'web',
                'return_url' => "$this->callBackUrl?action=game_ended&currency=EUR&game_id=$game_id&session_id=$session_id&player_id=$user_id",
                'language' => 'English'
            ];

            $gameLog = $wpdb->insert(
                $table_name,
                $tableArray
            );

            $api = new CasinoApi();



            $response = $api->initGame($data);

            // Process the response and return success
            wp_send_json_success([
                'message' => 'Game initialized successfully.',
                'game_url' => $response['url'] ?? null
            ]);
        } catch (Exception $e) {
            wp_send_json_error(['message' => 'Error initializing game: ' . $e->getMessage()]);
        }
    }

    // Function to handle the callback API
    public static function handle_callback(WP_REST_Request $request)
    {
        global $wpdb;

        $action = $request->get_param('action');
        $player_id = $request->get_param('player_id');
        $currency = $request->get_param('currency');
        $session_id = $request->get_param('session_id');
        $game_id = $request->get_param('game_uuid');
        $type = count($_POST) ? 'POST' : "GET";
        $data = json_encode($_REQUEST, true);

        $tableArray = [
            'logs'      => $data,
            'type' => $type
        ];
        $gameLog = $wpdb->insert(
            'wp_logs',
            $tableArray
        );



        // if action not  == balance then hit this

        if ($action != 'balance') {
            self::hanle_game_activity($player_id, $game_id, $session_id, $request);
        }

        // Perform your logic based on the 'action' parameter
        switch ($action) {
            case 'balance':
                return self::handle_balance($player_id, $currency, $session_id);
            case 'bet':
                return self::handle_bet($data);
            case 'win':
                return self::handle_win($data);
            case 'game_ended':
                return self::update_game_status($player_id, $game_id, $session_id);
            case 'refund':
                return self::hanle_refund($data);
            default:
                return new WP_REST_Response('Unknown action.', 400);
        }
    }

    // Example function for 'balance' action
    private static function handle_balance($player_id, $currency, $session_id)
    {
        global $wpdb;
        $sql = $wpdb->prepare("SELECT current_balance FROM {$wpdb->prefix}casino_balance WHERE player_id = %d ORDER BY id DESC LIMIT 1", $player_id);
        $balance = $wpdb->get_var($sql) ? $wpdb->get_var($sql) : 0;
        $game_details = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}casino_customer_play_game WHERE player_id = %d", $player_id)
        );
        $casino_games = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}casino_games WHERE id = %d", $game_details->game_id)
        );
        $casino_games_type = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}casino_game_type WHERE id = %d", $casino_games->type)
        );

        $current_user = wp_get_current_user();
        $user_id = $current_user->ID; // WordPress User ID
        $contact_id = get_user_meta($user_id, 'contact_id', true);

        $transactionId = $params['transaction_id'];

        $loyaltyController = new LoyaltyApiHanlder();

        $data = [
            'wordpress_user_id' => $user_id, // Assuming $user_id is the WordPress user ID
            'contactId' => $contact_id,    // You need to define this value
            'RpId' => get_option('casino_rpID'),              // You need to define this value
            'TransactionId' => $transactionId, // You need to define this value
            'GameType' => $casino_games->type,
            'GameTypeName' => $casino_games_type->name,
            'GameId' => $game_details->game_id,
            'Gameuuid' => $casino_games->uuid,
            'GameName' => $casino_games->name,      // You need to define this value
            'GameStatusType' => $game_details->status, // e.g., 'Loss'
            'Amount' => $balance,           // Amount spent or won
            'SpendMoneyCategory' => '1',
            'current_balance' => $balance,
            'FreeplayBalance' => 0,
            'SportFreeplayBalance' => 0,
            'FreespinBucket' => 0,
            'Timestamp' => time(), // ISO 8601 format; use actual timestamp if available
        ];

        $feedback = $loyaltyController->sendFeedbackToLoyalty("IGaming/CallBack?action=transaction", 'POST', $data);

        // Example logic: Return a mock balance
        return new WP_REST_Response([
            'player_id' => $player_id,
            'currency' => $currency,
            'balance' => $balance,  // Your logic for fetching balance
            'session_id' => $session_id,
        ], 200);
    }

    private static function handle_bet($params)
    {
        global $wpdb;
        $params = json_decode($params, true);
        $player_id = $params['player_id'];
        $sql = $wpdb->prepare("SELECT current_balance FROM {$wpdb->prefix}casino_balance WHERE player_id = %d ORDER BY id DESC LIMIT 1", $params['player_id']);
        $balance = $wpdb->get_var($sql) ? $wpdb->get_var($sql) : 0;

        $game_details = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}casino_customer_play_game WHERE player_id = %d", $player_id)
        );
        $casino_games = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}casino_games WHERE id = %d", $game_details->game_id)
        );
        $casino_games_type = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}casino_game_type WHERE id = %d", $casino_games->type)
        );

        $current_user = wp_get_current_user();
        $user_id = $current_user->ID; // WordPress User ID
        $contact_id = get_user_meta($user_id, 'contact_id', true);

        $loyaltyController = new LoyaltyApiHanlder();

        $transactionId = $params['transaction_id'];

        $data = [
            'wordpress_user_id' => $user_id, // Assuming $user_id is the WordPress user ID
            'contactId' => $contact_id,    // You need to define this value
            'RpId' => get_option('casino_rpID'),              // You need to define this value
            'TransactionId' => $transactionId, // You need to define this value
            'GameType' => $casino_games->type,
            'GameTypeName' => 'bet',
            'GameId' => $game_details->game_id,
            'Gameuuid' => $casino_games->uuid,
            'GameName' => $casino_games->name,      // You need to define this value
            'GameStatusType' => $game_details->status, // e.g., 'Loss'
            'Amount' => $balance,           // Amount spent or won
            'SpendMoneyCategory' => '1',
            'current_balance' => $balance,
            'FreeplayBalance' => 0,
            'SportFreeplayBalance' => 0,
            'FreespinBucket' => 0,
            'Timestamp' => time(), // ISO 8601 format; use actual timestamp if available
        ];

        $feedback = $loyaltyController->sendFeedbackToLoyalty("IGaming/CallBack?action=transaction", 'POST', $data);

        if ($balance < $params['amount']) {
            return new WP_REST_Response([
                "error_code" => "INSUFFICIENT_FUNDS",
                "error_description" => "Not enough money to continue playing"
            ], 200);
        }

        $return_amount  = $balance - $params['amount'];

        $table_name = $wpdb->prefix . 'casino_balance'; // Replace 'documents' with your table's name
        $tableArray = [
            'player_id'      => $params['player_id'],
            'last_balance'    => $balance,
            'current_balance'  => $return_amount, // Example: ID of the logged-in user
            'balance_in' => $params['amount'],
            'type' => 'bet'
        ];
        $balance = $wpdb->insert(
            $table_name,
            $tableArray
        );

        return new WP_REST_Response([
            'balance' => $return_amount,  // Your logic for fetching balance
            'transaction_id' => $params['transaction_id'],
        ], 200);


        // // Example logic: Return a mock balance

    }

    private static function handle_win($params)
    {
        global $wpdb;
        $params = json_decode($params, true);
        $sql = $wpdb->prepare("SELECT current_balance FROM {$wpdb->prefix}casino_balance WHERE player_id = %d ORDER BY id DESC LIMIT 1", $params['player_id']);
        $balance = $wpdb->get_var($sql) ? $wpdb->get_var($sql) : 0;
        $return_amount  = $balance + $params['amount'];
        $table_name = $wpdb->prefix . 'casino_balance'; // Replace 'documents' with your table's name
        $tableArray = [
            'player_id'      => $params['player_id'],
            'last_balance'    => $balance,
            'current_balance'  => $return_amount, // Example: ID of the logged-in user
            'balance_in' => $params['amount'],
            'type' => 'win'
        ];
        $balance = $wpdb->insert(
            $table_name,
            $tableArray
        );

        $game_details = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}casino_customer_play_game WHERE player_id = %d", $params['player_id'])
        );
        $casino_games = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}casino_games WHERE id = %d", $game_details->game_id)
        );
        $casino_games_type = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}casino_game_type WHERE id = %d", $casino_games->type)
        );

        $current_user = wp_get_current_user();
        $user_id = $current_user->ID; // WordPress User ID
        $contact_id = get_user_meta($user_id, 'contact_id', true);

        $transactionId = $params['TransactionId'];

        $loyaltyController = new LoyaltyApiHanlder();

        $data = [
            'wordpress_user_id' => $user_id, // Assuming $user_id is the WordPress user ID
            'contactId' => $contact_id,    // You need to define this value
            'RpId' => get_option('casino_rpID'),              // You need to define this value
            'TransactionId' => $transactionId, // You need to define this value
            'GameType' => $casino_games->type,
            'GameTypeName' => $casino_games_type->name,
            'GameId' => $game_details->game_id,
            'Gameuuid' => $casino_games->uuid,
            'GameName' => $casino_games->name,      // You need to define this value
            'GameStatusType' => $game_details->status, // e.g., 'Loss'
            'Amount' => $balance,           // Amount spent or won
            'SpendMoneyCategory' => '1',
            'current_balance' => $balance,
            'FreeplayBalance' => 0,
            'SportFreeplayBalance' => 0,
            'FreespinBucket' => 0,
            'Timestamp' => time(), // ISO 8601 format; use actual timestamp if available
        ];

        $feedback = $loyaltyController->sendFeedbackToLoyalty("IGaming/CallBack?action=win", 'POST', $data);

        return new WP_REST_Response([
            'player_id' => $params['player_id'],
            'currency' => $params['currency'],
            'balance' => $return_amount,  // Your logic for fetching balance
            'session_id' => $game_details->session_id,
        ], 200);
        // // Example logic: Return a mock balance
    }
    private static function update_game_status($player_id, $game_id, $session_id)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . "casino_customer_play_game";
        $result = $wpdb->update(
            $table_name,
            array(
                'status' => 'completed' // Replace with the column name and new value
            ),
            array(
                'session_id' => $session_id,
                'game_id' => $game_id,
                'player_id' => $player_id
            )
        );

        echo "<h1>Thank you for playing, the game has ended. Please rejoin if you wish to continue.</h1>";
        $base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") .
            "://" . $_SERVER['HTTP_HOST'] .
            rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\') . '/';


        // Correct redirect location
        header("Location: $base_url");
        exit; // Always use exit after header redirects to prevent further execution
    }

    private static function hanle_refund($params)
    {
        global $wpdb;
        $params = json_decode($params, true);
        $sql = $wpdb->prepare("SELECT current_balance FROM {$wpdb->prefix}casino_balance WHERE player_id = %d ORDER BY id DESC LIMIT 1", $params['player_id']);
        $balance = $wpdb->get_var($sql) ? $wpdb->get_var($sql) : 0;
        $return_amount  = $balance + $params['amount'];
        $table_name = $wpdb->prefix . 'casino_balance'; // Replace 'documents' with your table's name
        $tableArray = [
            'player_id'      => $params['player_id'],
            'last_balance'    => $balance,
            'current_balance'  => $return_amount, // Example: ID of the logged-in user
            'balance_in' => $params['amount'],
            'type' => 'refund'
        ];
        $balance = $wpdb->insert(
            $table_name,
            $tableArray
        );

        return new WP_REST_Response([
            'balance' => $return_amount,  // Your logic for fetching balance
            'transaction_id' => $params['transaction_id'],
        ], 200);
    }


    private static function hanle_game_activity($player_id, $game_id, $session_id, $request)
    {
        global $wpdb;
        $query = "select id,game_id from {$wpdb->prefix}casino_customer_play_game where player_id = '$player_id' and api_game_id = '$game_id' and session_id = '$session_id' ";
        $results = $wpdb->get_results($query);

        if (isset($results[0])) {

            $id = $results[0]->id;
            $localGameId = $results[0]->game_id;
            $table_name = $wpdb->prefix . 'casino_customer_played_game_logs'; // Replace 'documents' with your table's name


            $tableArray = [
                'play_game_id'      => $id,
                'game_id'           => $localGameId,
                'api_game_id'      => $game_id,
                'amount'      => $request->get_param('amount'),
                'currency' =>  $request->get_param('currency'),
                'transaction_id'      => $request->get_param('transaction_id'),
                'player_id'    => $request->get_param('player_id'),
                'session_id'  => $request->get_param('session_id'), // Example: ID of the logged-in user
                'round_id' => $request->get_param('round_id'),
                'finish' => $request->get_param('finish'),
                'type'   => $request->get_param('type'),
                'action'   => $request->get_param('action')
            ];
            $balance = $wpdb->insert(
                $table_name,
                $tableArray
            );
        }
    }
}

$casino_dashboard_handler = new API_Callback_Handler();

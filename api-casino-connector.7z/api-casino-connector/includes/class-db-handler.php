<?php
class DB_Handler {
   private $loyaltyHandler;
   public function __construct(Type $var = null) 
    {
        add_action('admin_post_game_filter_form', [$this, 'handle_game_filter_form_submission']);
        add_action('admin_post_nopriv_game_filter_form', [$this, 'handle_game_filter_form_submission']);

        add_action('admin_post_update_enabled_status', [$this, 'handle_update_enabled_status']);
        add_action('admin_post_nopriv_update_enabled_status', [$this, 'handle_update_enabled_status']);


        add_action('admin_post_casino_add_balance_nonce_field', [$this, 'handle_customer_balance']);
        add_action('admin_post_nopriv_casino_add_balance_nonce_field', [$this, 'handle_customer_balance']);
    
        
        add_action('admin_post_casino_store_short_code', [$this, 'casino_store_short_code']);
        add_action('admin_post_nopriv_casino_store_short_code', [$this, 'casino_store_short_code']);
        

        add_action('wp_ajax_get_game_count', [$this, 'get_game_count']);
        add_action('wp_ajax_nopriv_get_game_count', [$this, 'get_game_count']);


        // 

        $this->loyaltyHandler = new LoyaltyApiHanlder();

    
    }

    // Create Short Codes
    public function casino_store_short_code()
    {
        global $wpdb;
        $table = $wpdb->prefix . 'casino_game_short_codes';


        // Get the POST data
        $type = isset($_POST['type']) ? $_POST['type'] : [];
        $technology = isset($_POST['technology']) ? $_POST['technology'] : [];
        $provider = isset($_POST['provider']) ? $_POST['provider'] : [];
        $columns = isset($_POST['num_of_columns']) ? $_POST['num_of_columns'] : 0;
        $num_of_rows = isset($_POST['num_of_rows']) ? $_POST['num_of_rows'] : 0;
        $total_records = isset($_POST['total_records']) ? $_POST['total_records'] : 0;
        $size_of_images = isset($_POST['size_of_images']) ? $_POST['size_of_images'] : 0;
        $use_slider = isset($_POST['use_slider']) ? $_POST['use_slider'] : 0;
        $slider_type_auto = isset($_POST['slider_type']) ? $_POST['slider_type'] : 0;
        $slider_online = isset($_POST['slider_type']) ? $_POST['slider_type'] : 0;

        $shortcode_title = isset($_POST['shortcode_title']) ? $_POST['shortcode_title'] : '';
        $show_title = isset($_POST['show_title']) ? $_POST['show_title'] : false;

        $shortcode_status = isset($_POST['active']) ? $_POST['active'] : false;
    
        if($slider_type_auto && $columns < 7)
        {
            echo "To enable Slider you must have 7 columns";
            $url = $_SERVER['HTTP_REFERER']; // Get the page from which the form was submitted
            wp_redirect($url);
        }

        

        // Initialize the shortcode
        $shortcode = "[casino_all_active_games ";

        // Dynamically add attributes if they have data
        $shortcode .= "games='{$total_records}' rows='{$num_of_rows}' columns='{$columns}'";  // Always add these
        if (!empty($type)) {
            $shortcode .= " type='" . implode(',', $type) . "'"; // Add type if provided
        }
        if (!empty($provider)) {
            $shortcode .= " provider='" . implode(',', $provider) . "'"; // Add provider if provided
        }
        if (!empty($technology)) {
            $shortcode .= " technology='" . implode(',', $technology) . "'"; // Add technology if provided
        }
        if (!empty($use_slider)) {
            $shortcode .= " use_slider='" . $use_slider . "'"; // Add technology if provided
        }
        if (!empty($slider_type_auto)) {
            $shortcode .= " slider_type_auto='" . $slider_type_auto. "'"; // Add technology if provided
        }

        if (!empty($slider_type_auto)) {
            $shortcode .= " slider_type_auto='" . $slider_type_auto. "'"; // Add technology if provided
        }

        if (isset($shortcode_title)) {
            $shortcode .= " title='" . $shortcode_title. "'"; // Add technology if provided
        }

        if (isset($shortcode_status)) {
            $shortcode .= " live='" . $shortcode_status. "'"; // Add technology if provided
        }

        if($show_title)
        {
            $shortcode .= " show_title='" . $show_title. "'"; // Add technology if provided
        }
        

        // Close the shortcode
        $shortcode .= "]";

        // Prepare the data to be stored in the database (json_data will store type, provider, technology)
        $json_attributes = [
            'type' => $type,
            'provider' => $provider,
            'technology' => $technology,
            'games' => $total_records,
            'rows' => $num_of_rows,
            'columns' => $columns,
            'size_of_images' => $size_of_images
        ];

        // Insert data into the table
        $tableArray = [
            'shortcode' => $shortcode,
            'json_attributes' => json_encode($json_attributes), // Convert array to JSON
            'num_of_columns' => $columns,
            'num_of_rows' => $num_of_rows,
            'total_records' => $total_records,
            'size_of_images' => $size_of_images,
            'use_slider' => $use_slider,
            'slider_type_auto' => $slider_type_auto,
            'shortcode_title'  => $shortcode_title,
            'show_title' => $show_title,
            'active' => $shortcode_status
        ];
        // Perform the insert query
        $wpdb->insert($table, $tableArray);
        // Redirect to the previous page
        $url = $_SERVER['HTTP_REFERER']; // Get the page from which the form was submitted
        wp_redirect($url);
    }


    public function get_game_count()
    {
        global $wpdb;

        $technology = isset($_POST['technology']) ? json_decode(stripslashes($_POST['technology'])) : [];
        $type = isset($_POST['type']) ? json_decode(stripslashes($_POST['type'])) : [];
        $provider = isset($_POST['provider']) ? json_decode(stripslashes($_POST['provider'])) : [];
        

        $where_clauses = [];
        if (!empty($technology)) {
            $technology_in = implode(',', array_map('intval', $technology)); // Convert to integer for security
            $where_clauses[] = "technology IN ($technology_in)";
        }
        if (!empty($provider)) {
            $provider_in = implode(',', array_map('intval', $provider)); // Convert to integer for security
            $where_clauses[] = "provider IN ($provider_in)";
        }
        if (!empty($type)) {
            $type_in = implode(',', array_map('intval', $type)); // Convert to integer for security
            $where_clauses[] = "type IN ($type_in)";
        }

            // If no where clauses are present, return all records (no filters)
        if (empty($where_clauses)) {
            $where_sql = "1 = 1"; // This ensures all rows are selected
        } else {
            $where_sql = implode(' AND ', $where_clauses); // Join the individual conditions
        }

        $query = "SELECT COUNT(*) FROM {$wpdb->prefix}casino_games WHERE $where_sql";

        // Execute the query
        $total_games = $wpdb->get_var($query);

        // Return the result as JSON
        wp_send_json_success(['game_count' => $total_games]);
    }

    public function getAllShortCodes()
    {
        global $wpdb;
        $table = $wpdb->prefix . 'casino_game_short_codes';
        // $query  = "select * from {$table}";

        $game_table = $wpdb->prefix . "casino_games";
        $game_type = $wpdb->prefix . "casino_game_type";
        $game_provider = $wpdb->prefix . "casino_game_provider";
        $game_technology = $wpdb->prefix . "casino_game_technology";
    
        // Start building the main query for games
        $query_game = "SELECT * FROM $table";
    
        // Initialize an empty array to hold filter conditions
        return $wpdb->get_results($query_game);

    }

    public function getSingleShortCode($id)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'casino_game_short_codes';
        
        // Start building the main query for games
        $query_game = "SELECT * FROM $table where id = '$id'";
    
        // Initialize an empty array to hold filter conditions
        return $wpdb->get_results($query_game);

    }

    // delete a shortcode

    public function deleteSingleShortCode($id)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'casino_game_short_codes';
        
        // Start building the main query for games
        $deleteShortCode = "Delete FROM $table where id = '$id'";
    
        // Initialize an empty array to hold filter conditions
        return $wpdb->get_results($deleteShortCode);
    }

    // 


    // Dashboard View

    public function dashboard()
    {   
        global $wpdb;

        $games_table = $wpdb->prefix . "casino_games";
        $casino_customer_played_game_logs = $wpdb->prefix . "casino_customer_played_game_logs";
        $users = $wpdb->prefix . "users";
        $casino_customer_play_game = $wpdb->prefix . "casino_customer_play_game";
        $casino_balance = $wpdb->prefix . 'casino_balance';

        // Total Active Games
        $totalActive  = "select COUNT(id) as totalGames from {$games_table} where enabled = 1";
        $runTotalActive = $wpdb->get_results($totalActive);

        $totalInActive  = "select COUNT(id) as totalGames from {$games_table} where enabled = 0";
        $runTotalInActive = $wpdb->get_results($totalInActive);


        $customer = "
            SELECT u.*, cb.current_balance AS customer_balance FROM wp_users AS u INNER JOIN wp_usermeta AS um ON u.ID = um.user_id LEFT JOIN {$wpdb->prefix}casino_balance AS cb ON u.ID = cb.player_id WHERE um.meta_key = 'wp_capabilities' AND um.meta_value LIKE '%game_customer%' GROUP by u.ID ORDER BY u.user_registered DESC limit 10;
        ";
        $runCustomerQuery = $wpdb->get_results($customer);
        
   
        // Total Games Played

        $query = "
            SELECT 
                {$wpdb->prefix}casino_customer_played_game_logs.*,
                wp_users.*
            FROM 
                {$wpdb->prefix}casino_customer_played_game_logs
            JOIN 
                wp_users 
            ON 
                wp_users.ID = {$wpdb->prefix}casino_customer_played_game_logs.player_id
            WHERE 
                {$wpdb->prefix}casino_customer_played_game_logs.created_at <= NOW()
            GROUP BY 
                {$wpdb->prefix}casino_customer_played_game_logs.transaction_id, 
                {$wpdb->prefix}casino_customer_played_game_logs.type;
            limit 10
        ";
   
    
         
        $recentTransactions = $wpdb->get_results($query);

   
        return array(
            'totalActiveGames' => $runTotalActive[0]->totalGames,
            'totalInactiveGames' => $runTotalInActive[0]->totalGames,
            'totalUserRegistered' => count($runCustomerQuery),
            'totalMerchantLimit' => 12,
            'totalTransactionsRecent' => $recentTransactions,
            'latestCustomersRegistered' => $runCustomerQuery,
        );
    }


    public function handle_customer_balance() {
        global $wpdb;
        
        // Get values from POST
        $balance = $_POST['balance_to_add'];
        $currentBalance = $_POST['balance_to_add'] + $_POST['current_balance'];
        $customer_id = $_POST['customer_id'];
    
        // Check if the customer already has a balance record
        $existing_balance = $wpdb->get_var($wpdb->prepare(
            "SELECT current_balance FROM {$wpdb->prefix}casino_balance WHERE player_id = %s", 
            $customer_id
        ));
    
        if ($existing_balance !== null) {
            // Update existing balance if it exists
            $query = "UPDATE {$wpdb->prefix}casino_balance SET current_balance = %f WHERE player_id = %s";
            $wpdb->query($wpdb->prepare($query, $currentBalance, $customer_id));
        } else {
            // Insert new balance if it doesn't exist
            $query = "INSERT INTO {$wpdb->prefix}casino_balance (player_id, current_balance) VALUES (%s, %f)";
            $wpdb->query($wpdb->prepare($query, $customer_id, $currentBalance));
        }

        // Handle Loyalty Code to submit customer balance to loyalty Server

        $this->loyaltyHandler->updateBalance($_POST);

    
        // Define the URL for redirection
        $url = $_SERVER['HTTP_REFERER']; // This gets the page from which the form was submitted
        
        // Redirect to the specified URL
        wp_redirect($url);
        exit;        
    }
    
    public function handle_game_filter_form_submission() {
        // Ensure no output is sent before the redirect
        ob_clean(); // Clean output buffer if anything has been sent
    
        // Get the current page URL (the page the user is currently on)
        $url = $_SERVER['HTTP_REFERER']; // This gets the page from which the form was submitted
        // Append the filters to the URL query string
        $url = add_query_arg([
            'type' => isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '',
            'provider' => isset($_GET['provider']) ? sanitize_text_field($_GET['provider']) : '',
            'technology' => isset($_GET['technology']) ? sanitize_text_field($_GET['technology']) : '',
            'enabled' => isset($_GET['enabled']) ? sanitize_text_field($_GET['enabled']) : '', // Don't forget 'enabled' filter
            'currentPage' => isset($_GET['currentPage']) ? sanitize_text_field($_GET['currentPage']) : 1 // Don't forget 'enabled' filter

        ], $url);

        // Perform the redirect to the same page with the filters applied
        wp_redirect($url); // Redirect with query params
        exit; // Stop further execution to ensure redirection happens
    }
    public function handle_update_enabled_status()
    {
      
        $game_api_status = isset($_POST['activate'])?true:false;
        $status = isset($_POST['activate'])?1:0;
            if (!isset($_POST['enabled_status_nonce']) || !wp_verify_nonce($_POST['enabled_status_nonce'], 'update_enabled_status_nonce')) {
            wp_die('Security check failed.');
        }
        global $wpdb;
        $game_table = $wpdb->prefix . 'casino_games';
        $enabled_games = isset($_POST['selected_games']) ? $_POST['selected_games'] : [];

        if (!empty($enabled_games)) {
            $placeholders = implode(',', array_fill(0, count($enabled_games), '%s'));
            $query = "UPDATE $game_table SET enabled = $status WHERE uuid IN ($placeholders)";
            $wpdb->query($wpdb->prepare($query, $enabled_games));
        }


        $gamesList = [];
        foreach ($enabled_games as $uuid) {
            $gamesList[] = [
                'gameId' => $uuid,
                'status' => $game_api_status
            ];
        }

        // Prepare the final output
        $output = [
            'rptoken' => 'I6H58umMuF24VoWOfsd7ahLJI6b861',
            'gamesList' => $gamesList
        ];


        $response = $this->loyaltyHandler->updateGameListStauts($output);
        wp_redirect(wp_get_referer());
        exit;
    }

    // public function handle_update_enabled_status()
    // {
    //     $game_api_status = isset($_POST['activate']) ? "true" : "false";
    //     $status = $game_api_status ? 1 : 0;

    //     if (!isset($_POST['enabled_status_nonce']) || !wp_verify_nonce($_POST['enabled_status_nonce'], 'update_enabled_status_nonce')) {
    //         wp_die('Security check failed.');
    //     }

    //     global $wpdb;
    //     $game_table = $wpdb->prefix . 'casino_games';

    //     $enabled_games = isset($_POST['selected_games']) ? $_POST['selected_games'] : [];

    //     // Fetch all game UUIDs from the DB
    //     $all_games = $wpdb->get_col("SELECT uuid FROM $game_table");

    //     // Build the gamesList array
    //     $gamesList = [];
    //     foreach ($all_games as $uuid) {
    //         $gamesList[] = [
    //             'gameId' => $uuid,
    //             'status' => $game_api_status
    //         ];
    //     }

    //     // Prepare the final output
    //     $output = [
    //         'rptoken' => 'I6H58umMuF24VoWOfsd7ahLJI6b861',
    //         'gamesList' => $gamesList
    //     ];

    //     echo "<pre>";
    //     print_r($output);
    //     echo "</pre>";
    //     exit;

    //     // Optional: Save or log the output somewhere
    //     // file_put_contents(__DIR__ . '/status_output.json', json_encode($output, JSON_PRETTY_PRINT));

    //     // Run the actual DB update
    //     if (!empty($enabled_games)) {
    //         $placeholders = implode(',', array_fill(0, count($enabled_games), '%s'));
    //         $query = "UPDATE $game_table SET enabled = $status WHERE uuid IN ($placeholders)";
    //         $wpdb->query($wpdb->prepare($query, $enabled_games));
    //     }

    //     wp_redirect(wp_get_referer());
    //     exit;
    // }

    // Get Customers by Role
    public function get_customers($role = 'game_customer') {
        global $wpdb;
        // Prepare the SQL query
        $query = $wpdb->prepare(
            "
            SELECT u.*, cb.current_balance AS customer_balance
            FROM {$wpdb->prefix}users AS u
            INNER JOIN {$wpdb->prefix}usermeta AS um ON u.ID = um.user_id
            LEFT JOIN (
                SELECT player_id, current_balance
                FROM {$wpdb->prefix}casino_balance
                WHERE id IN (
                    SELECT MAX(id)
                    FROM {$wpdb->prefix}casino_balance
                    GROUP BY player_id
                )
            ) AS cb ON u.ID = cb.player_id
            WHERE um.meta_key = %s
            AND um.meta_value LIKE %s
            ORDER BY u.user_registered DESC
            ",
            "{$wpdb->prefix}capabilities", "%" . $wpdb->esc_like($role) . "%"
        );
        
        
        $result = $wpdb->get_results($query);


        // Debugging: Log the query
        error_log($query);
    
        // Execute and return results
        return $wpdb->get_results($query);
    }
    public function getCustomerGames() {
        global $wpdb;
    
        // Get the current user
        $current_user = wp_get_current_user();
        
        $user_id = $current_user->ID;
    
        // Prepare the SQL query safely
        $query = $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}casino_customer_play_game WHERE player_id = %d",
            $user_id
        );
        // Debugging: Log the query (optional)
        error_log($query);

        $result = $wpdb->get_results($query);

   
        // Execute and return results
        return $wpdb->get_results($query);
    }
    public function getCustomerBalancyHistory() {
        global $wpdb;
    
        // Get the current user
        $current_user = wp_get_current_user();
        
        $user_id = $current_user->ID;
    
        // Prepare the SQL query safely
        $query = $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}casino_balance WHERE player_id = %d",
            $user_id
        );
        // Debugging: Log the query (optional)
        error_log($query);

        $result = $wpdb->get_results($query);

   
        // Execute and return results
        return $wpdb->get_results($query);
    }


    public function getCustomerGameHistory($id) {
        global $wpdb;
        

       $query = "
            SELECT * FROM {$wpdb->prefix}casino_customer_play_game join {$wpdb->prefix}casino_games on  {$wpdb->prefix}casino_customer_play_game.game_id ={$wpdb->prefix}casino_games.id WHERE player_id = '$id'
        ";

        // // Prepare the SQL query safely
        // $query = $wpdb->prepare(
        //     "SELECT * FROM {$wpdb->prefix}casino_customer_play_game WHERE player_id = %d",
        //     $id
        // );
        // // Debugging: Log the query (optional)
        // error_log($query);

        // Execute and return results
        return $wpdb->get_results($query);
    }

    public function getCustomerTransactionHistory($id) {
        global $wpdb;
           // Prepare the SQL query safely
        $query = $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}casino_balance WHERE player_id = %d",
            $id
        );

        // Debugging: Log the query (optional)
        error_log($query);

        $result = $wpdb->get_results($query); 


   
        // Execute and return results
        return $result;
    }

    public function getCustomerById($id)
    {
        global $wpdb;
           // Prepare the SQL query safely
        $query = $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}casino_balance WHERE player_id = %d",
            $id
        );

        // Debugging: Log the query (optional)
        error_log($query);

        $result = $wpdb->get_results($query); 


   
        // Execute and return results
        return $result;
    }

    // Came Activity

    public function getGameActivity()
    {
        global $wpdb;
        $utils = new Utils();
           // Prepare the SQL query safely
        // Query for 'completed' status
        $query_completed = "SELECT * 
        FROM {$wpdb->prefix}casino_customer_play_game 
        RIGHT JOIN {$wpdb->prefix}casino_games 
        ON {$wpdb->prefix}casino_games.id = {$wpdb->prefix}casino_customer_play_game.game_id 
        WHERE {$wpdb->prefix}casino_customer_play_game.status = 'completed' and {$wpdb->prefix}casino_games.enabled = 1";


        $completed_games = $wpdb->get_results($query_completed);

        // Query for 'started' status
        $query_started = "SELECT * 
        FROM {$wpdb->prefix}casino_customer_play_game 
        JOIN {$wpdb->prefix}casino_games 
        ON {$wpdb->prefix}casino_games.id = {$wpdb->prefix}casino_customer_play_game.game_id 
        WHERE {$wpdb->prefix}casino_customer_play_game.status = 'started'";

        $started_games = $wpdb->get_results($query_started);

        // echo "<pre>";
        // print_r($started_games);
        // echo "</pre>";
        // exit;


        $query_enabled = "SELECT * 
        FROM {$wpdb->prefix}casino_games where enabled = 1";

        $pagination = [];
        $page = isset($_REQUEST['currentPage']) ? max(1, intval($_REQUEST['currentPage'])) : 1;
        $per_page = isset($_REQUEST['per_page']) ? max(1, intval($_REQUEST['per_page'])) : 250;


        if(isset($_GET['currentPage']))
        {
            $query_enabled = $utils->paginate($query_enabled);
            $queryResult = $wpdb->get_results($query_enabled);
        
            $total_pages = ceil(count($queryResult) / $per_page);


            $pagination = [              // Pagination metadata
                'current_page' => $page,
                'per_page' => $per_page,
                'total_records' => count($queryResult),
                'total_pages' => $total_pages,
            ];

        }
        else
        {
            $queryResult = $wpdb->get_results($query_enabled);
            $total_pages = ceil(count($queryResult) / $per_page);

            $pagination = [              // Pagination metadata
                'current_page' => $page,
                'per_page' => $per_page,
                'total_records' => count($queryResult),
                'total_pages' => $total_pages,
            ];
        }

        $page = "game-activity";

        // Return both arrays
        $response = [
        'completed' => $completed_games,
        'started'   => $started_games,
        'enabled'  => $queryResult,
        'pagination' => $pagination
        ];
   
        // Execute and return results
        return  $response;
    }
    public function getGameSessions($id)
    {
        global $wpdb;
      
        $sessions = "SELECT * 
        FROM {$wpdb->prefix}casino_customer_play_game 
        RIGHT JOIN {$wpdb->prefix}casino_games
        ON {$wpdb->prefix}casino_games.id = {$wpdb->prefix}casino_customer_play_game.game_id 
        RIGHT JOIN {$wpdb->prefix}users on {$wpdb->prefix}users.ID = {$wpdb->prefix}casino_customer_play_game.player_id
        WHERE  {$wpdb->prefix}casino_games.enabled = 1 and {$wpdb->prefix}casino_customer_play_game.game_id = '$id' ";

        $sessions = $wpdb->get_results($sessions);

        return  $sessions;
    }

    public function getGameSessionsLogs($id,$session_id,$player_id)
    {
        global $wpdb;

       $sessions = "SELECT * 
        FROM {$wpdb->prefix}casino_customer_play_game 
        JOIN {$wpdb->prefix}casino_customer_played_game_logs 
        ON {$wpdb->prefix}casino_customer_played_game_logs.play_game_id = {$wpdb->prefix}casino_customer_play_game.id
        RIGHT JOIN {$wpdb->prefix}users on {$wpdb->prefix}users.ID = {$wpdb->prefix}casino_customer_play_game.player_id
        where  {$wpdb->prefix}casino_customer_played_game_logs.game_id = '$id' and 
        {$wpdb->prefix}casino_customer_played_game_logs.player_id = '$player_id' and
        {$wpdb->prefix}casino_customer_played_game_logs.session_id = '$session_id'
        ";
        $sessions = $wpdb->get_results($sessions);
        return  $sessions;
    }

    // Ending customer query

    public function getCategoryWiseGames($status = 3) {
        global $wpdb;


        // Define table names
        $game_table = $wpdb->prefix . "casino_games";
        $game_type = $wpdb->prefix . "casino_game_type";
        $game_provider = $wpdb->prefix . "casino_game_provider";
        $game_technology = $wpdb->prefix . "casino_game_technology";
    
        // Start building the main query for games
        $query_game = "SELECT g.*, t.name AS type_name, p.name AS provider_name, tech.name AS technology_name
                       FROM $game_table g
                       LEFT JOIN $game_type t ON g.type = t.id
                       LEFT JOIN $game_provider p ON g.provider = p.id
                       LEFT JOIN $game_technology tech ON g.technology = tech.id";

        if($status != 3)
        {
            $query_game .= " where g.enabled = '$status' ";
        }
        // Initialize an empty array to hold filter conditions
        $conditions = [];


   
        // Apply filters based on request parameters
        if (isset($_REQUEST['type']) && !empty($_REQUEST['type'])) {
            $type = esc_sql($_REQUEST['type']);
            if($type != 'All')
            {
                $conditions[] = "g.type = '$type'";
            }
        }
        if (isset($_REQUEST['provider']) && !empty($_REQUEST['provider'])) {
            $provider = esc_sql($_REQUEST['provider']);
            if($provider != 'All')
            {
                $conditions[] = "g.provider = '$provider'";

            }
        }
        if (isset($_REQUEST['technology']) && !empty($_REQUEST['technology'])) {
            $technology = esc_sql($_REQUEST['technology']);
            if($technology != 'All')
            {
                $conditions[] = "g.technology = '$technology'";
            }
        }
        if (isset($_REQUEST['enabled'])) {
            $enabled = esc_sql($_REQUEST['enabled']);
           
            if($enabled != 'All')
            {
                $conditions[] = "g.enabled = '$enabled'";
            }

            
        }

      
        

     
        // Append conditions to the query
        if (!empty($conditions)) {
            $query_game .= " WHERE " . implode(" AND ", $conditions);
        }


        // Pagination Parameters
        $page = isset($_REQUEST['currentPage']) ? max(1, intval($_REQUEST['currentPage'])) : 1;
        $per_page = isset($_REQUEST['per_page']) ? max(1, intval($_REQUEST['per_page'])) : 250;
        $offset = ($page - 1) * $per_page;
    
        // Add LIMIT and OFFSET to the query
        $query_game .= " LIMIT $per_page OFFSET $offset";
         // Fetch the paginated games
        $games = $wpdb->get_results($query_game);
    
        // Fetch the total number of records (for pagination metadata)
        $total_query = "SELECT COUNT(*) AS total FROM $game_table g";
        if (!empty($conditions)) {
            $total_query .= " WHERE " . implode(" AND ", $conditions);
        }
        $total = $wpdb->get_var($total_query);
    
        // Calculate total pages
        $total_pages = ceil($total / $per_page);
    
        // Fetch all available types, providers, and technologies for filter options
        $types = $wpdb->get_results("SELECT * FROM $game_type");
        $providers = $wpdb->get_results("SELECT * FROM $game_provider");
        $technologies = $wpdb->get_results("SELECT * FROM $game_technology");
    
        // Return all the data: filtered games, filter options, and pagination metadata
        $data = [
            'items' => $games,             // Filtered games
            'type' => $types,              // Available types
            'provider' => $providers,      // Available providers
            'technology' => $technologies, // Available technologies
            'pagination' => [              // Pagination metadata
                'current_page' => $page,
                'per_page' => $per_page,
                'total_records' => $total,
                'total_pages' => $total_pages,
            ],
        ];

        return $data;
    }


    public function getFilteredGames($type, $provider, $technology) {
        global $wpdb;

        // Sanitize the input before directly inserting into the query to avoid SQL injection
        $type = esc_sql($type);
        $provider = esc_sql($provider);
        $technology = esc_sql($technology);

        // Define table names
        $games_table = "{$wpdb->prefix}casino_games"; // Game table
        $type_table = "{$wpdb->prefix}casino_game_type"; // Type table
        $provider_table = "{$wpdb->prefix}casino_game_provider"; // Provider table
        $technology_table = "{$wpdb->prefix}casino_game_technology"; // Technology table

        // Base query with JOIN
        $query = "SELECT g.*, t.name AS type_name, p.name AS provider_name, tech.name AS technology_name
                FROM $games_table g
                LEFT JOIN $type_table t ON g.type = t.id
                LEFT JOIN $provider_table p ON g.provider = p.id
                LEFT JOIN $technology_table tech ON g.technology = tech.id";

        // Add conditions dynamically if values are provided
        $conditions = array();

        // Add condition for 'type' if provided
        if ($type !== 'All' && !empty($type)) {
            $conditions[] = "t.name LIKE '%$type%'";
        }

        // Add condition for 'provider' if provided
        if ($provider !== 'All' && !empty($provider)) {
            $conditions[] = "p.name LIKE '%$provider%'";
        }

        // Add condition for 'technology' if provided
        if ($technology !== 'All' && !empty($technology)) {
            $conditions[] = "tech.name LIKE '%$technology%'";
        }

        // If there are conditions, join them with AND
        if (!empty($conditions)) {
            $query .= " WHERE " . implode(' AND ', $conditions);
        }
        
    
        $results = $wpdb->get_results($query);

        return $results;
    }


    public function getLobbyByGameId($id)
    {
        global $wpdb;
    
        // Define table names
         // Start building the main query for games
        $query_game = 'select * from ' .  $wpdb->prefix . 'casino_game_lobby' . " where local_game_id  = '$id'";

        // Initialize an empty array to hold filter conditions
        $conditions = [];

        // Fetch the filtered games from the database
        $games = $wpdb->get_results($query_game);

    
        return $games;
    }
    
    public function createUpdateProvider($tableName, $name) {
        global $wpdb;
    
        // Check if the record exists
        $query = $wpdb->prepare(
            "SELECT id FROM $tableName WHERE name = %s",
            $name
        );
        $result = $wpdb->get_row($query);
    
        if (!empty($result)) {
            // If record exists, update it
            $wpdb->update(
                $tableName,
                ['name' => $name],  // Values to update
                ['id' => $result->id], // Condition
                ['%s'], // Format for values to update
                ['%d']  // Format for condition
            );
    
            // Return the existing record's ID
            return $result->id;
        } else {
            // If record does not exist, insert a new one
            $wpdb->insert(
                $tableName,
                ['name' => $name],
                ['%s']
            );
    
            // Return the last inserted ID
            return $wpdb->insert_id;
        }
    }

    public function getGameByUid($id,$tableName)
    {
        global $wpdb;
        $query = $wpdb->prepare(
            "SELECT id,uuid FROM $tableName WHERE uuid = %s",  // Searching by uuid
            $id
        );
        
        // Execute the query
        $result = $wpdb->get_results($query);
        return $result;

    }
    public function getLobbyByUid($id,$tableName)
    {
        global $wpdb;
        $query = $wpdb->prepare(
            "SELECT id,uuid FROM $tableName WHERE uuid = %s",  // Searching by uuid
            $id
        );
        
        // Execute the query
        $result = $wpdb->get_results($query);
        return $result;

    }
    
    public function createUpdateGame($tableName, $gameData) {
        global $wpdb;
    
        // Upload main image to WordPress Media and update the URL
        $gameData['image'] = $this->uploadImageToWordPress($gameData['image']);

        print_r($gameData['image']);
        exit;
    
        // Process and upload each image inside the images array
        foreach ($gameData['images'] as &$image) {
            if (isset($image['url'])) {
                $image['url'] = $this->uploadImageToWordPress($image['url']);
            }
        }
        
        // Convert arrays to JSON format
        $images = json_encode($gameData['images']);
        $tags = json_encode($gameData['tags']);
        $related_games = json_encode($gameData['related_games']);
    
        // Prepare data for insertion/update
        $data = [
            'uuid' => $gameData['uuid'],
            'name' => $gameData['name'],
            'image' => $gameData['image'],
            'type' => $gameData['type'],
            'provider' => $gameData['provider'],
            'technology' => $gameData['technology'],
            'has_lobby' => $gameData['has_lobby'],
            'is_mobile' => $gameData['is_mobile'],
            'has_freespins' => $gameData['has_freespins'],
            'has_tables' => isset($gameData['has_tables']) ? $gameData['has_tables'] : 0,
            'images' => $images,
            'tags' => $tags,
            'related_games' => $related_games,
            'freespin_valid_until_full_day' => $gameData['freespin_valid_until_full_day'],
        ];
    
        // Check if game exists
        $result = $this->getGameByUid($gameData['uuid'], $tableName);
    
        // Update or insert
        if (!empty($result)) {
            $wpdb->update($tableName, $data, ['uuid' => $gameData['uuid']], array_fill(0, count($data), '%s'), ['%s']);
        } else {
            $wpdb->insert($tableName, $data, array_fill(0, count($data), '%s'));
        }
    
        // Fetch and return the game ID
        $findGame = $this->getGameByUid($gameData['uuid'], $tableName);
        return $findGame[0]->id;
    }
    
    /**
     * Uploads an image to WordPress Media Library and returns the local URL.
     */
    private function uploadImageToWordPress($image_url) {
        if (empty($image_url)) {
            return '';
        }
    
        // Include WordPress media handling functions
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
    
        // Upload image and get attachment ID
        $attachment_id = media_sideload_image($image_url, 0, null, 'id');
    
        if (is_wp_error($attachment_id)) {
            return $image_url; // Return original URL if upload fails
        }
    
        // Get the image URL from attachment ID
        return wp_get_attachment_url($attachment_id);
    }

    public function createUpdateGameLobby($tableName,$uuid ,$game_id,$lobby) {
        global $wpdb;
 
        // Prepare the SQL query to check if the game exists using the 'uuid'
        $result = $this->getLobbyByUid($uuid,$tableName);
        if(isset($lobby['lobby']))
        {
            foreach($lobby['lobby'] as $lob)
            {
                // Create a single array with all the table data
                $data = [
                    'uuid'                       => $uuid,
                    'local_game_id'              => $game_id,
                    'tableId'                    => isset($lob['tableId'])?$lob['tableId']:"",
                    'limitSetId'                 => isset($lob['limitSetId'])?$lob['limitSetId']:"",
                    'lobbyData'                      => $lob['lobbyData'],
                    'name'                       => $lob['name'],
                    'dealerName'                  => $lob['dealerName'],
                    'dealerAvatar'                => $lob['dealerAvatar'],
                    'isOpen'                 => $lob['isOpen'],
                    'device'                 => isset($lob['device'])?$lob['device']:'',
                    'openTime'             => $lob['openTime'],
                    'closeTime'                => $lob['closeTime'],
                    'technology'                    => 'technology',
                    'limits'                => isset($lob['limits'])?json_encode($lob['limits'],true):""
                ];
            
                // If game already exists, update it
                if (!empty($result)) {
                    // Update the existing game
                    $gameObject = $wpdb->update(
                        $tableName,
                        $data,  // Pass the array directly
                        ['uuid' => $uuid],  // Condition to update by uuid
                        array_fill(0, count($data), '%s'),  // Format for all columns (string)
                        ['%s']  // Format for the where condition (uuid)
                    );
    
                } else {
                    // If game does not exist, insert a new record
                    $gameObject = $wpdb->insert(
                        $tableName,
                        $data,  // Pass the array directly
                        array_fill(0, count($data), '%s')  // Format for all columns (string)
                    );
                }
    
            }
        }
        // Always return 1
        return 1;
    }
    
}

$handler = new DB_Handler();

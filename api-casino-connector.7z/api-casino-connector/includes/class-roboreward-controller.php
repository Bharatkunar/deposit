<?php
class RoboReward {
    private $jwtToken;
    private $username;
    private $password;
    private $roboRewardToken;

    public function __construct() {
        $this->roboRewardToken = get_option('casino_roboreward_token');
        $this->username = get_option('casino_username');
        $this->password = get_option('casino_password');
        $this->jwtToken = get_option('jwtToken');
        // add_shortcode('casino_play_game_page', array($this, 'casino_play_game_shortcode'));
    }

    public function makeApiRequest($endpoint = '', $action='POST', $data = []) {   
        $url = 'https://beta.roborewards.net/api/' . $endpoint;
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => $action,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Accept: application/json',
                "Authorization: Bearer $this->jwtToken",
                "Username: $this->username"
            ),
        ));

        // if($endpoint == 'EndUserProfile/GetTransferPoint?webFormId=2f62adb8-284a-4182-9e3c-6198820c598e&rpId=083eb6ce-c029-4086-869e-1175ce7c614d&contactId=8d56bb52-cdc5-475d-a213-b952a0929b17')
        // {
        //     print_r($body);
        //     echo $this->jwtToken;
        //     exit;
        // }

        // echo "Authorization: Bearer $this->jwtToken";
        // exit;

        $response = curl_exec($curl);
        $response = json_decode($response, true);
 
        if ($response['statusCode'] == 401) {
            $data = array(
                'rewardProgramToken' => $this->roboRewardToken,
                'username' => $this->username,
                'password' => $this->password
            );

  

            $response = $this->generateAccessToken($data);

            if (!empty($response['token'])) {
                $this->jwtToken = $response['token'];
                update_option('jwtToken', $this->jwtToken);
                return $this->makeApiRequest($endpoint, $action, $data);
            }
        }

        return $response;
    }

    public function generateAccessToken($data) {
        $response = $this->makeApiRequest('JWTAuthenticationWordPress/WordPressLogin', 'POST', $data);
        if (!empty($response['token'])) {
            return $response;
        } else {
            error_log('Token generation failed.');
            return null;
        }
    }

    public function transferPoints($data) {
        return $this->makeApiRequest('EndUserProfile/GetTransferPoint?webFormId=2f62adb8-284a-4182-9e3c-6198820c598e&rpId=083eb6ce-c029-4086-869e-1175ce7c614d&contactId=8d56bb52-cdc5-475d-a213-b952a0929b17', 'GET', $data);
    } 
}
?>

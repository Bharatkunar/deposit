<?php

class Casino_Settings_Controller {

    public $roboreward;
  
    public function __construct() {
        // Hook into init to handle form submissions
        add_action('admin_post_nopriv_casino_register_settings', array($this, 'casino_register_settings'));
        add_action('admin_post_casino_register_settings', array($this, 'casino_register_settings'));
    }
    
    // Handle Registration Form Submission
    public function casino_register_settings() {
        global $wpdb;

        $server_ip = $_SERVER['SERVER_ADDR']; // For server IP
        // Your base URL (can be dynamic depending on plugin settings)
        $base_url = get_site_url();
        $call_back_url = get_option('casino_callback_url');
        // Prepare the data for the API request
        $data = array(
            'base_url' => $base_url,
            'ip_address' => get_client_ip(),
            'callback_url' => $call_back_url, // Initially empty; will be updated later
        );

        // Enter Reward token


        if (isset($_POST['casino_roboreward_token']) && isset($_POST['casino_username']) && isset($_POST['casino_password'])) {
            
            global $wpdb;


            $roboreward = new LoyaltyApiHanlder();
            $reward_table = $wpdb->prefix . 'casino_roborewards_token';
        
            $casino_roboreward_token = $_POST['casino_roboreward_token'];
            $casino_rpID = $_POST['casino_rpID'];
            $casino_contactListID = $_POST['casino_contactListID'];
            $casino_username = $_POST['casino_username'];
            $casino_password = $_POST['casino_password'];
            $loyalty_callback = $_POST['loyalty_callback'];

            // Store Information in jwtToken

            update_option('casino_roboreward_token',$_POST['casino_roboreward_token']);
            update_option('casino_rpID',$_POST['casino_rpID']);
            update_option('casino_contactListID',$_POST['casino_contactListID']);
            update_option('casino_username',$_POST['casino_username']);
            update_option('casino_password',$_POST['casino_password']);
            update_option('WEBFROMID',$_POST['WEBFROMID']);


            // Update Static Tracking IDS
            // update_option('webFormId','2f62adb8-284a-4182-9e3c-6198820c598e');
            // update_option('rpId','083eb6ce-c029-4086-869e-1175ce7c614d');
            update_option('contactId','8d56bb52-cdc5-475d-a213-b952a0929b17');
            
        
            $rewardData = array(
                'rewardProgramToken' => $casino_roboreward_token,
                'rpId' => $casino_rpID,
                'contactListID' => $casino_contactListID,
                'username' => $casino_username,
                'password' => $casino_password
            );


        
            $response_data = $roboreward->generateAccessToken($rewardData);


            // // // $response_data = json_decode($response, true); // Decode JSON response
            // echo "<pre>";
            // print_r($response_data);
            // echo "</pre>";
            // exit;
            $token = $response_data['token'] ?? null; // Safely get the token
            

            if ($token) {
                // Check if record exists
                $existing_record = $wpdb->get_row(
                    $wpdb->prepare("SELECT * FROM $reward_table WHERE username = %s", $casino_username)
                );
        
                $data = array(
                    'rewardProgramToken' => $casino_roboreward_token,
                    'username' => $casino_username,
                    'password' => $casino_password,
                    'jwtToken' => $token,
                    'loyalty_callback' => $loyalty_callback,
                    'updated_at' => current_time('mysql')
                );
        
                if ($existing_record) {
                    // Update existing record
                    $wpdb->update(
                        $reward_table,
                        $data,
                        array('id' => $existing_record->id)
                    );
                } else {
                    // Insert new record
                    $data['created_at'] = current_time('mysql');
                    $wpdb->insert($reward_table, $data);
                }

                update_option('jwtToken',$token);

        
                echo 'Data successfully saved!';
            } else {
                echo 'Failed to authenticate!';
            }

        }
        

    
        $response = vendor_registration_api_request($data);
        if ($response && isset($response['status']) && $response['status'] == 'success') {
            // Store the vendor ID or data in the plugin options or database
            update_option('vendor_id', $response['data']['id']); // Save vendor ID
            update_option('casino_merchant_id',$response['data']['casino_merchant_id']);
            update_option('casino_merchant_key',$response['data']['casino_merchant_key']);
            update_option('casino_base_url',$response['data']['casino_base_url']);
            // Optionally store other data like base_url, callback_url, etc.
            update_option('vendor_data', $response['data']);
        } else {
            // Handle the error
            error_log('Vendor registration failed: ' . json_encode($response));
        }

        $redirect_url = add_query_arg('message', 'Settings Updated', wp_get_referer());
        wp_redirect($redirect_url);
    }

    // 

}

$Casino_Settings_Controller = new Casino_Settings_Controller();

<?php
if (!defined('ABSPATH')) exit;

class Offers_Sync {
    private $loyalty_my_offer;
    private $loyalty_callback;

 

    public function __construct() {
        $this->loyalty_callback = new Loyalty_CallBack_Handler();
    }

    public static function sync($user_id) {
        $instance = new self();
        $user = get_user_by('ID', $user_id);
        $contact_id = get_user_meta($user_id, 'contact_id', true);
    
        if (!$user || !$contact_id) {
            loyalty_plugin_log("Missing user or contact_id for user ID: $user_id", 'Offers_Sync');
            return;
        }
    
        loyalty_plugin_log("Sync started for user: {$user->user_email}, Contact ID: $contact_id", 'Offers_Sync');
    
        try {
            $offers = self::fetch_offers_from_api($user);
            // Lets fetch all Records from the handlers

            $callback = $instance->loyalty_callback->syncAllApis();
       
            if (empty($offers)) {
                loyalty_log_api_event($user_id, 'my_offers_sync', 'login', 'success', 'No offers returned.');
                loyalty_plugin_log("No offers returned for user {$user->ID}", 'Offers_Sync');
                return;
            }

            
    
            global $wpdb;
            $loyalty_my_offer = $wpdb->prefix . 'loyalty_my_offer';


            $json_data = wp_json_encode($offers);
    
            $existing_id = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM $loyalty_my_offer WHERE user_id = %d AND contact_id = %s",
                $user_id,
                $contact_id
            ));

    
            if ($existing_id) {
                $wpdb->update(
                    $loyalty_my_offer,
                    ['data' => $json_data],
                    ['id' => $existing_id]
                );
                loyalty_plugin_log("Offers updated for user {$user->ID} in loyalty_my_offer", 'Offers_Sync');
            } else {
                $wpdb->insert(
                    $loyalty_my_offer,
                    [
                        'data'       => $json_data,
                        'user_id'    => $user_id,
                        'contact_id' => $contact_id
                    ]
                );
                loyalty_plugin_log("Offers inserted for user {$user->ID} in loyalty_my_offer", 'Offers_Sync');
            }

      
    
            loyalty_log_api_event($user_id, 'my_offers_sync', 'login', 'success', "Offers processed and stored.");
            

            self::create_coupons_from_offers($user_id);
    
        } catch (Exception $e) {
            loyalty_log_api_event($user_id, 'my_offers_sync', 'login', 'failed', $e->getMessage());
            loyalty_plugin_log("Sync failed for user {$user->ID}: " . $e->getMessage(), 'Offers_Sync');
        }
    }
    

    private static function fetch_offers_from_api($user) {
        $user_id = $user->ID;
 
        if (!$user) {
            loyalty_plugin_log("User not found for ID: $user_id", 'Offers_Sync');
            return;
        }
        $contact_id = get_user_meta($user_id, 'contact_id', true);

        if (empty($contact_id)) {
            loyalty_plugin_log("No contact-id found for user {$user_id}", 'Offers_Sync');
            return [];
        }

        try {
            $handler = new LoyaltyApiHanlder(); // Your custom API class
            $offers = $handler->syncContactOffers($contact_id);

   
            if (!is_array($offers)) {
                loyalty_plugin_log("Invalid offers response for contact-id: $contact_id", 'Offers_Sync');
                return [];
            }



            return $offers;
        } catch (Exception $e) {
            loyalty_plugin_log("API fetch failed for contact-id $contact_id: " . $e->getMessage(), 'Offers_Sync');
            return [];
        }
    }

    public static function create_coupons_from_offers($user_id) {
        global $wpdb;
    
        $contact_id = get_user_meta($user_id, 'contact_id', true);
        if (!$contact_id) {
            loyalty_plugin_log("No contact_id found for user ID: $user_id", 'Coupon_Sync');
            return;
        }
    
        $table = $wpdb->prefix . 'loyalty_my_offer';
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT data FROM $table WHERE user_id = %d AND contact_id = %s",
            $user_id,
            $contact_id
        ));

     
        if (!$row || empty($row->data)) {
            loyalty_plugin_log("No offer data found for user $user_id, contact $contact_id", 'Coupon_Sync');
            return;
        }


    
        $offers = json_decode($row->data, true);

        if (!is_array($offers)) {
            loyalty_plugin_log("Invalid offer JSON for user $user_id", 'Coupon_Sync');
            return;
        }
    
        foreach ($offers as $offer) {
            if (empty($offer['offerID']) || empty($offer['offerTitle'])) {
                loyalty_plugin_log("Skipping offer due to missing ID or Title", 'Coupon_Sync');
                continue;
            }
    
            $coupon_code = sanitize_title($offer['offerTitle']);
    
            // 🛑 Skip if coupon already exists
            if (get_page_by_title($coupon_code, OBJECT, 'shop_coupon')) {
                loyalty_plugin_log("Coupon already exists: $coupon_code", 'Coupon_Sync');
                continue;
            }
    
            // 🧾 Create WooCommerce coupon post
            $coupon = [
                'post_title'   => $coupon_code,
                'post_name'    => $coupon_code,
                'post_content' => $offer['offerDescription'] ?? '',
                'post_status'  => 'publish',
                'post_type'    => 'shop_coupon',
            ];
    
            $coupon_id = wp_insert_post($coupon);
    
            if (is_wp_error($coupon_id)) {
                loyalty_plugin_log("Failed to create coupon for offer {$offer['offerID']}: " . $coupon_id->get_error_message(), 'Coupon_Sync');
                continue;
            }
    
            // 💰 Discount logic
            $discount = floatval($offer['offerDiscount'] ?? 0);
            if ($discount <= 0) $discount = 100;
    
            update_post_meta($coupon_id, 'discount_type', $offer['offerDiscountType'] ?: 'percent');
            update_post_meta($coupon_id, 'coupon_amount', $discount);
            update_post_meta($coupon_id, 'individual_use', 'yes');
            update_post_meta($coupon_id, 'usage_limit', 1);
            update_post_meta($coupon_id, 'usage_limit_per_user', 1);
            update_post_meta($coupon_id, 'free_shipping', 'no');
    
            // 🔐 Loyalty-specific metadata
            update_post_meta($coupon_id, '_loyalty_user_id', $user_id);
            update_post_meta($coupon_id, '_loyalty_contact_id', $contact_id);
            update_post_meta($coupon_id, '_loyalty_offer_id', $offer['offerID']);
    
            // Smart Coupons: restrict to user email
            $user = get_user_by('ID', $user_id);
            if ($user && is_email($user->user_email)) {
                update_post_meta($coupon_id, 'customer_email', [$user->user_email]);
            }
    
            loyalty_plugin_log("Coupon created: $coupon_code for user {$user->user_email}", 'Coupon_Sync');
        }
    }
    
}

// 🔄 API Logs to Database (optional)
function loyalty_log_api_event($user_id, $action, $source = 'unknown', $status = 'success', $message = '') {
    global $wpdb;
    // Uncomment and use if logging to DB is needed
    // $table = $wpdb->prefix . 'loyalty_woocommerce_loyalty_api_logs';
    // $wpdb->insert($table, [
    //     'user_id' => $user_id,
    //     'action' => $action,
    //     'source' => $source,
    //     'status' => $status,
    //     'message' => $message,
    // ]);
}

// 🪵 Logs to plugin-specific file
function loyalty_plugin_log($message, $context = '') {
    $log_dir = plugin_dir_path(__FILE__) . '../../';
    $log_file = $log_dir . 'loyalty-plugin.log';

    $log_entry = '[' . date('Y-m-d H:i:s') . ']';
    if (!empty($context)) {
        $log_entry .= " [$context]";
    }
    $log_entry .= " $message" . PHP_EOL;

    file_put_contents($log_file, $log_entry, FILE_APPEND);
}




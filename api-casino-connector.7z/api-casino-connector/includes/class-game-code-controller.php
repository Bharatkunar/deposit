<?php
class Game_Short_Code_Hanlder {
    public $gameController;
    public function __construct() {
        // Register shortcodes
        add_shortcode('casino_all_active_games', array($this, 'casino_all_games_shortcode'));
        add_shortcode('casino_all_active_games_2', array($this, 'casino_all_games_2_shortcode'));
        
        // Add custom query vars for pagination
        add_filter('query_vars', array($this, 'add_query_vars_filter'));

        // Add rewrite rules for custom pagination URL structure
        add_action('init', array($this, 'custom_rewrite_rules'));


        $this->gameController = new Game_Controller();

    }

    // Handle adding custom query vars for pagination
    function add_query_vars_filter($vars) {
        $vars[] = 'page_num'; // Register the 'page_num' query var for pagination
        return $vars;
    }

// Custom rewrite rules to change URL structure (e.g., /page/2/ instead of ?page=2)
     // Custom rewrite rules to change URL structure (e.g., /page/2/ instead of ?page=2)
     function custom_rewrite_rules() {
        add_rewrite_rule('^casino/page/([0-9]+)/?', 'index.php?page_num=$matches[1]', 'top');
    }

    // Get Filtered Games
    public function getFilteredGames($filters = [], $offset = 0, $limit = 250) {
        global $wpdb;

      
    
        $game_table = $wpdb->prefix . "casino_games";
        $game_type = $wpdb->prefix . "casino_game_type";
        $game_provider = $wpdb->prefix . "casino_game_provider";
        $game_technology = $wpdb->prefix . "casino_game_technology";
        $game_lobby = $wpdb->prefix . "casino_game_lobby";
    
        $query_game = "SELECT 
                        g.*, 
                        COUNT(l.id) AS totalLobby, /* Count of lobbies for each game */
                        t.name AS type_name, 
                        p.name AS provider_name, 
                        tech.name AS technology_name
                    FROM $game_table g
                    LEFT JOIN $game_type t ON g.type = t.id
                    LEFT JOIN $game_provider p ON g.provider = p.id
                    LEFT JOIN $game_technology tech ON g.technology = tech.id
                    LEFT JOIN $game_lobby l ON g.id = l.local_game_id";
    
        $where_clauses = ["g.enabled = 1"]; // Start with base condition
        $params = [];
    
        // Add filters dynamically
        if (!empty($filters['type'])) {
            // $where_clauses[] = "g.name = %s";

            $type_in = $filters['type']; // Convert to integer for security
            $params[] = $type_in;

            $where_clauses[] = "g.type IN (%s)";

        }
        if (!empty($filters['provider'])) {
            // $where_clauses[] = "p.name = %s";

            $provider_in = $filters['provider']; // Convert to integer for security
            $params[] = $provider_in;

            $where_clauses[] = "g.provider IN (%s)";
        }
        if (!empty($filters['technology'])) {
            // $where_clauses[] = "tech.name = %s";
            $technology_in = $filters['technology']; // Convert to integer for security
            $params[] = $technology_in;

            $where_clauses[] = "g.technology IN (%s)";
        }
    
        // Add WHERE clause if there are filters
        if (!empty($where_clauses)) {
            $query_game .= " WHERE " . implode(" AND ", $where_clauses);
        }


        // Add GROUP BY clause
        $query_game .= " GROUP BY 
                        g.id, g.name, g.type, g.provider, g.technology, 
                        t.name, p.name, tech.name";

    
        // Add LIMIT and OFFSET
        $limit = isset($filters['games']) ? absint($filters['games']) : 250;
        $offset = isset($offset) ? absint($offset) : 0;
    
        $query_game .= " LIMIT %d OFFSET %d";
        $params[] = $limit;
        $params[] = $offset;


        // echo "<br>";
        // echo "<br>";
        // echo "<br>";
        // echo "<br>";
        // echo $query_game;
    
    
        // Prepare and execute the query
        $prepared_query = $wpdb->prepare($query_game, $params);
        $results = $wpdb->get_results($prepared_query);

        // echo "<pre>";
        // print_r($results);
        // echo "</pre>";
        // exit;
    
        // Return the results
        return $results;
    }
    

    /**
     * The shortcode that displays all active games, with pagination and filtering.
     */
    
    public function casino_all_games_shortcode($atts) {
        // Extract attributes with default values
        $atts = shortcode_atts(
            [
                'type' => 'All',
                'provider' => 'All',
                'technology' => 'All',
                'games'      => 'All'
            ],
            $atts
        );
    
        // Get the current page from the URL (use the 'page_num' query var)
        $current_page = get_query_var('page_num') ? max(1, intval(get_query_var('page_num'))) : 1;
        $limit = 10; // Number of records per page
        $offset = ($current_page - 1) * $limit;
    
        // Set up filters for the query
        $filters = [];
        if ($atts['type'] !== 'All') {
            $filters['type'] = $atts['type'];
        }
        if ($atts['provider'] !== 'All') {
            $filters['provider'] = $atts['provider'];
        }
        if ($atts['technology'] !== 'All') {
            $filters['technology'] = $atts['technology'];
        }
        if ($atts['games'] !== 'All') {
            $filters['games'] = $atts['games'];
        }

   
    
        $games = $this->getFilteredGames($filters, $offset, $limit);
    
        // // Output HTML
        ob_start();
        // // if (!empty($games)) {
        // //     echo '<table border="1" class="wp-list-table widefat fixed striped">';
        // //     echo '<thead>
        // //             <tr>
        // //                 <th>Name</th>
        // //                 <th>Type</th>
        // //                 <th>Provider</th>
        // //                 <th>Technology</th>
        // //             </tr>
        // //           </thead>';
        // //     echo '<tbody>';
        // //     foreach ($games as $game) {
        // //         echo '<tr>';
        // //         echo '<td>' . esc_html($game->name) . '</td>';
        // //         echo '<td>' . esc_html($game->type_name) . '</td>';
        // //         echo '<td>' . esc_html($game->provider_name) . '</td>';
        // //         echo '<td>' . esc_html($game->technology_name) . '</td>';
        // //         echo '</tr>';
        // //     }
        // //     echo '</tbody>';
        // //     echo '</table>';
    
        // //     // Pagination Links
        // //     $total_games = 250; // Replace with the actual total number of games for pagination calculation
        // //     $total_pages = ceil($total_games / $limit);
    
        // //     echo '<div class="pagination">';
        // //     if ($current_page > 1) {
        // //         echo '<a href="' . home_url('/page/test/' . ($current_page - 1) . '/') . '" class="prev">Previous</a>';
        // //     }
        // //     if ($current_page < $total_pages) {
        // //         echo '<a href="' . home_url('/page/test/' . ($current_page + 1) . '/') . '" class="next">Next</a>';
        // //     }
        // //     echo '</div>';
        // // } else {
        // //     echo '<p>No games found for the selected filters.</p>';
        // // }
        include plugin_dir_path(__FILE__) . '../public/views/game/index.php';

        return ob_get_clean();
    }
    
    
    public function casino_all_games_2_shortcode($atts) {
        // Extract attributes with default values
        $atts = shortcode_atts(
            [
                'type' => 'All',
                'provider' => 'All',
                'technology' => 'All',
                'games'      => 25,
                'numb_of_columns' => $atts['cols'],
                'numb_of_rows' => $atts['rows'],
                "show_nav" => $atts['use_slider'],
                "autoplay" => $atts['slider_type_auto'],
                "live"     => $atts['live'],
                "title"    => $atts['title']
            ],
            $atts
        );



        // Get the current page from the URL (use the 'page_num' query var)
        $current_page = get_query_var('page_num') ? max(1, intval(get_query_var('page_num'))) : 1;
        $limit = 10; // Number of records per page
        $offset = ($current_page - 1) * $limit;
    
        // Set up filters for the query
        $filters = [];
        if ($atts['type'] !== 'All') {
            $filters['type'] = $atts['type'];
        }
        if ($atts['provider'] !== 'All') {
            $filters['provider'] = $atts['provider'];
        }
        if ($atts['technology'] !== 'All') {
            $filters['technology'] = $atts['technology'];
        }
        if ($atts['games']) {
            $filters['games'] = $atts['games'];
        }
        if ($atts['numb_of_columns']) {
            $filters['numb_of_columns'] = $atts['numb_of_columns'];
        }
        if (isset($atts['live'])) {
            $filters['live'] = $atts['live'];
        }
        if (isset($atts['title'])) {
            $filters['title'] = $atts['title'];
        }
        if (isset($atts['numb_of_rows'])) {
            $filters['numb_of_rows'] = $atts['numb_of_rows'];
        }
        
        
        // echo "<pre>";
        // print_r($filters);
        // echo "</pre>";
        // exit;

        // Fetch games with filters
        $games = $this->gameController->getFilteredGames($filters, $offset, $atts['games']);
        $num_of_rows = max(1, intval($atts['numb_of_rows'])); // Ensure at least 1 row
        $numb_of_columns = max(1, intval($atts['numb_of_columns'])); // Ensure at least 1 column



        // Calculate total number of games
        $total_games = count($games);

        // Debugging: Output total games and number of rows/columns
        // echo "<br><br>Games: $total_games<br>";
        // echo "Rows & Columns: $num_of_rows, $numb_of_columns<br>";

        // Calculate games per row, ensuring at least 1 game per row
        $games_per_row = max(1, ceil($total_games / $num_of_rows));

        // Initialize shortcode content
        $shortcode_content = '<div id="spinner"></div>';
        $shortcode_content .= '<div class="shortcode_div">';

        // Divide games into rows
        $rows = $total_games > 0 ? array_chunk($games, $games_per_row) : [];

        
        foreach ($rows as $row_index => $row) {
            $columns_in_this_row = $atts['show_nav'] == 'yes' ? max(6, min(count($row), $numb_of_columns)):count($row); // Ensure at least 6 columns, but not more than specified number
            $autoplay = $atts['autoplay']?'yes':'no';
            $show_nav = $atts['show_nav']?'yes':'no';
            $shortcode_content .= '[fusion_images class="my-class2" columns="' . esc_attr($columns_in_this_row) . '" show_nav="'.$show_nav.'" autoplay="'.$autoplay.'"]';
        
            $counter = 1; // Counter for the images
            foreach ($row as $game) {
                $id = $game->id;
                $uuid = $game->uuid;
                $name = $game->name;
                $image = $game->image;
        
                $shortcode_content .= '[fusion_image link="#" image_id="slider' . $counter . '" class="test' . $game->id . '" image="' . esc_url($image) . '?id=' . $uuid . '&local_id=' . $id . '&game=' . $name . '" alt="' . esc_attr($name) . '" /]';
                $counter++;
            }
        
            $shortcode_content .= '[/fusion_images]' ;
        }
        $shortcode_content .="</div>";
        // Return the processed shortcode output
        return do_shortcode($shortcode_content);
       
    }
}

// Initialize the handler
new Game_Short_Code_Hanlder();

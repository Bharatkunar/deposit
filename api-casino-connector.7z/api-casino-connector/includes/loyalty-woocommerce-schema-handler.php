<?php
class Loyalty_Woocommerce_Schema_handler {

    public function create_or_update_tables() {
        global $wpdb;

        // Define plugin version
        $current_version = get_option('casino_plugin_version', '1.1');

        // Check if an update is needed
        $this->create_tables();
        $this->add_user_meta_fields(); // Add user meta fields
        update_option('casino_plugin_version', '1.2');
    }

    // Method to handle schema updates
    private function create_tables() {
        global $wpdb;

        // Get charset collate
        $charset_collate = $wpdb->get_charset_collate();

        // Define the table schemas
        $tables = [
            'loyalty_woocommerce_orders' => $this->get_loyalty_woocommerce_orders_schema($charset_collate),
            'loyalty_woocommerce_orders_line_items' => $this->get_woocommerce_orders_line_items_schema($charset_collate),
            'loyalty_woocommerce_orders_payment' => $this->get_woocommerce_orders_payment_schema($charset_collate),
            'loyalty_woocommerce_loyalty_user_offers' => $this->get_loyalty_woocommerce_loyalty_user_offers_schema($charset_collate),
            'loyalty_woocommerce_loyalty_api_logs' => $this->get_loyalty_api_logs_schema($charset_collate),
            'loyalty_woocommerce_order_logs' => $this->get_woocommerce_order_logs_schema($charset_collate),
        ];

        // Execute dbDelta for each table
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        foreach ($tables as $table_name => $schema) {
            $full_table_name = $wpdb->prefix . $table_name;
            $sql = str_replace('{table_name}', $full_table_name, $schema);
            dbDelta($sql);
        }
    }

    // ✅ Add Custom Fields in usermeta (for Loyalty Integration)
    private function add_user_meta_fields() {
        $users = get_users();

        foreach ($users as $user) {
            if (!get_user_meta($user->ID,   'loyalty_member_id', true)) {
                update_user_meta($user->ID, 'loyalty_member_id', '');
                update_user_meta($user->ID, 'loyalty_points', 0);
                update_user_meta($user->ID, 'loyalty_last_sync', current_time('mysql'));
                update_user_meta($user->ID, 'loyalty_status', 'active');
            }
        }

        $products = get_posts([
            'post_type'   => 'product',
            'numberposts' => -1
        ]);
        
        foreach ($products as $product) {
            if (!get_post_meta($product->ID, 'loyalty_eligible', true)) {
                update_post_meta($product->ID, 'loyalty_eligible', 1); // Default eligible
                update_post_meta($product->ID, 'loyalty_points_earned', 0);
                update_post_meta($product->ID, 'loyalty_discount_amount', 0.00);
                update_post_meta($product->ID, 'loyalty_discount_percentage', 0.00);
                update_post_meta($product->ID, 'loyalty_offer_id', '');
                update_post_meta($product->ID, 'loyalty_excluded', 0);
            }
        }
    }

    private function get_loyalty_woocommerce_orders_schema($charset_collate) {
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            woo_order_id INT NOT NULL, 
            data LONGTEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }

    private function get_woocommerce_orders_line_items_schema($charset_collate) {
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            woo_order_id INT NOT NULL, 
            woo_order_line_id INT NOT NULL,
            local_order_id INT NOT NULL,
            data LONGTEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }

    private function get_woocommerce_orders_payment_schema($charset_collate) {
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            woo_order_id INT NOT NULL, 
            woo_order_line_id INT NOT NULL,
            local_order_id INT NOT NULL,
            data LONGTEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }

    private function get_loyalty_woocommerce_loyalty_user_offers_schema($charset_collate) {
        return "CREATE TABLE IF NOT EXISTS {table_name} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            offer_id VARCHAR(100) NOT NULL,
            coupon_code VARCHAR(100) NOT NULL,
            
            offer_title VARCHAR(255) DEFAULT NULL,
            offer_description TEXT DEFAULT NULL,
            offer_discount DECIMAL(10,2) DEFAULT 0,
            offer_discount_type VARCHAR(50) DEFAULT NULL,
            offer_image_url TEXT DEFAULT NULL,
            offer_barcode VARCHAR(100) DEFAULT NULL,
            offer_expires_option VARCHAR(20) DEFAULT NULL,
            offer_expires_type VARCHAR(20) DEFAULT NULL,
            offer_expires_at DATETIME DEFAULT NULL,
            offer_point_value DECIMAL(10,2) DEFAULT 0,
    
            data_json LONGTEXT NULL,
            is_coupon_created BOOLEAN DEFAULT FALSE,
            coupon_id BIGINT UNSIGNED DEFAULT NULL,
    
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
            PRIMARY KEY (id),
            UNIQUE KEY user_offer (user_id, offer_id)
        ) $charset_collate;";
    }
    
    private function get_loyalty_api_logs_schema( $charset_collate) {
        return "CREATE TABLE IF NOT EXISTS {table_name} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED DEFAULT NULL,
            action VARCHAR(100) NOT NULL,
            source VARCHAR(50) DEFAULT 'unknown',
            status VARCHAR(20) DEFAULT 'success',
            message TEXT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_user_action (user_id, action)
        ) $charset_collate;";
    }

    
    
    private function get_woocommerce_order_logs_schema($charset_collate) {
        return "CREATE TABLE IF NOT EXISTS {table_name} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED DEFAULT NULL,
            action VARCHAR(100) NOT NULL,
            source VARCHAR(50) DEFAULT 'unknown',
            status VARCHAR(20) DEFAULT 'success',
            message LONGTEXT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_user_action (user_id, action)
        ) $charset_collate;";
    }
    
}

// Instantiate Schema Handler
$schemaHandler = new Loyalty_Woocommerce_Schema_handler();
register_activation_hook(__FILE__, array($schemaHandler, 'create_or_update_tables'));

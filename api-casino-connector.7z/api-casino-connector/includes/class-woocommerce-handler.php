<?php

class Woocommerce_Handler {
    private static $instance = null;

    public static function get_instance() {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct()
    {
        add_action('wp_ajax_handle_woocommerce_keys', array($this, 'handle_woocommerce_keys'));
        add_action('wp_ajax_handle_woocommerce_keys', array($this, 'handle_woocommerce_keys'));
    }

    public function handle_woocommerce_keys()
    {
        if (!function_exists('wc')) {
            wp_send_json_error(['message' => 'WooCommerce is not installed!']);
            wp_die(); // Ensure the script stops
        }

        $user_id = get_current_user_id();
        
        if (!$user_id) {
            wp_send_json_error(['message' => 'User not authenticated!']);
            wp_die();
        }

        try {
            $consumer_key    = 'ck_' . wp_generate_password(40, false);
            $consumer_secret = 'cs_' . wp_generate_password(40, false);

            if (!$consumer_key || !$consumer_secret) {
                throw new Exception('Failed to generate API keys');
            }

            // Store the keys
            update_option('myplugin_api_key', $consumer_key);
            update_option('myplugin_api_secret', $consumer_secret);

            // Return success response
            wp_send_json_success([
                'consumer_key'    => $consumer_key,
                'consumer_secret' => $consumer_secret,
            ]);

        } catch (Exception $e) {
            error_log('WooCommerce API Key Error: ' . $e->getMessage());
            wp_send_json_error(['message' => $e->getMessage()]);
        }

        wp_die();
    }



    // Rest Apis For Loyalty Program



}

// Initialize the CronJob handler
$loyaltyObject = Woocommerce_Handler::get_instance();
?>

<?php
class casino_Dashboard_Handler {

    // Register Shortcodes
    public function register_dashboard_shortcodes() {
        add_shortcode('casino_dashboard_page', array($this, 'casino_dashboard_page_shortcode'));
        add_shortcode('casino_all_games', array($this, 'casino_all_games_shortcode'));
        add_shortcode('casino_orders', array($this, 'casino_orders_shortcode'));
        add_shortcode('casino_settings', array($this, 'casino_settings_shortcode'));
        add_action('init', array($this, 'add_custom_dashboard_endpoints'));
        add_filter('query_vars', array($this, 'add_query_vars'));
        add_action('template_redirect', array($this, 'load_dashboard_endpoint_content'));
        add_action('init', array($this, 'add_custom_rewrite_rules')); // Add your rewrite rules
    }

    public function add_custom_rewrite_rules() {
        add_rewrite_rule(
            '^dashboard/([a-zA-Z0-9_-]+)/?$',
            'index.php?pagename=dashboard&slug=$matches[1]',
            'top'
        );
        flush_rewrite_rules();
    }

    public function add_query_vars($vars) {
        $vars[] = 'slug';  // Capture the part after '/dashboard/'
        return $vars;
    }

    public function add_custom_dashboard_endpoints() {
        add_rewrite_endpoint('all-games', EP_ROOT | EP_PAGES);
        add_rewrite_endpoint('orders', EP_ROOT | EP_PAGES);
        add_rewrite_endpoint('settings', EP_ROOT | EP_PAGES);
    }

    // Handle Dashboard Main Page
    public function casino_dashboard_page_shortcode() {
        global $wp_query;
        ob_start();

        $customer = new CustomerController();
    
        include plugin_dir_path(__FILE__) . '../public/views/dashboard/partials2/header.php';
              // Get the slug from the query vars (e.g., all-games, orders, settings)
        $slug = isset($wp_query->query_vars['slug'])?$wp_query->query_vars['slug']:'dashboard';
        
        if($slug == 'all-games')
              {
                  $api = new DB_Handler();
                  $games = $api->getCustomerGames(); // Fetch games data
                  include plugin_dir_path(__FILE__) . '../public/views/dashboard/games/index.php';
              }
              elseif($slug == 'balance-history')
              {
                  $api = new DB_Handler();
                  $games = $api->getCustomerBalancyHistory(); // Fetch games data
         
                  include plugin_dir_path(__FILE__) . '../public/views/dashboard/games/balance_history.php'; 
              }
              elseif($slug == 'dashboard')
              {
                $dasboard = $customer->customerDashboard();
       
                include plugin_dir_path(__FILE__) . '../public/views/dashboard/dashboard.php';
              }
        include plugin_dir_path(__FILE__) . '../public/views/dashboard/partials2/footer.php';
        return ob_get_clean();
    }

    // Handle All Games Section
    public function casino_all_games_shortcode() {
        ob_start();
        include plugin_dir_path(__FILE__) . '../public/views/dashboard/games/index.php';
        return ob_get_clean();
    }

    // Handle Orders Section
    public function casino_orders_shortcode() {
        ob_start();
        include plugin_dir_path(__FILE__) . 'views/dashboard/dashboard-orders.php';
        return ob_get_clean();
    }

    // Handle Settings Section
    public function casino_settings_shortcode() {
        ob_start();
        include plugin_dir_path(__FILE__) . 'views/dashboard/dashboard-settings.php';
        return ob_get_clean();
    }

    // Load Endpoint Content based on the current page and slug
    public function load_dashboard_endpoint_content() {
        global $wp_query;

    }

    // Initialize Handler
    public function init() {
        $this->register_dashboard_shortcodes();
    }
}

// Instantiate and initialize the handler class
$casino_dashboard_handler = new casino_Dashboard_Handler();
$casino_dashboard_handler->init();





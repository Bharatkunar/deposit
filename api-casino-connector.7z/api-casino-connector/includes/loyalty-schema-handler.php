<?php
class Loyalty_Schema_handler
{

    public function create_or_update_tables()
    {
        global $wpdb;

        // Define plugin version
        $current_version = get_option('casino_plugin_version', '1.1');

        // Check if an update is needed
        $this->create_tables();
        update_option('casino_plugin_version', '1.2');
    }
    // Method to handle schema updates
    private function create_tables()
    {
        global $wpdb;

        // Get charset collate
        $charset_collate = $wpdb->get_charset_collate();

        // Define the table schemas
        $tables = [
            'loyalty_free_play' => $this->get_loyalty_Free_play_schema($charset_collate),
            'loyalty_transaction_history' => $this->get_loyalty_transaction_history_schema($charset_collate),
            'loyalty_my_offer' => $this->get_loyalty_my_offer_schema($charset_collate),
            'loyalty_egift_offer' => $this->get_loyalty_egift_offer_schema($charset_collate),
            'loyalty_leaderboard' => $this->get_loyalty_leaderboard_schema($charset_collate),
            'loyalty_referal_stats' => $this->get_loyalty_referal_stats_schema($charset_collate),
            'loyalty_homepage' => $this->get_loyalty_homepage_schema($charset_collate),
            'loyalty_webhook_calls' => $this->get_loyalty_webhook_calls_schema($charset_collate),
            'loyalty_surveys' => $this->get_loyalty_surveys_schema($charset_collate),
            'loyalty_location' => $this->get_loyalty_location_schema($charset_collate),
            'loyalty_profile' => $this->get_profile_schema($charset_collate),
            'loyalty_birthdays' => $this->get_birthdays_schema($charset_collate),
        ];

        // Execute dbDelta for each table
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        foreach ($tables as $table_name => $schema) {
            $full_table_name = $wpdb->prefix . $table_name;
            $sql = str_replace('{table_name}', $full_table_name, $schema);
            dbDelta($sql);
        }
    }
    // Games Table
    private function get_loyalty_Free_play_schema($charset_collate)
    {
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            data LONGTEXT  NULL,
            user_id INT NOT NULL,
            contact_id LONGTEXT  NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }
    private function get_loyalty_transaction_history_schema($charset_collate)
    {
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            data LONGTEXT  NULL,
            user_id INT NOT NULL,
            contact_id LONGTEXT  NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }
    private function get_loyalty_my_offer_schema($charset_collate)
    {
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            data LONGTEXT  NULL,
            user_id INT NOT NULL,
            contact_id LONGTEXT  NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }



    private function get_loyalty_leaderboard_schema($charset_collate)
    {
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            data LONGTEXT  NULL,
            user_id INT NOT NULL,
            contact_id LONGTEXT  NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }

    private function get_loyalty_egift_offer_schema($charset_collate)
    {
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            data LONGTEXT  NULL,
            user_id INT NOT NULL,
            contact_id LONGTEXT  NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }


    private function get_loyalty_referal_stats_schema($charset_collate)
    {
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            data LONGTEXT  NULL,
            user_id INT NOT NULL,
            contact_id LONGTEXT  NULL,
            type VARCHAR(255) NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }

    private function get_loyalty_homepage_schema($charset_collate)
    {
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            data LONGTEXT  NULL,
            type VARCHAR(255) NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }

    public function get_loyalty_webhook_calls_schema($charset_collate)
    {
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            data LONGTEXT  NULL,
            action VARCHAR(255) NULL,
            contact_id VARCHAR(255) NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }
    public function get_loyalty_surveys_schema($charset_collate)
    {
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            data LONGTEXT  NULL,
            user_id BIGINT NOT NULL,
            contact_id LONGTEXT  NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }
    public function get_loyalty_location_schema($charset_collate)
    {
        return "CREATE TABLE {table_name} (
            id INT NOT NULL AUTO_INCREMENT,
            data LONGTEXT  NULL,
            user_id BIGINT NOT NULL,
            contact_id LONGTEXT  NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
    }
    public function get_profile_schema($charset_collate)
    {
        return "CREATE TABLE {table_name} (
        id INT NOT NULL AUTO_INCREMENT,
        user_id BIGINT NOT NULL,
        contact_id LONGTEXT NULL,
        first_name VARCHAR(255) NULL,
        last_name VARCHAR(255) NULL,
        gender ENUM('Male', 'Female') NULL,
        phone_number VARCHAR(20) NULL,
        email VARCHAR(255) NULL,
        password VARCHAR(255) NULL,
        describe_yourself VARCHAR(255) NULL,
        spender ENUM('Yes, Big Spender') NULL,
        appointment_date DATE NULL,
        fvrt_hockey_team VARCHAR(255) NULL,
        display_name VARCHAR(255) NULL,
        image_url VARCHAR(255) NULL,
        address VARCHAR(255) NULL,
        city VARCHAR(255) NULL,
        state VARCHAR(255) NULL,
        zip_code VARCHAR(20) NULL,
        anniversary_date DATE NULL,
        allow_email BOOLEAN NULL,
        allow_sms BOOLEAN NULL,
        allow_push BOOLEAN NULL,
        preferred_media VARCHAR(255) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";
    }
    public function get_birthdays_schema($charset_collate)
    {
        return "CREATE TABLE {table_name} (
        id INT NOT NULL AUTO_INCREMENT,
        user_id BIGINT NOT NULL,
        friend_name VARCHAR(255) NOT NULL,
        birthday DATE NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";
    }
}
$schemaHanlder = new Loyalty_Schema_handler();

<?php
$contact_id = isset($_SESSION['contact_id']) ?? '';
$address_id = isset($_SESSION['loyalty']['addressID']) ?? '';


class LoyaltyApiHanlder
{
    private $jwtToken;
    private $username;
    private $password;
    private $roboRewardToken;
    private $wp;
    private $contact_id;

    // Tables
    private $loyalty_free_play;
    private $loyalty_transaction_history;
    private $loyalty_my_offer;
    private $loyalty_egift_offer;
    private $loyalty_leaderboard;
    private $loyalty_referal_stats;
    private $loyalty_homepage;
    private $loyalty_surveys;
    private $loyalty_location;
    private $loyalty_rpID;
    private $loyalty_contactListID;
    private $loyalty_roboreward_token;
    private $loyalty_webformId;
   

    

    public function __construct()
    {
        global $wpdb, $contact_id;

        $this->contact_id = $contact_id;

        if(!$this->contact_id)
        {
            return;
        }
  

        $this->rp_id = get_option('casino_rpID');
        
        $this->loyalty_rpID = get_option('casino_rpID');
        $this->loyalty_contactListID = get_option('casino_contactListID');
        $this->loyalty_roboreward_token = get_option('casino_roboreward_token');
        $this->loyalty_webformId = get_option('WEBFROMID');
        
        $this->roboRewardToken = get_option('casino_roboreward_token');
        $this->username = get_option('casino_username');
        $this->password = get_option('casino_password');
        $this->jwtToken = get_option('jwtToken');
        

        // update_option('casino_roboreward_token',$_POST['casino_roboreward_token']);
        // update_option('casino_rpID',$_POST['casino_rpID']);
        // update_option('casino_contactListID',$_POST['casino_contactListID']);
        // update_option('casino_username',$_POST['casino_username']);
        // update_option('casino_password',$_POST['casino_password']);
        // update_option('WEBFROMID',$_POST['WEBFROMID']);

        $this->loyalty_free_play = $wpdb->prefix . "loyalty_free_play";
        $this->loyalty_transaction_history = $wpdb->prefix . "loyalty_transaction_history";
        $this->loyalty_my_offer = $wpdb->prefix . "loyalty_my_offer";
        $this->loyalty_egift_offer = $wpdb->prefix . "loyalty_egift_offer";
        $this->loyalty_leaderboard = $wpdb->prefix . "loyalty_leaderboard";
        $this->loyalty_referal_stats = $wpdb->prefix . "loyalty_referal_stats";
        $this->loyalty_homepage = $wpdb->prefix . "loyalty_homepage";
        $this->loyalty_surveys = $wpdb->prefix . "loyalty_surveys";
        $this->loyalty_location = $wpdb->prefix . "loyalty_location";
        

        // add_shortcode('casino_play_game_page', array($this, 'casino_play_game_shortcode'));

        //transfer points
        add_action('wp_ajax_loyalty_transferpoints', array($this, 'loyalty_transferpoints'));
        add_action('wp_ajax_nopriv_loyalty_transferpoints', array($this, 'loyalty_transferpoints'));

        add_action('wp_ajax_loyalty_profile', array($this, 'loyalty_profile'));
        add_action('wp_ajax_nopriv_loyalty_profile', array($this, 'loyalty_profile'));

        add_action('wp_ajax_submitCashBackRedemption', array($this, 'submitCashBackRedemption'));
        add_action('wp_ajax_nopriv_submitCashBackRedemption', array($this, 'submitCashBackRedemption'));

        add_action('wp_ajax_getLeaderBoard', array($this, 'getLeaderBoard'));
        add_action('wp_ajax_nopriv_getLeaderBoard', array($this, 'getLeaderBoard'));

        // Transaction History Page
        add_action('wp_ajax_getTransactionHistory', array($this, 'getTransactionHistory'));
        add_action('wp_ajax_nopriv_getTransactionHistory', array($this, 'getTransactionHistory'));

        // Redem the Offers
        add_action('wp_ajax_redeemOffer', array($this, 'redeemOffer'));
        add_action('wp_ajax_nopriv_redeemOffer', array($this, 'redeemOffer'));
        // Listing Offers
        add_action('wp_ajax_myOffers', array($this, 'myOffers'));
        add_action('wp_ajax_nopriv_myOffers', array($this, 'myOffers'));

        // Redem EGift Offers
        add_action('wp_ajax_redeemEgiftOffer', array($this, 'redeemEgiftOffer'));
        add_action('wp_ajax_nopriv_redeemEgiftOffer', array($this, 'redeemEgiftOffer'));

        // listing Egifts Offers

        add_action('wp_ajax_eGiftOffers', array($this, 'eGiftOffers'));
        add_action('wp_ajax_nopriv_eGiftOffers', array($this, 'eGiftOffers'));


        add_action('wp_ajax_popup', array($this, 'fetchPopups'));
        add_action('wp_ajax_nopriv_popup', array($this, 'fetchPopups'));

        add_action('wp_ajax_freePlayVisits', array($this, 'freePlayVisits'));
        add_action('wp_ajax_nopriv_freePlayVisits', array($this, 'freePlayVisits'));

        add_action('wp_ajax_getSurveys', array($this, 'getSurveys'));
        add_action('wp_ajax_nopriv_getSurveys', array($this, 'getSurveys'));

        add_action('wp_ajax_getLocation', array($this, 'getLocation'));
        add_action('wp_ajax_nopriv_getLocation', array($this, 'getLocation'));

        add_action('wp_ajax_handle_update_user_profile', array($this, 'handle_update_user_profile'));
        add_action('wp_ajax_nopriv_handle_update_user_profile', array($this, 'handle_update_user_profile'));
    }

    public function sendFeedbackToLoyalty($endpoint = '', $action = 'POST', $data = [])
    {
        $url = 'https://beta.roborewards.net/api/' . $endpoint;
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => $action,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Accept: application/json',
                "Authorization: Bearer $this->jwtToken",
                "Username: $this->username"
            ),
        ));

        // if($endpoint == 'EndUserProfile/GetTransferPoint?webFormId=2f62adb8-284a-4182-9e3c-6198820c598e&rpId=083eb6ce-c029-4086-869e-1175ce7c614d&contactId=8d56bb52-cdc5-475d-a213-b952a0929b17')
        // {
        //     print_r($body);
        //     echo $this->jwtToken;
        //     exit;
        // }

        // echo "Authorization: Bearer $this->jwtToken";
        // exit;

        $response = curl_exec($curl);
        $response = json_decode($response, true);

        if ($response['statusCode'] == 401) {
            $data = array(
                'rewardProgramToken' => $this->roboRewardToken,
                'username' => $this->username,
                'password' => $this->password
            );



            $response = $this->generateAccessToken($data);

            if (!empty($response['token'])) {
                $this->jwtToken = $response['token'];
                update_option('jwtToken', $this->jwtToken);
                return $this->makeApiRequest($endpoint, $action, $data);
            }
        }
        return $response;
    }

    public function makeApiRequest($endpoint = '', $action = 'POST', $data = [])
    {
        $baseUrl = 'https://alpha.roborewards.net/api/';
        $url = $baseUrl . $endpoint;

        // For GET requests, append data as query parameters
        if (strtoupper($action) === 'GET' && !empty($data)) {
            $query = http_build_query($data);
            $url .= (strpos($url, '?') === false ? '?' : '&') . $query;
        }

        $curl = curl_init();

        $curlOptions = [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => $action,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Accept: application/json',
                "Authorization: Bearer $this->jwtToken",
                "Username: $this->username"
            ]
        ];

        // Only set POSTFIELDS for non-GET requests
        if (strtoupper($action) !== 'GET') {
            $curlOptions[CURLOPT_POSTFIELDS] = json_encode($data);
        }

        curl_setopt_array($curl, $curlOptions);

        $response = curl_exec($curl);
        $response = json_decode($response, true);

        // Handle unauthorized - refresh token
        if (isset($response['statusCode']) && $response['statusCode'] == 401) {
            $authData = [
                'rewardProgramToken' => $this->roboRewardToken,
                'username' => $this->username,
                'password' => $this->password
            ];

            $newTokenResponse = $this->generateAccessToken($authData);
            if (!empty($newTokenResponse['token'])) {
                $this->jwtToken = $newTokenResponse['token'];
                update_option('jwtToken', $this->jwtToken);
                return $this->makeApiRequest($endpoint, $action, $data); // retry
            }
        }

        return $response;
    }



    public function preGenerateOtp($data)
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $rpToken = get_option('casino_roboreward_token');
        $webFormID = get_option('casino_roboreward_token');
        $rewardProgramIDNew = get_option('casino_rpID');

        

        $mobilePhone = $data['mobilePhone'];
        $email = $data['email'];

        $queryParams = [
            'RPToken' => $rpToken,
            'MobilePhone' => $mobilePhone,
            'Email' => $email,
        ];

        $response = $this->makeApiRequest(
            'PreLoginUser/GeneratePreSignUpOtp',
            'GET',
            $queryParams
        );

        if (isset($response['statusCode']) && $response['statusCode'] == 1) {
            // Success, store OTP data in session
            $data['otpVerificationId'] = $response['responsedata'];
            $_SESSION['my_data'] = $data;

            return $data;
        }

        // Failed
        error_log('OTP Generation Failed: ' . json_encode($response));
        return 0;
    }



    public function signup($data)
    {


        $customArray = array(
            'contactListID' => "282218B2-3B40-4E4F-99F8-19DB44086F41",
            'webFormID' => '2f62adb8-284a-4182-9e3c-6198820c598e',
            'RewardProgramToken' => 'IF33aPn37HGS1dy7m8HsWN8Pcnpm18',
            'rewardProgramIDNew' => "083eb6ce-c029-4086-869e-1175ce7c614d",
            "firstName" => $data['username'],
            'emailAddress' => $data['email'],
            'password' => $data['password'],
            'confirmPassword' => $data['password'],
            'mobilePhone' => $data['mobilePhone'],
            "otpVerificationId" => $data['otpVerificationId'],
            "otp" => "",
        );


        $response = $this->makeApiRequest('PreLoginUser/JoinNow', 'POST', $customArray);

        $responsedata = json_decode($response['responsedata'], true);

        if (!empty($responsedata['contactID'])) {
            update_user_meta($data['user_id'], 'contact_id', sanitize_text_field($responsedata['contactID']));
        }

        return;
    }
    public function login($data)
    {
        $customArray = array(
            'rewardProgramToken' => get_option('casino_roboreward_token'),
            "username" => $data['username'],
            'password' => $data['password']
        );

        $response = $this->makeApiRequest('PreLoginUser/SignInNow', 'POST', $customArray);

    }
    public function generateAccessToken($data)
    {
        $response = $this->makeApiRequest('JWTAuthenticationWordPress/WordPressLogin', 'POST', $data);
        if (!empty($response['token'])) {
            return $response;
        } else {
            error_log('Token generation failed.');
            return null;
        }
    }

    // All Transfer Points

    public function transferPoints($data)
    {
        $contact_id = isset($_SESSION['contact_id']) ? $_SESSION['contact_id'] : "8d56bb52-cdc5-475d-a213-b952a0929b17";
        return $this->makeApiRequest('EndUserProfile/GetTransferPoint?webFormId=2f62adb8-284a-4182-9e3c-6198820c598e&rpId=083eb6ce-c029-4086-869e-1175ce7c614d&contactId=' . $contact_id, 'GET', $data);
    }
    // Function hits Api, and submit data to the server
    public function loyalty_transferpoints()
    {
        // Sanitize and retrieve fields
        $txtcontact = isset($_POST['txtcontact']) ? sanitize_text_field($_POST['txtcontact']) : '';
        $txtamount = isset($_POST['txtamount']) ? sanitize_text_field($_POST['txtamount']) : '';

        // Validate required fields
        if (empty($txtcontact) || empty($txtamount)) {
            wp_send_json_error([
                'statusCode' => 0,
                'message' => 'Both Contact ID and Amount are required.'
            ]);
        }

        // Build the array for the API call
        $customArray = array(
            'contactID' => isset($_SESSION['contact_id']) ? $_SESSION['contact_id'] : "8d56bb52-cdc5-475d-a213-b952a0929b17",
            'webFormId' => '2f62adb8-284a-4182-9e3c-6198820c598e',
            'rpId' => $_POST['rewardProgramID'],
            'transferPoints' => $txtamount,
            'transferTo' => $txtcontact
        );

        // Make API request
        $data = $this->makeApiRequest('EndUserProfile/TransferPoints', 'POST', $customArray);

        // Handle API response
        if (isset($data['statusCode']) && $data['statusCode'] == 1) {
            wp_send_json_success([
                'statusCode' => 1,
                'message' => 'Points transferred successfully!'
            ]);
        } else {
            $errorMessage = isset($data['message']) ? $data['message'] : 'An error occurred during the transfer.';
            wp_send_json_error([
                'statusCode' => 0,
                'message' => $errorMessage
            ]);
        }
    }


    // 

    // Cashback Handler
    public function getCashBackRedemption($data)
    {
        $contact_id = isset($_SESSION['contact_id']) ? $_SESSION['contact_id'] : "8d56bb52-cdc5-475d-a213-b952a0929b17";
        return $this->makeApiRequest('EndUserProfile/GetCashBack?webFormId=2f62adb8-284a-4182-9e3c-6198820c598e&rpId=083eb6ce-c029-4086-869e-1175ce7c614d&contactId=' . $contact_id, 'GET', $data);
    }
    public function submitCashBackRedemption()
    {

        $customArray = array(
            'contactID' => isset($_SESSION['contact_id']) ? $_SESSION['contact_id'] : "8d56bb52-cdc5-475d-a213-b952a0929b17",
            'webFormId' => '2f62adb8-284a-4182-9e3c-6198820c598e',
            'rpId' => $_POST['rewardProgramID'],
            'cashbackAmount' => $_POST['cashbackAmount'],
        );

        $data = $this->makeApiRequest('EndUserProfile/CashBackRedeem', 'POST', $customArray);

        if (isset($data['statusCode']) && $data['statusCode'] == 1) {
            wp_send_json_success(['statusCode' => 1, 'message' => 'Points transferred successfully!']);
        } else {
            $errorMessage = isset($data['message']) ? $data['message'] : 'An error occurred during the transfer.';
            wp_send_json_error(['statusCode' => 0, 'message' => $errorMessage]);
        }
    }
    public function getTransactionHistory($page = '')
    {
        global $wpdb;

        $contact_id = $this->contact_id;


        $getResult = $wpdb->get_var("SELECT data FROM {$this->loyalty_transaction_history}");

        if ($getResult) {
            $responseData = json_decode($getResult, true);
            $response = [
                'responsedata' => [
                    'transactionHistory' => $responseData
                ]
            ];

            if ($page === 'automation') {
                return $response;
            } else {
                wp_send_json($response); // auto wp_die()
            }
        } else {
            $apiResponse = $this->makeApiRequest(
                "EndUserProfile/TransactionHistory?webFormId=$this->loyalty_webformId&rpId=$this->loyalty_rpID&contactId=" . $contact_id . '&PageNumber=1&pageSize=25',
                'GET',
                []
            );

            $transactions = $apiResponse['responsedata']['transactionhistorylst'] ?? [];

            $encodedData = json_encode($transactions);

            $wpdb->insert($this->loyalty_transaction_history, [
                'data'       => $encodedData,
                'contact_id' => $contact_id
            ]);

            $response = [
                'responsedata' => [
                    'transactionHistory' => $transactions
                ]
            ];

            if ($page === 'automation') {
                return $response;
            } else {
                wp_send_json($response);
            }
        }
    }




    public function getLeaderBoard($page = '')
    {
        global $wpdb;
    
        $tableName = $this->loyalty_leaderboard;
    
        // ✅ Fetch fresh API data
        $apiData = $this->makeApiRequest(
            "EndUserProfile/GetLeaderBoardData?RewardProgramId=$this->loyalty_rpID&PageSize=100&PageNumber=1",
            'GET',
            []
        );
    
        $responsedata = $apiData['responsedata'] ?? [];
        $jsonData = json_encode($responsedata);
    
        // ✅ Check if any row exists
        $exists = $wpdb->get_var("SELECT COUNT(*) FROM {$tableName}");
    
        if ($exists) {
            // ✅ Update existing row
            $wpdb->query(
                $wpdb->prepare("UPDATE {$tableName} SET data = %s LIMIT 1", $jsonData)
            );
        } else {
            // ✅ Insert new row
            $wpdb->insert($tableName, ['data' => $jsonData], ['%s']);
        }
    
        // ✅ Return or echo result
        if ($page === 'automation') {
            return $responsedata;
        } else {
            echo $jsonData;
            wp_die();
        }
    }
    





    // Egift Offers


    public function eGiftOffers($page = '')
    {
        global $wpdb;

        $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;
        $contact_id = $this->contact_id;

        $getResult = $wpdb->get_var("SELECT data FROM {$this->loyalty_egift_offer}");

        if ($getResult) {
            if ($page === 'automation') {
                return json_decode($getResult, true); // Return array for backend
            } else {
                echo $getResult; // AJAX or direct call
                wp_die();
            }
        } else {
            $apiResponse = $this->makeApiRequest(
                "EndUserProfile/GetEGiftOffers?rpId=$this->loyalty_rpID&webFormId=$this->loyalty_webformId&contactId=" . $contact_id,
                'GET',
                []
            );
            $offersList = $apiResponse['responsedata']['offersList'] ?? [];

            $encodedData = json_encode($offersList);

            $wpdb->insert($this->loyalty_egift_offer, [
                'data'       => $encodedData,
                'user_id'    => $user_id,
                'contact_id' => $contact_id
            ]);

            if ($page === 'automation') {
                return $offersList;
            } else {
                echo $encodedData;
                wp_die();
            }
        }
    }


    public function redeemEgiftOffer()
    {
        $customArray = array(
            'rewardProgramID' => '083eb6ce-c029-4086-869e-1175ce7c614d',
            'addressID' => '5b0cc1f3-c4ed-41c0-998a-ac671c8fe749',
            'contactID' => isset($_SESSION['contact_id']) ? $_SESSION['contact_id'] : "8d56bb52-cdc5-475d-a213-b952a0929b17",
            'offerSendID' => 'a8765eb9-d87f-492b-a6d5-768303d780ad'
        );
        $data = $this->makeApiRequest('EndUserProfile/RedeemOffers', 'POST', $customArray);
        echo json_encode(['success' => true, 'data' => $data]);
        wp_die();
    }

    // Ending EGift Offers


    // My Offers

    public function syncContactOffers($contact_id)
    {
        global $wpdb;
        $rp_id = get_option('casino_rpID');
        $data =  $this->makeApiRequest("EndUserProfile/GetOffers?webFormId=90a655cf-fc8e-4a6c-99c4-cce39192cb32&rpId=$rp_id&contactId=$contact_id", 'GET', []);
        $data =  $data['responsedata']['offerDetails'];
        return $data;
    }

    public function myOffers()
    {
        global $wpdb;

        $getResult = $wpdb->get_var("select data from {$this->loyalty_my_offer}");

        if ($getResult) {
            echo $getResult;
            wp_die();
        } else {
            $user_id = isset($_SESSION['user_id']);
            $contact_id = isset($_SESSION['contact_id']) ? $_SESSION['contact_id'] : "8d56bb52-cdc5-475d-a213-b952a0929b17";

            $data =  $this->makeApiRequest('EndUserProfile/GetOffers?webFormId=2f62adb8-284a-4182-9e3c-6198820c598e&rpId=083eb6ce-c029-4086-869e-1175ce7c614d&contactId=' . $contact_id, 'GET', []);

            $data =  json_encode($data['responsedata']['offerDetails'], true);
            $tableArray = [
                'data'      => $data,
                'user_id'    => $user_id,
                'contact_id' => $contact_id
            ];
            $insert = $wpdb->insert(
                $this->loyalty_my_offer,
                $tableArray
            );
        }

        wp_die();
    }
    public function redeemOffer()
    {
        
        $customArray = array(
            'rewardProgramID' => get_option('casino_rpID'),
            'addressID' => $_SESSION['loyalty']['addressID'],
            'contactID' => $_POST['contact_id'],
            "offerID" => $_POST['offer_id']
        );
  
        $data = $this->makeApiRequest('EndUserProfile/RedeemOffers', 'POST', $customArray);
        echo json_encode(['success' => true, 'data' => $data]);
        wp_die();
    }
    // Ending My Offers

    public function rewardCatalogOffers()
    {
        $contact_id = isset($_SESSION['contact_id']) ? $_SESSION['contact_id'] : "8d56bb52-cdc5-475d-a213-b952a0929b17";
        return $this->makeApiRequest('EndUserProfile/GetRewardCatalogOffers?rpId=083eb6ce-c029-4086-869e-1175ce7c614d&webFormId=2f62adb8-284a-4182-9e3c-6198820c598e&contactId=' . $contact_id, 'GET', []);
    }

    public function getReferFriends()
    {
        $contact_id = isset($_SESSION['contact_id']) ? $_SESSION['contact_id'] : "8d56bb52-cdc5-475d-a213-b952a0929b17";
        return $this->makeApiRequest('EndUserProfile/ReferFriends?webFormId=2f62adb8-284a-4182-9e3c-6198820c598e&rpId=083eb6ce-c029-4086-869e-1175ce7c614d&contactId=' . $contact_id, 'GET', []);
    }

    public function homePage($page = '')
    {
        global $wpdb;

        $tableName = $this->loyalty_homepage;
        $contact_id = $this->contact_id;

        $getResult = $wpdb->get_var("SELECT data FROM {$tableName}");

        if ($getResult) {
            $decoded = json_decode($getResult, true);

            if ($page === 'automation') {
                return $decoded;
            } else {
                echo json_encode($decoded);
                wp_die();
            }
        } else {
            $apiResponse = $this->makeApiRequest(
                "EndUserProfile/Home?webFormId=$this->loyalty_webformId&rpId=$this->loyalty_rpID&contactId=" . $contact_id,
                'GET',
                []
            );

            $encodedData = json_encode($apiResponse);
   
            $wpdb->insert($tableName, [
                'data' => $encodedData
            ]);

            if ($page === 'automation') {
                return $apiResponse;
            } else {
                echo $encodedData;
                wp_die();
            }
        }
    }


    public function fetchPopups()
    {
        $data =  $this->makeApiRequest('EndUserProfile/GetGlobalPopupmsg', 'GET', []);
        update_option('popup_api_response', $data);
        return $data;
    }

    public function VisitTrackingData()
    {
        $contact_id = $this->contact_id;
        $data =  $this->makeApiRequest("EndUserProfile/VisitTrackingData?rpId=$this->casino_rpID&contactId=" . $contact_id, 'GET', []);
        return $data;
    }

    public function referalStats($page = '')
    {
        global $wpdb;
    
        $contact_id = $this->contact_id;
        $tableName = $this->loyalty_referal_stats;
    
        $getResult = $wpdb->get_var("SELECT data FROM {$tableName}");
    
        if ($getResult) {
            $decoded = json_decode($getResult, true);
    
            if ($page === 'automation') {
                return $decoded;
            } else {
                echo json_encode($decoded);
                wp_die();
            }
        } else {
            $apiResponse = $this->makeApiRequest(
                "EndUserProfile/Referrals?rpId=$this->loyalty_rpID&contactId=" . $contact_id,
                'GET',
                []
            );
    
            $encodedData = json_encode($apiResponse);
    
            $wpdb->insert($tableName, [
                'data'       => $encodedData,
                'contact_id' => $contact_id
            ]);
    
            if ($page === 'automation') {
                return $apiResponse;
            } else {
                echo $encodedData;
                wp_die();
            }
        }
    }
    

    public function freePlayVisits($page = '')
    {
        global $wpdb;
        
        $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;
        $contact_id = $this->contact_id; 

        $getResult = $wpdb->get_var("SELECT data FROM wp_loyalty_free_play");

        if ($getResult) {
            $decoded = json_decode($getResult, true);
            $decoded['user_id'] = $user_id;
            $decoded['contact_id'] = $contact_id;

            if ($page === 'automation') {
                return $decoded; // return array for automation/cronjob
            } else {
                echo json_encode($decoded);
                wp_die(); // for AJAX
            }
        } else {
            $apiResponse = $this->makeApiRequest(
                "EndUserProfile/VisitTrackingData?rpId=$this->loyalty_rpID&contactId=" . $contact_id,
                'GET',
                []
            );

    
            $dataArr = $apiResponse['responsedata']['visitTracking'] ?? [];
            $dataArr['user_id'] = $user_id;
            $dataArr['contact_id'] = $contact_id;

            $encodedData = json_encode($dataArr);

            // Save into DB
            $wpdb->insert($this->loyalty_free_play, [
                'data'       => 'test',
                'user_id'    => '111',
                'contact_id' => '111'
            ]);

            if ($page === 'automation') {
                return $dataArr;
            } else {
                echo $encodedData;
                wp_die();
            }
        }
    }
    public function getSurveys($page = '')
    {
        global $wpdb;
    
        $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;
        $contact_id = $this->contact_id;    
    
        $getResult = $wpdb->get_var("SELECT data FROM {$this->loyalty_surveys}");
    
        if ($getResult) {
            $decoded = json_decode($getResult, true);
            $decoded['user_id'] = $user_id;
            $decoded['contact_id'] = $contact_id;
    
            if ($page === 'automation') {
                return $decoded;
            } else {
                echo json_encode($decoded);
                wp_die();
            }
        } else {
            $apiResponse = $this->makeApiRequest(
                "EndUserProfile/GetSurvey?webFormId=$this->loyalty_webformId&rpId=$this->loyalty_rpID&contactId=" . $contact_id,
                'GET',
                []
            );
 
            $dataArr = $apiResponse['responsedata'] ?? [];
            $dataArr['user_id'] = $user_id;
            $dataArr['contact_id'] = $contact_id;
    
            $encodedData = json_encode($dataArr);
    
            // Save into DB
            $wpdb->insert($this->loyalty_surveys, [
                'data'       => $encodedData,
                'user_id'    => $user_id,
                'contact_id' => $contact_id
            ]);
    
            if ($page === 'automation') {
                return $dataArr;
            } else {
                echo $encodedData;
                wp_die();
            }
        }
    }
    

    public function getLocation($page = '')
    {
        global $wpdb;

        $tableName = $this->loyalty_location;
        $contact_id = $this->contact_id;

        $getResult = $wpdb->get_var("SELECT data FROM {$tableName}");

        if ($getResult) {
            $decoded = json_decode($getResult, true);

            if ($page === 'automation') {
                return $decoded;
            } else {
                echo json_encode($decoded);
                wp_die();
            }
        } else {
            $apiResponse = $this->makeApiRequest(
                "EndUserProfile/GetLocations?webFormId=$this->loyalty_webformId&rpId=$this->loyalty_rpID&contactId=" . $contact_id,
                'GET',
                []
            );

            $locations = $apiResponse['responsedata'] ?? [];
            $encodedData = json_encode($locations);

            $wpdb->insert($tableName, [
                'data' => $encodedData,
                'contact_id' => $contact_id
            ]);

            if ($page === 'automation') {
                return $locations;
            } else {
                echo $encodedData;
                wp_die();
            }
        }
    }


    function handle_update_user_profile()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'loyalty_profile'; // replace with your actual table name

        $user_id = 0;
        // if (!$user_id) {
        //     wp_send_json_error(['message' => 'User not logged in.']);
        // } else {
        //     $contact_id = get_user_meta($user_id, 'contact_id', true);
        // }

        // Process friend_name[] and friend_birthday[] to generate birthDates JSON
        $birthDatesJson = '';
        if (!empty($_POST['additional_name']) && is_array($_POST['additional_name'])) {
            $birthDatesArray = [];

            foreach ($_POST['additional_name'] as $i => $name) {
                $name = sanitize_text_field($name);
                $birthday = sanitize_text_field($_POST['additional_birthdate'][$i]);

                if ($name && $birthday) {
                    $birthDatesArray[] = [
                        'AdditionalName' => $name,
                        'AdditionalBirthDates' => date('d-M-Y', strtotime($birthday))
                    ];
                }
            }

            $birthDatesJson = json_encode($birthDatesArray);
        }

        // Build the array for the API call
        // $customArray = array(
        //     'webformId' => "1e7579dc-7d48-469d-9173-dbd4483d7512",
        //     'rpId' => "083eb6ce-c029-4086-869e-1175ce7c614d",
        //     'contactID' => "c72dcd26-df59-47c3-aac2-99695993ac95",
        //     'contactListId' => "3c093031-2257-4dfb-aac1-b40bd95b3adc",
        //     'firstName' => $_POST['first_name'],
        //     'lastName' => $_POST['last_name'],
        //     'address' => $_POST['address'],
        //     'city' => $_POST['city'],
        //     'state' => $_POST['state'],
        //     'zip' => $_POST['zip'],
        //     'gender' => $_POST['gender'],
        //     'email' => $_POST['email'],
        //     'emailFormat' => 0,
        //     'password' => $_POST['password'],
        //     'mobile' => $_POST['phone_number'],
        //     'leaderBoardName' => $_POST['display_name'],
        //     "country" => "United States",
        //     "addressId" => "a3a1b7f9-67d9-480a-a1ad-261f99556d0f",
        //     "smsProvider" => "CYDNE",
        //     "sKey" => null,
        //     "emailConfirmationStatusHidden" => "Confirmed",
        //     "smsConfirmationStatusHidden" => "Confirmed",
        //     'birthDate' => $_POST['anniversary'],
        //     "isBirthdayEditedHidden" => "0",
        //     "isAnniversaryEditedHidden" => "false",
        //     "additionalBirthday" => null,
        //     "anniversary" => null,
        //     'birthDates' => $birthDatesJson,
        //     'allowSms' => ($_POST['allow_sms'] ?? '') === 'Yes, allow SMS' ? 1 : 0,
        //     'allowEmail' => ($_POST['allow_email'] ?? '') === 'Yes, allow email' ? 1 : 0,
        //     'allowPostal' => "null",
        //     'preferMediaType' => sanitize_text_field($_POST['preferred_media'] ?? ''),
        //     // 'profilePic' => esc_url_raw($_POST['image_url'] ?? ''),
        //     "completionPoints" => "200",
        //     "driverLicense" => "12121212121",
        //     "currentProfilePic" => null,
        //     "allowsSmsHidden" => "true",
        //     "contactAllowsSmsHidden" => "true",
        //     "allowPush" => "false",
        //     "isSmsOptInConfirmRP" => "false",
        //     "isEmailOptInConfirmRP" => "true",
        //     "isMinimumJoinYear" => "false",
        //     "checkTos" => "true",
        //     "socialReferId" => null,
        //     "isOptInConfirm" => "True",
        //     "emailConfirmationStatus" => "Confirmed",
        //     "smsConfirmationStatus" => "Confirmed",
        //     "isProfileComplete" => "1",
        //     "isImported" => "false",
        //     "customFields" => "{\"custome_fileds\":[]}",
        //     "memberCardId" => "10101010",
        //     "profilePic" => "https://betaroborewards.s3.us-west-2.amazonaws.com/083eb6ce-c029-4086-869e-1175ce7c614d/EndUser/293286843.jpg",
        // );

        // $customArray = array(
        //     "rpId" => $this->loyalty_rpID,
        //     "contactId" => $this->contact_id, // Renamed from "contactID"
        //     "contactListId" => $this->loyalty_contactListID,
        //     "firstName" => $_POST['firstname'],
        //     "lastName" => $_POST['lastname'],
        //     "address" => $_POST['address'],
        //     "address2" => $_POST['address2'],
        //     "address3" => $_POST['address3'],
        //     "city" => $_POST['city'],
        //     "state" => $_POST['state'],
        //     "zip" => $_POST['zip'],
        //     "country" => $_POST['country'],
        //     "addressId" => $address_id,
        //     "smsProvider" => "CYDNE",
        //     "sKey" => null,
        //     "emailConfirmationStatusHidden" => "Confirmed",
        //     "smsConfirmationStatusHidden" => "Confirmed",
        //     "mobile" => $_POST['mobile'],
        //     "password" => $_POST['password'],
        //     "gender" => $_POST['please_select_gender'],
        //     "birthDate" => $_POST['anniversary'],
        //     "isBirthdayEditedHidden" => "0",
        //     "isAnniversaryEditedHidden" => "false",
        //     "additionalBirthday" => null,
        //     "anniversary" => null,
        //     "email" => $_POST['member_email'],
        //     "emailFormat" => "0",
        //     "customFields" => "{\"custome_fileds\":[]}",
        //     "memberCardId" => "10101003", // match from JSON, or dynamic if needed
        //     "birthDates" => $birthDatesJson, // must be JSON-encoded string
        //     "allowSms" => "true",
        //     "allowEmail" => "true",
        //     "allowPostal" => "null",
        //     "preferMediaType" => "Email",
        //     "socialReferId" => null,
        //     "isOptInConfirm" => "True",
        //     "emailConfirmationStatus" => "Confirmed",
        //     "smsConfirmationStatus" => "Confirmed",
        //     "isProfileComplete" => "1",
        //     "isImported" => "false",
        //     "webformId" => $this->loyalty_webformId,
        //     "profilePic" => "https://betaroborewards.s3.us-west-2.amazonaws.com/083eb6ce-c029-4086-869e-1175ce7c614d/EndUser/293286843.jpg",
        //     "leaderBoardName" => $_POST['leaderboard_display'],
        //     "completionPoints" => "200",
        //     "driverLicense" => "424209-8463",
        //     "currentProfilePic" => null,
        //     "allowsSmsHidden" => "true",
        //     "contactAllowsSmsHidden" => "true",
        //     "allowPush" => "false",
        //     "isSmsOptInConfirmRP" => "false",
        //     "isEmailOptInConfirmRP" => "true",
        //     "isMinimumJoinYear" => "false",
        //     "checkTos" => "true"
        // );

        $customArray = [
            "rpId" => $this->loyalty_rpID,
            "contactId" => $this->contact_id,
            "contactListId" => $this->loyalty_contactListID,
            "firstName" => "Demoo",
            "lastName" => "Testing",
            "address" => "surat",
            "address2" => "ahmd",
            "address3" => "mumbai",
            "city" => "surat Test",
            "state" => "gujarat",
            "zip" => "315021",
            "country" => "United States",
            "addressId" => $address_id,
            "smsProvider" => "CYDNE",
            "sKey" => null,
            "emailConfirmationStatusHidden" => "Confirmed",
            "smsConfirmationStatusHidden" => "Confirmed",
            "mobile" => "(789) 798-9790",
            "password" => "123456789",
            "gender" => "Male",
            "birthDate" => "21-May-2003",
            "isBirthdayEditedHidden" => "0",
            "isAnniversaryEditedHidden" => "false",
            "additionalBirthday" => null,
            "anniversary" => null,
            "email" => "abdul@gmail.com",
            "emailFormat" => "0",
            "customFields" => '{"custome_fileds":[]}',
            "memberCardId" => "10101003",
            "birthDates" => '[{"AdditionalName":"Demo","AdditionalBirthDates":"14-May-2023"}]',
            "allowSms" => "true",
            "allowEmail" => "true",
            "allowPostal" => "null",
            "preferMediaType" => "Email",
            "socialReferId" => null,
            "isOptInConfirm" => "True",
            "emailConfirmationStatus" => "Confirmed",
            "smsConfirmationStatus" => "Confirmed",
            "isProfileComplete" => "1",
            "isImported" => "false",
            "webformId" => $this->loyalty_webformId,
            "profilePic" => "https://betaroborewards.s3.us-west-2.amazonaws.com/083eb6ce-c029-4086-869e-1175ce7c614d/EndUser/293286843.jpg",
            "leaderBoardName" => "Demo T",
            "completionPoints" => "200",
            "driverLicense" => "424209-8463",
            "currentProfilePic" => null,
            "allowsSmsHidden" => "true",
            "contactAllowsSmsHidden" => "true",
            "allowPush" => "false",
            "isSmsOptInConfirmRP" => "false",
            "isEmailOptInConfirmRP" => "true",
            "isMinimumJoinYear" => "false",
            "checkTos" => "true"
        ];
        
        


        echo "<pre>";
        print_r($customArray);
        echo "</pre>";


        // Make API request
        $data = $this->makeApiRequest('EndUserProfile/UpdateProfile', 'POST', $customArray);

        echo "<pre>";
        print_r($data);
        echo "</pre>";
        exit;

        // Handle API response
        if (isset($data['statusCode']) && $data['statusCode'] == 1) {
            wp_send_json_success([
                'statusCode' => 1,
                'message' => 'Profile updated successfully!'
            ]);
        } else {
            $errorMessage = isset($data['message']) ? $data['message'] : 'An error occurred during the updating.';
            wp_send_json_error([
                'statusCode' => 0,
                'message' => $errorMessage
            ]);
        }

        $data = [
            'user_id'           => $user_id,
            'contact_id'        => $contact_id,
            'first_name'        => sanitize_text_field($_POST['first_name'] ?? ''),
            'last_name'         => sanitize_text_field($_POST['last_name'] ?? ''),
            'gender'            => sanitize_text_field($_POST['gender'] ?? ''),
            'phone_number'      => sanitize_text_field($_POST['phone_number'] ?? ''),
            'email'             => sanitize_email($_POST['email'] ?? ''),
            'password'          => sanitize_text_field($_POST['password'] ?? ''), // You can hash if needed
            'describe_yourself' => sanitize_text_field($_POST['describe_yourself'] ?? ''),
            'spender'           => sanitize_text_field($_POST['spender'] ?? ''),
            'appointment_date'  => sanitize_text_field($_POST['appointment_date'] ?? ''),
            'fvrt_hockey_team'  => sanitize_text_field($_POST['fvrt_hockey_team'] ?? ''),
            'display_name'      => sanitize_text_field($_POST['display_name'] ?? ''),
            'image_url'         => esc_url_raw($_POST['image_url'] ?? ''),
            'address'           => sanitize_text_field($_POST['address'] ?? ''),
            'city'              => sanitize_text_field($_POST['city'] ?? ''),
            'state'             => sanitize_text_field($_POST['state'] ?? ''),
            'zip_code'          => sanitize_text_field($_POST['zip_code'] ?? ''),
            'anniversary_date'  => sanitize_text_field($_POST['anniversary'] ?? ''),
            'allow_email'       => ($_POST['allow_email'] ?? '') === 'Yes, allow email' ? 1 : 0,
            'allow_sms'         => ($_POST['allow_sms'] ?? '') === 'Yes, allow SMS' ? 1 : 0,
            'allow_push'        => ($_POST['allow_push'] ?? '') === 'Yes, allow PUSH' ? 1 : 0,
            'preferred_media'   => sanitize_text_field($_POST['preferred_media'] ?? ''),
        ];

        // Check if profile already exists
        $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table_name WHERE user_id = %d", $user_id));

        if ($existing) {
            $wpdb->update($table_name, $data, ['user_id' => $user_id]);
        } else {
            $wpdb->insert($table_name, $data);
        }

        if (!empty($_POST['additional_name']) && is_array($_POST['additional_name'])) {
            global $wpdb;
            $birthday_table = $wpdb->prefix . 'loyalty_birthdays';
            $user_id = 0;

            $birthDatesArray = [];

            foreach ($_POST['additional_name'] as $i => $name) {
                $name = sanitize_text_field($name);
                $birthday = sanitize_text_field($_POST['additional_birthdate'][$i]);

                if ($name && $birthday) {
                    // Save to DB
                    $wpdb->insert($birthday_table, [
                        'user_id' => $user_id,
                        'friend_name' => $name,
                        'birthday' => $birthday
                    ]);

                    // Add to birthDates array
                    $birthDatesArray[] = [
                        'AdditionalName' => $name,
                        'AdditionalBirthDates' => date('d-M-Y', strtotime($birthday))
                    ];
                }
            }

            // Now generate JSON format for birthDates field
            $birthDatesJson = json_encode($birthDatesArray);

            // Save this into your main data array like:
            $customArray['birthDates'] = $birthDatesJson;
        }

        wp_send_json_success(['message' => 'Profile updated successfully.']);
    }


    function viewOfferByid($id)
    {
        $data = $this->makeApiRequest("EndUserProfile/GetUserOfferByOfferId?rpId=1BF55854-7BF3-4315-A25C-9A17F4CE221E&OfferId=$id&contactId=42269f96-46e7-44ea-8896-8266e27817b0", 'GET', []);
      

        return $data;
    }

    // Loyalty Game Play Integration with Plugin :
    function gameList()
    {
        $data = $this->makeApiRequest('IGaming/CasinoGameList?RpToken=I6H58umMuF24VoWOfsd7ahLJI6b861&PageNumber=2&PageSize=20', 'GET',[]);
        return $data;
    }

    function updateGameListStauts($array)
    {

        $data = $this->makeApiRequest('IGaming/CasinoGameListStatusUpdate', 'POST',$array);
        return $data;
    }


    function merchantDetails($array = [])
    {
        $data = $this->makeApiRequest('IGaming/MerchantDetails?rpId=1BF55854-7BF3-4315-A25C-9A17F4CE221E', 'GET',$array);
        return $data;
    }

    function dashboard($array = [])
    {
       
        $data = $this->makeApiRequest('IGaming/DashboardSummaryWithTxns?rpId=1BF55854-7BF3-4315-A25C-9A17F4CE221E&contactId=42269f96-46e7-44ea-8896-8266e27817b0&webFormId=90a655cf-fc8e-4a6c-99c4-cce39192cb32', 'GET',$array);
        return $data['responsedata'];
    }

    function updateBalance($data)
    {
    
        $contact_id = get_user_meta($data['customer_id'], 'contact_id', true);
        $array = array(
            'amount' => $data['balance_to_add'],
            'contactID' => $contact_id,
            'rptoken' => get_option('casino_roboreward_token')
        );

 
        $data = $this->makeApiRequest('IGaming/AddBalance', 'POST',$array);

        return $data['responsedata'];
    }


    function viewGameActivityByGameId($data)
    {
        // print_r($data);
        // exit;
        // $contact_id = get_user_meta($data['customer_id'], 'contact_id', true);
        $array = array(
            'amount' => $data['balance_to_add'],
            'contactID' => $contact_id,
            'rptoken' => get_option('casino_rpID')
        );

        $game_id = $data['GameUid'];
        $rpToken = get_option('casino_roboreward_token');

        $session_id = $data['SessionId'];
        $PageNumber = 1;
        $PageSize = 10; 
        


 
        $data = $this->makeApiRequest("IGaming/GameActivityTransaction?RewardProgramToken=$rpToken&GameUid=$game_id&SessionId=$session_id&PageNumber=$PageNumber&PageSize=$PageSize", 'GET',[]);
        return $data['responsedata'];

    }


    function viewCustomerPlayGame($data)
    {
        // print_r($data);
        // exit;
        // $contact_id = get_user_meta($data['customer_id'], 'contact_id', true);
        $array = array(
            'amount' => $data['balance_to_add'],
            'contactID' => $contact_id,
            'rptoken' => get_option('casino_rpID')
        );

        $game_id = $data['game_uiid'];
        $rpToken = get_option('casino_roboreward_token');

        $session_id = $data['session_id'];
        $PageNumber = 1;
        $PageSize = 10; 
        


 
        $data = $this->makeApiRequest("IGaming/GameCurrentlyPlayed?RewardProgramToken=$rpToken&PageNumber=$PageNumber&$PageSize=10", 'GET',[]);
        return $data['responsedata'];
    }
}


new LoyaltyApiHanlder();
    
<?php
class RoboRewardLoyaltyShortCodeHandler
{
    private $LoyaltyApiHanlder;
    public function __construct()
    {
        $this->loyaltyController = new LoyaltyApiHanlder();

        add_shortcode('loyalty_transfer_points', array($this, 'transferPointsShortCode'));
        add_shortcode('loyalty_transfer_points_b1', array($this, 'transferPointsShortCodeB1'));
        add_shortcode('loyalty_transfer_points_b2', array($this, 'transferPointsShortCodeB2'));
        add_Shortcode('loyalty_transfer_points_b3', array($this, 'loyaltyTransferPointsShortCode'));
        add_shortcode('loyalty_cashback_redemption', array($this, 'cashBackRedemptionShortCode'));
        add_shortcode('loyalty_transaction_history', array($this, 'transactionHistoryShortCode'));
        add_shortcode('loyalty_transaction_history_b1', array($this, 'transactionHistoryShortCodeB1'));
        add_shortcode('loyalty_transaction_history_b2', array($this, 'transactionHistoryShortCodeB2'));

        // Leadersshop shortcodes
        add_shortcode('loyalty_leaderboard_data', array($this, 'leaderBoardDataShortCode'));
        add_shortcode('loyalty_leaderboard_data_b1', array($this, 'leaderBoardDataShortCodeB1'));
        add_shortcode('loyalty_egift_offer', array($this, 'leaderEGiftShortCode'));
        add_shortcode('loyalty_my_offers', array($this, 'loyaltyMyOffersShortCode'));
        add_shortcode('loyalty_my_offers_b1', array($this, 'loyaltyMyOffersShortCodeB1'));
        add_shortcode('loyalty', array($this, 'loyaltyHomePageShortCode'));
        add_shortcode('loyalty_referal_link', array($this, 'loyaltyReferFriendsShortCode'));

        add_shortcode('loyalty_popup_screens', array($this, 'popup_short_codes'));

        add_shortcode('loyalty_referal_stats', array($this, 'referalStatsShortcode'));
        add_shortcode('loyalty_referal_stats_b1', array($this, 'referalStatsShortcodeB1'));
        add_shortcode('loyalty_referal_stats_b2', array($this, 'referalStatsShortcodeB2'));


        add_shortcode('loyalty_free_visits', array($this, 'loyaltyFreeVisitShortCode'));

        add_shortcode('loyalty_cashback_redemption', array($this, 'loyaltyCashBackRedemptionShortCode'));

        add_shortcode('loyalty_personal_info', array($this, 'loyaltyPersonalInfoShortCode'));
        add_shortcode('loyalty_change_password', array($this, 'loyaltyChangePasswordShortCode'));
        add_shortcode('loyalty_take_a_brake', array($this, 'loyaltyTakeABrakeShortCode'));

        add_shortcode('loyalty_verification', array($this, 'loyaltyVerificationShortCode'));
        add_shortcode('loyalty_survey', array($this, 'loyaltySurveyShortCode'));
        add_shortcode('loyalty_survey_avada', array($this, 'loyaltySurveyAvadaShortCode'));

        add_shortcode('loyalty_location', array($this, 'loyaltyLocationShortCode'));

        add_shortcode('loyalty_profile', array($this, 'loyaltyProfileShortCode'));




        add_shortcode('redeem_popup_content', array($this, 'redeem_popup_shortcode'));
  

        // Abdul
        add_shortcode('loyalty_profile_avada',array($this,'loyalty_profile_avada'));


        // add_shortcode('loyalty_leaderboard_member_search',array($this,'leaderboardMemberSearchShortCode'));
        // add_shortcode('loyalty_leaderboard_potential_winners',array($this,'leaderboardPotentialWinnersShortCode'));
        // add_shortcode('loyalty_leaderboard_checkins_qualify',array($this,'leaderboardcheckinsQualify'));
        // add_shortcode('loyalty_leaderboard_referrals_qualify',array($this,'leaderboardReferralsQualifyShortCode'));


        add_shortcode('loyalty_profile_deposit',array($this,'loyalty_profile_deposit'));

    }

    // Done Bharat

    function loyalty_profile_deposit()
    {
        ob_start();
        
        include plugin_dir_path(__FILE__) . '../deposit_shortcode/loyalty_profile_deposit.php';

        return ob_get_clean();

    }

    // Popups Shortcode

    function redeem_popup_shortcode()
    {
        ob_start();
        $user_id = $_SESSION['user_id'] ?? null;
        $offer_id = $user_id ? get_user_meta($user_id, 'loyalty_offer_id', true) : '';


        // Get Details from the controller

        $offerData = $this->loyaltyController->viewOfferById($offer_id);
        if (isset($offerData['responsedata'])) {
            $offerData = $offerData['responsedata'];
        }


        include plugin_dir_path(__FILE__) . '../popup_shortcodes/redeem_popup.php';

        return ob_get_clean();
    }

    function get_registered_shortcodes()
    {
        global $shortcode_tags;

        $shortcodes = [];

        foreach ($shortcode_tags as $shortcode => $callback) {
            if (strpos($shortcode, 'loyalty') === 0) {
                if (is_array($callback)) {
                    $reflection = new ReflectionMethod($callback[0], $callback[1]);
                } else {
                    $reflection = new ReflectionFunction($callback);
                }

                $doc_comment = $reflection->getDocComment();
                preg_match('/\*\s+(.+?)\s*\*/', $doc_comment, $matches);
                $description = isset($matches[1]) ? $matches[1] : 'No description available';

                $shortcodes[$shortcode] = [
                    'description' => $description
                ];
            }
        }

        return $shortcodes;
    }


    public function transferPointsShortCode($data)
    {
        global $wpdb;

        // This will pull Data from Transfer Points
        $apiResponse = $this->loyaltyController->transferPoints([]);
        if (isset($apiResponse['responsedata'])) {
            $apiResponse = $apiResponse['responsedata'];
        }

        // Extract form fields from the provided $data
        $pointBalance = $apiResponse['transferPointPageData']['pointBalance'];
        $contactID = $apiResponse['transferPointPageData']['contactID'];
        $rewardProgramID = $apiResponse['transferPointPageData']['rewardProgramID'];
        $contactTerm = $apiResponse['transferPointPageData']['contactTerm'];

        $txtIdPlaceholder = $apiResponse['requiredForm']['txtId']['placeholder'];
        $txtAmountPlaceholder = $apiResponse['requiredForm']['txtAmount']['placeholder'];
        $btnSubmitText = $apiResponse['requiredForm']['btnSubmit'];


        // Generate the form dynamically
        ob_start();

        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/transfer_points.php';

        return ob_get_clean();
    }

    public function transferPointsShortCodeB1($data)
    {
        global $wpdb;

        // This will pull Data from Transfer Points
        $apiResponse = $this->loyaltyController->transferPoints([]);
        if (isset($apiResponse['responsedata'])) {
            $apiResponse = $apiResponse['responsedata'];
        }

        // Extract form fields from the provided $data
        $pointBalance = $apiResponse['transferPointPageData']['pointBalance'];
        $contactID = $apiResponse['transferPointPageData']['contactID'];
        $rewardProgramID = $apiResponse['transferPointPageData']['rewardProgramID'];
        $contactTerm = $apiResponse['transferPointPageData']['contactTerm'];

        $txtIdPlaceholder = $apiResponse['requiredForm']['txtId']['placeholder'];
        $txtAmountPlaceholder = $apiResponse['requiredForm']['txtAmount']['placeholder'];
        $btnSubmitText = $apiResponse['requiredForm']['btnSubmit'];


        // Generate the form dynamically
        ob_start();

        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/transfer_points_b1.php';

        return ob_get_clean();
    }

    public function transferPointsShortCodeB2($data)
    {
        global $wpdb;

        // This will pull Data from Transfer Points
        $apiResponse = $this->loyaltyController->transferPoints([]);
        if (isset($apiResponse['responsedata'])) {
            $apiResponse = $apiResponse['responsedata'];
        }

        // Extract form fields from the provided $data
        $pointBalance = $apiResponse['transferPointPageData']['pointBalance'];

        return "
    <div class='code_inline'>
        <div class='counter_inline'>
            <span id='points-balance'>" . esc_html($pointBalance) . "</span>
        </div>PTS
    </div>
";
    }


    // CashRedemptionShortcode
    public function cashBackRedemptionShortCode($data)
    {
        global $wpdb;
        // This will pull Data from Transfer Points
        $apiResponse = $this->loyaltyController->getCashBackRedemption([]);
        if (isset($apiResponse['responsedata'])) {
            $apiResponse = $apiResponse['responsedata'];
        }

        // Extract form fields from the provided $data
        $cashbackAmount = $apiResponse["responsedata"]["cashBackDetails"]["cashbackAmount"];
        $currencySymbol = $apiResponse["responsedata"]["cashBackDetails"]["currencySymbol"];
        $defaultRedemptionValues = $apiResponse["responsedata"]["defaultCashRedemptionValues"];
        // Generate the form dynamically
        ob_start();

        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/cashbackredemption.php';
        return ob_get_clean();
    }
    // 
    public function transactionHistoryShortCode($table)
    {
        ob_start();
        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/transaction_history.php';
        return ob_get_clean();
    }
    public function transactionHistoryShortCodeB1($atts)
    {
        ob_start();
        // Pass $transactions to your include file
        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/transaction_history_b1.php';
        return ob_get_clean();
    }
    public function transactionHistoryShortCodeB2($table)
    {
        ob_start();
        // Pass $transactions to your include file
        include plugin_dir_path(__FILE__) . '../loyalty-avada-shortcodes/transaction_history_avada.php';
        return ob_get_clean();
    }

    public function loyalty_profile_avada()
    {
        ob_start();
        include plugin_dir_path(__FILE__) . '../loyalty-avada-shortcodes/loyalty_profile_avada.php';
        return ob_get_clean();
    }


    // Leaderboard ShortCodes
    public function leaderBoardDataShortCode($atts)
    {
        ob_start();
        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/leaderboard_data.php';
        return ob_get_clean();
    }
    public function leaderBoardDataShortCodeB1($atts)
    {
        ob_start();

        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/leaderboard_data_b1.php';
        return ob_get_clean();
    }
    public function leaderEGiftShortCode($table)
    {
        // Dummy data just for now
        $offers = [
            [
                'offerData' => [
                    'tangoCategoryName' => 'Entertainment'
                ]
            ],
            [
                'offerData' => [
                    'tangoCategoryName' => 'Department Store'
                ]
            ]
        ];

        ob_start();
        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/egift.php';
        return ob_get_clean();
    }

    public function loyaltyMyOffersShortCode($table)
    {
        ob_start();
        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/my_offers.php';
        return ob_get_clean();
    }
    public function loyaltyMyOffersShortCodeB1($table)
    {
        ob_start();
        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/my_offersB1.php';
        return ob_get_clean();
    }


    public function loyaltyHomePageShortCode($atts)
    {
        $totalPoints = isset($atts['total_points']) ? $atts['total_points'] : false;
        $cashback = isset($atts['cashback']) ? $atts['cashback'] : false;
        $transfer_points = isset($atts['transfer_points']) ? $atts['transfer_points'] : false;
        $totalTierPoints = isset($atts['tier_points']) ? $atts['tier_points'] : false;

        $apiResponse = $this->loyaltyController->homePage([]);
        if (isset($apiResponse['responsedata'])) {
            $apiResponse = $apiResponse['responsedata'];
        }

        // // Traking Api
        // $trackingResponse = $this->loyaltyController->VisitTrackingData();
        
        echo "<pre>";
        print_r($apiResponse);
        echo "</pre>";
        exit;

        $tierPoints = $apiResponse['contactPointsDetails']['pointBalance'];
        $pointInBalance = $apiResponse['contactPointsDetails']['pointBalance'];
        $cashbackPoint = $apiResponse['contactPointsDetails']['cashbackPoint'];

        $transactionPoint = $apiResponse['contactPointsDetails']['transactionPoint'];
        // Contact Details Object

        $isAllowFacebookBonusPoints = $apiResponse['contactDetails']['isAllowFacebookBonusPoints'];
        $addressID = $apiResponse['contactDetails']['addressID'];
        $lastName = $apiResponse['contactDetails']['lastName'];
        $firstName = $apiResponse['contactDetails']['firstName'];
        $isDelete = $apiResponse['contactDetails']['isDelete'];
        $pointBalance = $apiResponse['contactDetails']['pointBalance'];
        $_DateFormat = $apiResponse['contactDetails']['_DateFormat'];
        $contactBalance = $apiResponse['contactDetails']['contactBalance'];
        $shipDetails = $apiResponse['contactDetails']['shipDetails'];

        $offersList = $apiResponse['offerDetails'];

        ob_start();

        if ($totalPoints) {
            echo $pointInBalance;
        } elseif ($cashback) {
            echo $cashbackPoint;
        } elseif ($transfer_points) {
            echo $transactionPoint;
        } elseif ($totalTierPoints) {
            echo $tierPoints;
        }


        return ob_get_clean();
    }


    public function loyaltyReferFriendsShortCode()
    {
        $apiResponse = $this->loyaltyController->getReferFriends([]);
        if (isset($apiResponse['responsedata'])) {
            $apiResponse = $apiResponse['responsedata'];
        }
        $link = $apiResponse['sharedLink'];
        $shareLinkTitle = $apiResponse['shareLinkTitle'];
        $shareLinkText = $apiResponse['shareLinkText'];

        ob_start();

        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/referal_link.php';
        return ob_get_clean();
    }


    public function popup_short_codes()
    {
        $apiResponse = $this->loyaltyController->fetchPopups([]);
        if (isset($apiResponse['responsedata'])) {
            $apiResponse = $apiResponse['responsedata'];
        }
        // Store or update in wp_options
        update_option('popup_api_response', $apiResponse);
    }

    public function referalStatsShortcode($atts)
    {
        ob_start();

        $total_clicked = isset($atts['total_clicked']) ? $atts['total_clicked'] : false;
        $total_joins = isset($atts['total_joins']) ? $atts['total_joins'] : false;
        $referal_earned = isset($atts['referal_earned']) ? $atts['referal_earned'] : false;

        $apiResponse = $this->loyaltyController->referalStats([]);
        if (isset($apiResponse['responsedata'])) {
            $apiResponse = $apiResponse['responsedata'];
        }
        $apiResponse = json_decode($apiResponse['hdnSocialReport'], true);


        if ($total_clicked) {
            echo $apiResponse['InvitesVisited']['Point'];
        } else if ($total_joins) {
            echo $apiResponse['InvitesJoined']['Point'];
        } else {
            echo $apiResponse['SocialPointsEarned']['Point'];
        }



        return ob_get_clean();
    }

    public function referalStatsShortcodeB1($atts)
    {
        ob_start();

        $total_clicked = isset($atts['total_clicked']) ? $atts['total_clicked'] : false;
        $total_joins = isset($atts['total_joins']) ? $atts['total_joins'] : false;
        $referal_earned = isset($atts['referal_earned']) ? $atts['referal_earned'] : false;

        $apiResponse = $this->loyaltyController->referalStats([]);
        if (isset($apiResponse['responsedata'])) {
            $apiResponse = $apiResponse['responsedata'];
        }
        $apiResponse = json_decode($apiResponse['hdnSocialReport'], true);

        if ($total_clicked) {
            $total_clicked = $apiResponse['InvitesVisited']['Point'];
            $total_joins = $apiResponse['InvitesJoined']['Point'];
            $referal_earned = $apiResponse['SocialPointsEarned']['Point'];
        } else if ($total_joins) {
            $total_joins = $apiResponse['InvitesJoined']['Point'];
        } else {
            $referal_earned = $apiResponse['SocialPointsEarned']['Point'];
        }
        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/referal_statsB1.php';
        return ob_get_clean();
    }

    public function referalStatsShortcodeB2($atts)
    {
        ob_start();

        $total_clicked = isset($atts['total_clicked']) ? $atts['total_clicked'] : false;
        $total_joins = isset($atts['total_joins']) ? $atts['total_joins'] : false;
        $referal_earned = isset($atts['referal_earned']) ? $atts['referal_earned'] : false;

        $apiResponse = $this->loyaltyController->referalStats([]);
        if (isset($apiResponse['responsedata'])) {
            $apiResponse = $apiResponse['responsedata'];
        }
        $apiResponse = json_decode($apiResponse['hdnSocialReport'], true);

        if ($total_clicked) {
            $total_clicked = $apiResponse['InvitesVisited']['Point'];
            $total_joins = $apiResponse['InvitesJoined']['Point'];
            $referal_earned = $apiResponse['SocialPointsEarned']['Point'];
        } else if ($total_joins) {
            $total_joins = $apiResponse['InvitesJoined']['Point'];
        } else {
            $referal_earned = $apiResponse['SocialPointsEarned']['Point'];
        }
        include plugin_dir_path(__FILE__) . '../loyalty-avada-shortcodes/referal_stats_avada.php';
        return ob_get_clean();
    }

    public function loyaltyFreeVisitShortCode($atts)
    {
        ob_start();

        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/free_play_visits.php';
        return ob_get_clean();
    }

    public function loyaltyCashBackRedemptionShortCode($atts)
    {
        ob_start();

        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/cashbackredemption.php';
        return ob_get_clean();
    }

    public function loyaltyPersonalInfoShortCode($atts)
    {
        ob_start();

        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/personal_info.php';
        return ob_get_clean();
    }

    public function loyaltyChangePasswordShortCode($atts)
    {
        ob_start();

        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/change_password.php';
        return ob_get_clean();
    }
    public function loyaltyTakeABrakeShortCode($atts)
    {
        ob_start();

        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/takeabrake.php';
        return ob_get_clean();
    }
    public function loyaltyVerificationShortCode($atts)
    {
        ob_start();

        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/verification.php';
        return ob_get_clean();
    }
    public function loyaltySurveyShortCode($atts)
    {
        ob_start();

        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/survey.php';
        return ob_get_clean();
    }

    public function loyaltySurveyAvadaShortCode($atts)
    {
        ob_start();

        include plugin_dir_path(__FILE__) . '../loyalty-avada-shortcodes/survey-avada.php';
        return ob_get_clean();
    }

    public function loyaltyLocationShortCode($atts)
    {
        ob_start();

        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/location.php';
        return ob_get_clean();
    }
    public function loyaltyProfileShortCode($atts)
    {
        ob_start();

        include plugin_dir_path(__FILE__) . '../loyalty-universal-shortcodes/profile.php';
        return ob_get_clean();
    }
    public function loyaltyTransferPointsShortCode($atts)
    {
        // $page_id = 6232; // Replace with your page or layout ID
        // $post = get_post($page_id);

        // if ($post) {
        //     // Apply Fusion Builder shortcodes
        //     return do_shortcode($post->post_content);
        // }

        // return '<p>Content not found.</p>';
        ob_start();

        include plugin_dir_path(__FILE__) . '../loyalty-avada-shortcodes/transfer_points_avada.php';
        return ob_get_clean();
    }



    
}


add_action('wp_ajax_get_offer_modal_content', function () {
    $user_id = get_current_user_id();
    $offer_id = $_GET['offer_id'] ?? null;

    if ($offer_id) {
        update_user_meta($user_id, 'loyalty_offer_id', $offer_id);
    }

    // This will ensure the shortcode uses latest offer_id
    $controller = new LoyaltyApiHanlder();
    $offerData = $controller->viewOfferById($offer_id);

    if (isset($offerData['responsedata'])) {
        $offerData = $offerData['responsedata'];
    }

    include plugin_dir_path(__FILE__) . '../popup_shortcodes/redeem_popup.php';

    wp_die(); // always for ajax
});

new RoboRewardLoyaltyShortCodeHandler();

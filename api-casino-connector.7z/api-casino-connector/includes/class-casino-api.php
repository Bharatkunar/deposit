<?php

class  CasinoApi
{
    private $merchantId;
    private $merchantKey;
    private $callBackUrl;
    private $baseUrl;
    private $signedKey;

    public function __construct()
    {
        $this->merchantId = get_option('casino_merchant_id');
        $this->merchantKey = get_option('casino_merchant_key');
        $this->callBackUrl = get_option('casino_callback_url');
        $this->baseurl = get_option('casino_base_url');
    }
    public function allChecks()
    {
        if(!$this->callBackUrl || !$this->merchantId || !$this->merchantKey ||  !$this->baseurl )
        {
            echo "Please update your plugin settings";
            exit;
        }
    }

    public function XSign($requestParams=[])
    {
        $headers = [
            'X-Merchant-Id' => $this->merchantId,
            'X-Timestamp' => time(),
            'X-Nonce' => md5(uniqid(mt_rand(),true)),
           ];

        $requestParams = $requestParams;
        $mergedParams = array_merge($requestParams,$headers);
        ksort($mergedParams);

        
        $hashString = http_build_query($mergedParams);
        $XSign = hash_hmac('sha1', $hashString,$this->merchantKey);
        $headers['X-Sign'] = $XSign;
        return $headers;

    }

    public function get_games($endpoint = 'games?expand=tags,parameters,images,related_games',$page=1)
    {
        $this->allChecks();

        $url = $this->baseurl . $endpoint ; // Assuming this is how the API URL is structured
        $params = [];
        if(isset($_GET['currentPage']))
        {
            $next = $_GET['currentPage'];
            $url .= "&page=$next";
            $params['page'] = $next;
            $url .='&expand=tags,parameters,images,related_games,category';
            $params['expand'] = 'tags,parameters,images,related_games,category';
        }
        else
        {
            $url .= "&page=$page";
            $params['page'] = $page;
            $url .='&expand=tags,parameters,images,related_games,category';
            $params['expand'] = 'tags,parameters,images,related_games,category';

        }
        $headers = $this->XSign($params);
        $response = wp_remote_get($url, [
            'headers' => $headers,
            'timeout' => 30, // Increase the timeout (default is 5 seconds)
        ]);
        // Handle response
        if (is_wp_error($response)) {
            echo $response->get_error_message();
            return ['error' => $response->get_error_message()];
        }
        $data = wp_remote_retrieve_body($response);
        $games = json_decode($data, true); // Assuming the response is JSON

 

        return $games;
    }

    public function gameLobby($param=[],$gameId)
    {
        
        $url = $this->baseurl . 'games/lobby' . "?game_uuid=$gameId&currency=EUR"  ; // Assuming this is how the API URL is structured
        $headers = $this->XSign([
            'game_uuid' => $gameId,
            'currency' => 'EUR'
        ]);
        
        $response = wp_remote_get($url, [
            'headers' => $headers
        ]);


        // Handle response
        if (is_wp_error($response)) {
            return ['error' => $response->get_error_message()];
        }
        $data = wp_remote_retrieve_body($response);
        $games = json_decode($data, true); // Assuming the response is JSON
   
        return $games;
    }


    public function initGame($params=[])
    {   
        $game_uuid = $params['game_uuid'];
        $currency = $params['currency'];
        $player_id = $params['player_id'];
        $player_name = $params['player_name'];
        $return_url = $params['return_url'];
        $language = $params['language'];
        $client_callback_endpoint = $params['client_callback_endpoint'];
        $server_ip = $_SERVER['SERVER_ADDR'];
        $params['server_ip'] = $server_ip;


        $url = $this->baseurl . 'games/init'; // The URL for the API
        
        $headers = $this->XSign($params);
        
        // Prepare data to be sent in the POST body
        $body = [

            'game_uuid' => $game_uuid,
            'currency' => $currency,
            'player_id' => $player_id,
            'player_name' => $player_name,
            'session_id' => $params['session_id'],
            'return_url' => $return_url,
            'language' => $language,
            'client_callback_endpoint' => $client_callback_endpoint,
            'server_ip' => $server_ip
        ];
         
         

        // Send a POST request with the body parameters
        $response = wp_remote_post($url, [
            'headers' => $headers,
            'body'    => $body
        ]);

        // Handle the response
        if (is_wp_error($response)) {
            return ['error' => $response->get_error_message()];
        }

        $data = wp_remote_retrieve_body($response);
      
        // Assuming the response is JSON
        $games = json_decode($data, true); 

        return $games;
    }


    public function getBalance($endpoint = 'balance')
    {
        $current_user = wp_get_current_user();
        $user_id = 'WPUser_' . $current_user->ID; // WordPress User ID
        $username = $current_user->user_login; // WordPress Username
        $session_id = '57F909D572E64A88B9ED97E18FC52134';

        $url = $this->baseurl . $endpoint . "?player_id=$user_id&currency=USD&session_id=$session_id&action=balance" ; // Assuming this is how the API URL is structured
 
        $params = [
            'player_id' => $user_id,
            'currency' => 'USD',
            'session_id' => $session_id,
            'action' => 'balance'
        ];
        $headers = $this->XSign($params);
        $response = wp_remote_get($url, [
            'headers' => $headers,
            'timeout' => 30, // Increase the timeout (default is 5 seconds)

        ]);
        // Handle response
        if (is_wp_error($response)) {
            return ['error' => $response->get_error_message()];
        }
        $data = wp_remote_retrieve_body($response);
        $games = json_decode($data, true); // Assuming the response is JSON
        return $games;
    }

    public function getLimits($endpoint = 'limits')
    {
        
        $url = $this->baseurl . $endpoint ;
        $params = [
        ];  
       
        $headers = $this->XSign($params);
      
        $response = wp_remote_get($url, [
            'headers' => $headers
        ]);



        // Handle response
        if (is_wp_error($response)) {
            return ['error' => $response->get_error_message()];
        }
       
        $data = wp_remote_retrieve_body($response);

        $games = json_decode($data, true); // Assuming the response is JSON

        return $games;
    }
    
    public function getLimitFreeSpin($endpoint = 'limits/freespin')
    {
        
        $url = $this->baseurl . $endpoint ;
 
        $params = [
        ];
       
        $headers = $this->XSign($params);
      
        $response = wp_remote_get($url, [
            'headers' => $headers
        ]);
        // Handle response
        if (is_wp_error($response)) {
            return ['error' => $response->get_error_message()];
        }
       
        $data = wp_remote_retrieve_body($response);

        $games = json_decode($data, true); // Assuming the response is JSON

        return $games;
    }

    public function jackpots($endpoint = 'jackpots')
    {
        
        $url = $this->baseurl . $endpoint;
 
        $params = [
        ];
       
        $headers = $this->XSign($params);
      
        $response = wp_remote_get($url, [
            'headers' => $headers
        ]);
        // Handle response
        if (is_wp_error($response)) {
            return ['error' => $response->get_error_message()];
        }
        $data = wp_remote_retrieve_body($response);

        $games = json_decode($data, true); // Assuming the response is JSON

        return $games;
    }

}


?>
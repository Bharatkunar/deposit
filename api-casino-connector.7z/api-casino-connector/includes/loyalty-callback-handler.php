<?php

class Loyalty_CallBack_Handler
{
    private $callBackUrl;
    private $loyaltyController;
    public $gameController;
    public function __construct()
    {
        add_action('wp_ajax_play_game', [$this, 'handle_play_game']);
        add_action('wp_ajax_nopriv_play_game', [$this, 'handle_play_game']);
        $this->callBackUrl  = get_option('casino_callback_url');

        $this->loyaltyController = new LoyaltyApiHanlder();
        $this->gameController = new Game_Controller();
    }

    public function get_call_back_actions()
    {

        $array = [
            'free_play_visit',
            'my_offers',
            'transaction_history',
            'egift_offer',
            'leader_board',
            'referal_stats',
            'home_page',
            'survey',
            'location'
        ];

        wp_send_json([
            'status' => 200,
            'message' => 'success',
            'data' => $array
        ]);
    }

    public function syncAllApis()
    {
       
       $loyaltyController = new LoyaltyApiHanlder(); // Create an instance here

       $freePlayData =  $loyaltyController->freePlayVisits('automation'); // Use instance here

       $getTransactionHistory = $loyaltyController->getTransactionHistory('automation'); // Use instance here


       $egiftOffers =  $loyaltyController->eGiftOffers('automation');


       $getLeaderBoard = $loyaltyController->getLeaderBoard('automation');



       $referalStats = $loyaltyController->referalStats('automation');


       $homepage = $loyaltyController->homePage('automation');


        
       $getSurveys = $loyaltyController->getSurveys('automation');



       $location = $loyaltyController->getLocation('automation');


    }

    // Function to handle the callback API
    public static function handle_callback($request)
    {
        global $wpdb;



        $loyaltyController = new LoyaltyApiHanlder(); // Create an instance here

        $action = $request->get_param('action');
        $loyalty_contact = $request->get_param('loyalty_contact');
       
        $table = $wpdb->prefix . 'loyalty_webhook_calls';
        $tableArray = [
            'data'      => json_encode($request->get_params(),true),
            'action'    => $action,
            'contact_id' => $loyalty_contact
        ];
        $insert = $wpdb->insert($table, $tableArray);
        if (false === $insert) {
            // Insert failed – show error message
            echo '<pre>';
            echo 'Insert failed: ' . $wpdb->last_error . "\n";
            echo 'Query: ' . $wpdb->last_query . "\n";
            echo 'Data: ';
            print_r($tableArray);
            echo '</pre>';
        } else {
            echo 'Insert successful. Insert ID: ' . $wpdb->id;
        }
       
        switch ($action) {
            case 'free_play_visit':
                $loyaltyController->freePlayVisits(); // Use instance here
            case 'my_offers':
                $loyaltyController->myOffers(); // Use instance here
            case 'transaction_history':
                $loyaltyController->getTransactionHistory(); // Use instance here
            case 'egift_offer':
                $loyaltyController->eGiftOffers();
            case 'leader_board':
                $loyaltyController->getLeaderBoard();
            case 'referal_stats':
                $loyaltyController->referalStats();
            case 'home_page':
                $loyaltyController->homePage();
            case 'survey':
                $loyaltyController->getSurveys();
            // case 'popup_message':
            //     $loyaltyController->fetchPopups();
            case 'location':
                $loyaltyController->getLocation();
            case 'popup_transaction':
                $contact_id = $request->get_param('ContactID');
      
                // Get the contact_id of the currently logged-in user
                $row = $wpdb->get_row("
                    SELECT *
                    FROM wp_usermeta
                    WHERE meta_value = '{$contact_id}'
                    LIMIT 1
                ", ARRAY_A);

                // Check if query failed
                if ( $row === null ) {
                    echo "❌ Query failed or returned no results.<br>";
                    echo "MySQL Error: " . $wpdb->last_error . "<br>";
                    echo "Last SQL: " . $wpdb->last_query . "<br>";
                }
                else
                {
                    $user_id = $row['user_id'];
                }


           
                update_user_meta($user_id, 'show_popup_7330', true);
                update_user_meta($user_id, 'loyalty_offer_id', $_GET['OfferID']);

                // Retrieve Offer Details Now

                $offerData = $loyaltyController->viewOfferById($_GET['OfferID']);
                       
           
                $offerData = $offerData['responsedata'];
          
         




                update_user_meta($user_id, 'loyalty_offer_description', $offerData['offerDescription'] );



                $options = [
                    'cluster' => 'ap2',
                    'useTLS' => true,
                ];
                
                $pusher = new Pusher\Pusher(
                    '4994bb580820ff5f007d',  // ✅ Your app key
                    '86252a33d136259f80fc',  // ✅ Your secret
                    '2016674',               // ✅ Your app ID
                    $options                 // ✅ Cluster and TLS settings
                );
                
                // ✅ Sends a custom event to user-<user_id> channel
                $pusher->trigger('user-' . $user_id, 'popup-7330', [
                    'offer_id' => $_GET['OfferID'] ?? null,
                    'loyalty_offer_description' => $offerData['offerDescription'],
                    'contactid' => $contact_id
                ]);

                break;

            case 'get_actions':
                $array = [
                    'free_play_visit',
                    'my_offers',
                    'transaction_history',
                    'egift_offer',
                    'leader_board',
                    'referal_stats',
                    'home_page',
                    'survey',
                    'location'
                ];

                wp_send_json([
                    'status' => 200,
                    'message' => 'success',
                    'data' => $array
                ]);
            default:
                new WP_REST_Response('Unknown action.', 400);
        }

        return wp_send_json([
            'status' => 200,
            'message' => 'success',
            'action' => $action
        ]);
    }

    public static function get_games(WP_REST_Request $request)
    {
        global $wpdb;

        $games_table       = $wpdb->prefix . "casino_games";
        $game_type         = $wpdb->prefix . "casino_game_type";
        $game_provider     = $wpdb->prefix . "casino_game_provider";
        $game_technology   = $wpdb->prefix . "casino_game_technology";

        // Pagination
        $page      = isset($_REQUEST['page']) ? max(1, (int) $_REQUEST['page']) : 1;
        $per_page  = isset($_REQUEST['per_page']) ? (int) $_REQUEST['per_page'] : 10;
        $offset    = ($page - 1) * $per_page;

        $conditions = [];

        // Filters
        if (!empty($_REQUEST['type']) && $_REQUEST['type'] !== 'All') {
            $type = (int) $_REQUEST['type'];
            $conditions[] = "g.type = $type";
        }
        if (!empty($_REQUEST['provider']) && $_REQUEST['provider'] !== 'All') {
            $provider = (int) $_REQUEST['provider'];
            $conditions[] = "g.provider = $provider";
        }
        if (!empty($_REQUEST['technology']) && $_REQUEST['technology'] !== 'All') {
            $technology = (int) $_REQUEST['technology'];
            $conditions[] = "g.technology = $technology";
        }
        if (isset($_REQUEST['enabled']) && $_REQUEST['enabled'] !== 'All') {
            $enabled = esc_sql($_REQUEST['enabled']);
            $conditions[] = "g.enabled = '$enabled'";
        }

        // WHERE clause
        $where = !empty($conditions) ? "WHERE " . implode(" AND ", $conditions) : "";

        // Main query with LIMIT and OFFSET
        $query_game = "
        SELECT g.*, t.name AS type_name, p.name AS provider_name, tech.name AS technology_name
        FROM $games_table g
        LEFT JOIN $game_type t ON g.type = t.id
        LEFT JOIN $game_provider p ON g.provider = p.id
        LEFT JOIN $game_technology tech ON g.technology = tech.id
        $where
        LIMIT %d OFFSET %d
    ";

        // Prepare the paginated query
        $query_game = $wpdb->prepare($query_game, $per_page, $offset);
        $games = $wpdb->get_results($query_game);

        // Count total results for pagination
        $count_query = "
        SELECT COUNT(*) FROM $games_table g
        LEFT JOIN $game_type t ON g.type = t.id
        LEFT JOIN $game_provider p ON g.provider = p.id
        LEFT JOIN $game_technology tech ON g.technology = tech.id
        $where
    ";
        $total_items = $wpdb->get_var($count_query);
        $total_pages = ceil($total_items / $per_page);

        return wp_send_json([
            'status'     => 200,
            'message'    => 'success',
            'data'       => $games,
            'pagination' => [
                'current_page' => $page,
                'per_page'     => $per_page,
                'total_items'  => (int) $total_items,
                'total_pages'  => $total_pages
            ]
        ]);
    }

    public static function getGameFiltersList(WP_REST_Request $request)
    {
        global $wpdb;

        $response = [];
        $game_type        = $wpdb->prefix . "casino_game_type";
        $game_provider    = $wpdb->prefix . "casino_game_provider";
        $game_technology  = $wpdb->prefix . "casino_game_technology";

        // Check if type is requested
        if ($request->get_param('type')) {
            $response['types'] = $wpdb->get_results("SELECT id, name FROM $game_type ORDER BY name ASC");
        }

        // Check if provider is requested
        if ($request->get_param('provider')) {
            $response['providers'] = $wpdb->get_results("SELECT id, name FROM $game_provider ORDER BY name ASC");
        }

        // Check if technology is requested
        if ($request->get_param('technology')) {
            $response['technologies'] = $wpdb->get_results("SELECT id, name FROM $game_technology ORDER BY name ASC");
        }

        if (empty($response)) {
            return wp_send_json([
                'status'  => 400,
                'message' => 'No valid filter requested. Use ?type=1, ?provider=1 or ?technology=1'
            ]);
        }

        return wp_send_json([
            'status'  => 200,
            'message' => 'success',
            'data' => $response
        ]);
    }

    public static function get_shortcode_list(WP_REST_Request $request)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'casino_game_short_codes';

        // Get page and per_page from request, with defaults
        $page      = isset($_REQUEST['page']) ? max(1, (int) $_REQUEST['page']) : 1;
        $per_page = (int) $request->get_param('per_page') ?: 10;
        $offset   = ($page - 1) * $per_page;

        // Main paginated query
        $query = $wpdb->prepare("SELECT * FROM $table LIMIT %d OFFSET %d", $per_page, $offset);
        $shortcodes = $wpdb->get_results($query);

        // Get total count
        $total_items = $wpdb->get_var("SELECT COUNT(*) FROM $table");
        $total_pages = ceil($total_items / $per_page);

        return wp_send_json([
            'status'     => 200,
            'message'    => 'success',
            'data' => $shortcodes,
            'pagination' => [
                'current_page' => $page,
                'per_page'     => $per_page,
                'total_items'  => (int) $total_items,
                'total_pages'  => $total_pages
            ]
        ]);
    }
    public static function create_shortcode(WP_REST_Request $request)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'casino_game_short_codes';

        $raw = $request->get_params();

        // Safely cast string to array if needed
        $json_attributes = [
            'type' => !empty($raw['type']) ? (array) $raw['type'] : [],
            'provider' => !empty($raw['provider']) ? (array) $raw['provider'] : [],
            'technology' => !empty($raw['technology']) ? (array) $raw['technology'] : [],
            'games' => $raw['games'] ?? '50',
            'rows' => $raw['rows'] ?? '4',
            'columns' => $raw['columns'] ?? '13',
            'size_of_images' => isset($raw['size_of_images']) ? (int)$raw['size_of_images'] : 0,
        ];

        // Optional extra values
        $use_slider = $raw['use_slider'] ?? 'yes';
        $slider_type_auto = $raw['slider_type_auto'] ?? '1';
        $title = $raw['title'] ?? 'SLOTS';
        $live = $raw['live'] ?? '1';

        $type = $json_attributes['type'][0] ?? '1';

        // Build shortcode string
        $shortcode = "[casino_all_active_games games='{$json_attributes['games']}' rows='{$json_attributes['rows']}' columns='{$json_attributes['columns']}' type='{$type}' use_slider='{$use_slider}' slider_type_auto='{$slider_type_auto}' title='{$title}' live='{$live}']";

        // Check for duplicates
        $existing = $wpdb->get_row($wpdb->prepare("SELECT id FROM $table WHERE shortcode = %s", $shortcode));
        if ($existing) {
            return wp_send_json([
                'status' => 400,
                'message' => 'Shortcode already exists.'
            ]);
        }

        // Save to database
        $wpdb->insert($table, [
            'shortcode' => $shortcode,
            'json_attributes' => json_encode($json_attributes),
            'num_of_columns' => (int) $json_attributes['columns'],
            'num_of_rows' => (int) $json_attributes['rows'],
            'total_records' => (int) $json_attributes['games'],
            'size_of_images' => $json_attributes['size_of_images'],
            'use_slider' => $use_slider === 'yes' ? 1 : 0,
            'slider_type_auto' => (int) $slider_type_auto,
            'shortcode_title' => $title,
            'show_title' => 1,
            'active' => (int) $live
        ]);

        return wp_send_json([
            'status' => 200,
            'message' => 'Shortcode created successfully.'
        ]);
    }

    public static function get_single_shortcode(WP_REST_Request $request)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'casino_game_short_codes';

        // Get the input
        $input = $request->get_param('shortcode');

        if (is_numeric($input)) {
            // Search by ID
            $result = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $input));
        } else {
            // Search by shortcode string
            $result = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE shortcode_title = %s", $input));
        }


        $json_attributes = json_decode($result->json_attributes, true);
        $filters = [];
        if (!empty($json_attributes['type'])) {
            $filters['type'] = implode(',', $json_attributes['type']); // WPDB expects comma-separated string for IN()
        }
        
        // Add 'provider' filter if present
        if (!empty($json_attributes['provider'])) {
            $filters['provider'] = implode(',', $json_attributes['provider']);
        }
        
        // Add 'technology' filter if present
        if (!empty($json_attributes['technology'])) {
            $filters['technology'] = implode(',', $json_attributes['technology']);
        }
        
        // Add 'games' filter (limit) if present
        if (!empty($json_attributes['games'])) {
            $filters['games'] = $json_attributes['games'];
        }
        
        // Optional offset (e.g., 0)
        $offset = 0;

        $gameController = new Game_Controller();
        
        // Call the function with the prepared filters
        $games = $gameController->getFilteredGames($filters, $offset);

        $result->games = $games;
        // If found, return
        if ($result) {
            return wp_send_json([
                'status' => 200,
                'message' => 'Shortcode found.',
                'data' => $result
            ]);
        } else {
            return wp_send_json([
                'status' => 404,
                'message' => 'Shortcode not found.'
            ]);
        }
    }
}

$loyaltyCallBackHandler = new Loyalty_CallBack_Handler();


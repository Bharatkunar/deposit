<?php
class Casino_Auth_Controller
{

    private $loyaltyController;

    public function __construct()
    {
        // Hook into init to handle form submissions
        add_action('wp_ajax_nopriv_casino_register_user', array($this, 'handle_registration'));
        add_action('wp_ajax_casino_register_user', array($this, 'handle_registration'));


        add_action('wp_ajax_casino_login_user', array($this, 'casino_login_user'));
        add_action('wp_ajax_nopriv_casino_login_user', array($this, 'casino_login_user'));

        add_action('wp_ajax_casino_verify_otp', array($this, 'casino_verify_otp'));
        add_action('wp_ajax_nopriv_casino_verify_otp', array($this, 'casino_verify_otp'));



        add_action('wp_ajax_casino_forget_password', array($this, 'casino_forget_password'));
        add_action('awp_ajax_nopriv_forget_password', array($this, 'casino_forget_password'));


        // Initialize Loyalty Controller Here

        $this->loyaltyController = new LoyaltyApiHanlder();
    }

    // Handle Registration Form Submission
    public function handle_registration()
    {
        global $wpdb;

        $username     = sanitize_user($_POST['username'] ?? '');
        $email        = sanitize_email($_POST['email'] ?? '');
        $password     = sanitize_text_field($_POST['password'] ?? '');
        $mobilePhone  = sanitize_text_field($_POST['mobilePhone'] ?? '');

        if (empty($username) || empty($email) || empty($password) || empty($mobilePhone)) {
            wp_send_json_error(['message' => 'All fields are required.']);
            wp_die();
        }

        if (username_exists($username) || email_exists($email)) {
            wp_send_json_error(['message' => 'User already exists.']);
            wp_die();
        }

        $user_id = wp_create_user($username, $password, $email);
        if (is_wp_error($user_id)) {
            wp_send_json_error(['message' => 'Error creating user: ' . $user_id->get_error_message()]);
            wp_die();
        }

        $user = get_userdata($user_id);
        $user->set_role('game_customer');

        $wpdb->insert(
            $wpdb->prefix . 'casino_balance',
            [
                'player_id' => $user_id,
                'last_balance' => 0,
                'current_balance' => 100,
                'balance_in' => 100,
            ]
        );

        $userMeta = [
            'user_id'     => $user_id,
            'username'    => $username,
            'email'       => $email,
            'mobilePhone' => $mobilePhone
        ];

        try {
            $response = $this->loyaltyController->preGenerateOtp($userMeta);
        } catch (Exception $e) {
            error_log('OTP generation failed: ' . $e->getMessage());
            wp_send_json_error(['message' => 'User registered, but OTP could not be sent.']);
            wp_die();
        }

        if (session_status() === PHP_SESSION_NONE) session_start();
        $_SESSION['my_data'] = array_merge($userMeta, [
            'password' => $password,
            'otpVerificationId' => $response['otpVerificationId'] ?? null
        ]);

        wp_send_json_success([
            'message' => 'Registration successful. OTP sent.',
            'data' => [
                'userId' => $user_id,
                'otpSent' => true,
                'via' => 'phone',
                'otpMeta' => $response
            ]
        ]);
        wp_die();
    }

    // Handle OTP Verification
    public function casino_verify_otp()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();

        if (!isset($_SESSION['my_data'])) {
            echo json_encode(['success' => false, 'message' => 'Session expired or invalid.']);
            exit;
        }

        $data = $_SESSION['my_data'];
        $otp = $_POST['otp'] ?? '';


        $rpToken = get_option('casino_roboreward_token');
        $webFormID = get_option('WEBFROMID');
        $rewardProgramIDNew = get_option('casino_rpID');
        $casino_contactListID = get_option('casino_contactListID');


        $payload = [
            'firstName' => $data['username'],
            'emailAddress' => $data['email'],
            'password' => $data['password'],
            'confirmPassword' => $data['password'],
            'RewardProgramToken' => $rpToken,
            'rewardProgramIDNew' => $rewardProgramIDNew,
            'contactListID' => $casino_contactListID,
            'webFormID' => $webFormID,
            'OtpVerificationId' => $data['otpVerificationId'],
            'mobilePhone' => $data['mobilePhone'],
            'Otp' => $otp
        ];


        // echo "payload";
        // echo "<pre>";
        // print_r($payload);
        // echo "</pre>";
     

   

        $response = $this->loyaltyController->makeApiRequest('PreLoginUser/JoinNow', 'POST', $payload);

        // echo "response";
        // echo "<pre>";
        // print_r($response);
        // echo "</pre>";
        // wp_die();

        
        if (isset($response['statusCode']) && $response['statusCode'] == 1) {
            $newData = json_decode($response['responsedata'], true);

            if (!empty($newData['contactID']) && !empty($data['user_id'])) {
                update_user_meta($data['user_id'], 'contact_id', sanitize_text_field($newData['contactID']));

                $this->loyaltyController->sendFeedbackToLoyalty('IGaming/CallBack?action=add_new_user', 'POST', [
                    'wordpress_user_id' => $data['user_id'],
                    'contactId' => $newData['contactID'],
                    'rpid' => $rpToken,
                    'current_balance' => 100
                ]);
            }
            wp_send_json_success([
                'message' => 'Otp verification successfull',
                'redirect' => home_url('/dashboard/')           
            ]);
            wp_die();
        } else {
            wp_send_json_error([
                'message' => 'OTP verification failed',
                'redirect' => home_url('/dashboard/') 
            ]);
            wp_die();
        }
    }

    // public function casino_login_user()
    // {

    //     // Verify the nonce field for security
    //     if (!isset($_POST['casino_login_nonce_field']) || !wp_verify_nonce($_POST['casino_login_nonce_field'], 'casino_login_nonce')) {
    //         wp_redirect(home_url()); // redirect to homepage if nonce is not valid
    //         exit;
    //     }


    //     // Collect the username/email and password
    //     $username = sanitize_text_field($_POST['username']);
    //     $password = sanitize_text_field($_POST['password']);



    //     // Authenticate the user
    //     $user = wp_authenticate($username, $password);


    //     $contact_id = get_user_meta($user->ID, 'contact_id', true);
    //     $user_id = get_current_user_id();


    //     // Check if authentication was successful
    //     if (is_wp_error($user)) {
    //         $error_message = $user->get_error_message();
    //         wp_redirect(add_query_arg(array('message' => $error_message, 'status' => 'error'), home_url('/login/')));
    //     }


    //     // If successful, log the user in
    //     wp_set_auth_cookie($user->ID);

    //     // Redirect the user to the dashboard or desired page
    //     wp_redirect(home_url('/dashboard/'));

    //     // Option 2 (Better): Store in PHP session if session is being used
    //     // session_start(); // only if not staFrted
    //     $_SESSION['contact_id'] = $contact_id;
    //     $_SESSION['user_id'] = $user_id;

    //     exit;
    // }

    public function casino_login_user()
    {
        // Check nonce
        // if (
        //     !isset($_POST['casino_login_nonce_field']) ||
        //     !wp_verify_nonce($_POST['casino_login_nonce_field'], 'casino_login_nonce')
        // ) {
        //     wp_send_json_error([
        //         'message' => 'Security verification failed. Please refresh the page and try again.'
        //     ]);
        // }

        // Sanitize inputs
        $username = sanitize_text_field($_POST['email'] ?? '');
        $password = sanitize_text_field($_POST['password'] ?? '');

        // Authenticate user
        $user = wp_authenticate($username, $password);

        if (is_wp_error($user)) {
            wp_send_json_error([
                'message' => $user->get_error_message()
            ]);
        }

        // Set login cookies
        wp_set_auth_cookie($user->ID);
        wp_set_current_user($user->ID);

        // Optional session logic
        $contact_id = get_user_meta($user->ID, 'contact_id', true);
        $_SESSION['contact_id'] = $contact_id;
        $_SESSION['user_id'] = $user->ID;

        $customArray = array(
            'username' => $username,
            'password' => $password,
            'rewardProgramToken' => get_option('casino_roboreward_token')
        );


        $response = $this->loyaltyController->makeApiRequest('PreLoginUser/SignInNow', 'POST', $customArray);


        $_SESSION['loyalty'] = $response['responsedata']['contactData'];




        // Send success response
        wp_send_json_success([
            'message' => 'Login successful',
            'redirect' => home_url('/dashboard/')
        ]);
    }


    public function casino_forget_password()
    {
        // Check nonce
        if (
            !isset($_POST['casino_login_nonce_field']) ||
            !wp_verify_nonce($_POST['casino_login_nonce_field'], 'casino_login_nonce')
        ) {
            wp_send_json_error([
                'message' => 'Security verification failed. Please refresh the page and try again.'
            ]);
        }

        // Sanitize inputs
        $username = sanitize_text_field($_POST['email'] ?? '');
        $password = sanitize_text_field($_POST['password'] ?? '');

        // Authenticate user
        $user = wp_authenticate($username, $password);

        if (is_wp_error($user)) {
            wp_send_json_error([
                'message' => $user->get_error_message()
            ]);
        }

        // Set login cookies
        wp_set_auth_cookie($user->ID);
        wp_set_current_user($user->ID);

        // Optional session logic
        $contact_id = get_user_meta($user->ID, 'contact_id', true);
        $_SESSION['contact_id'] = $contact_id;
        $_SESSION['user_id'] = $user->ID;

        // Send success response
        wp_send_json_success([
            'message' => 'Login successful',
            'redirect' => home_url('/dashboard/')
        ]);
    }

}

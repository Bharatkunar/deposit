<?php
class Logger {
    public static function log($message) {
    }
}
?>
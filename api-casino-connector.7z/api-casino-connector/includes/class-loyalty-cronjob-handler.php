<?php
class API_ROYALTY_CRONJOB_HANDLER
{
    public $royaltyApi;
    public $loyaltyShortcode;
    private static $instance = null;
    private $callbacks = [];

    public static function get_instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    private function __construct()
    {

        // Initialize other classes
        $this->royaltyApi = new LoyaltyApiHanlder();
        $this->loyaltyShortcode = new RoboRewardLoyaltyShortCodeHandler();
        // Add cron job hooks
        add_action('wp_cronjob_hit_callbacks', [$this, 'hit_callbacks']);
        $this->callback = [
            'free_play_visit',
            'my_offers',
            'transaction_history',
            'egift_offer',
            'leader_board',
            'referal_stats',
            'home_page',
            'survey',
            'location'
        ];
    }
    function hit_callbacks()
    {
        $callbacks = [
            'free_play_visit',
            'my_offers',
            'transaction_history',
            'egift_offer',
            'leader_board',
            'referal_stats',
            'home_page',
            'popup_message',
            'survey',
            'location'
        ];

        foreach ($callbacks as $callback) {
            $url = get_site_url(null, "/wp-json/api-loyalty/v1/callback?action=" . $callback);
            // Making a GET request
            $response = wp_remote_get($url);

            // Check if request was successful
            if (is_wp_error($response)) {
                error_log("Error hitting callback: $callback - " . $response->get_error_message());
            } else {
                $body = wp_remote_retrieve_body($response);
                error_log("Callback $callback hit successfully. Response: " . $body);
            }
        }
    }
}
// Initialize the CronJob handler
$loyaltyObject = API_ROYALTY_CRONJOB_HANDLER::get_instance();

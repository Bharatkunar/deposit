<?php
class Game_Short_Code_Hanlder {
    public $gameController;
    public function __construct() {
        // Register shortcodes
        // add_shortcode('casino_all_active_games', array($this, 'casino_all_games_shortcode'));
        add_shortcode('casino_all_active_games', array($this, 'casino_all_games_2_shortcode'));
        add_shortcode('casino_search_popup', array($this, 'casino_search_popup_shortcode'));
        add_shortcode('my-shortcode', array($this, 'my_new_shortcode'));
        add_shortcode('my-EGiftOffers-Avada', array($this, 'EGiftOffers_Avada'));
        add_shortcode('ReferFriends-Avada', array($this, 'ReferFriends_Avada'));
        add_shortcode('TransactionHistory-Avada', array($this, 'TransactionHistory_Avada'));
        add_shortcode('LeaderBoard-Avada', array($this, 'LeaderBoard_Avada'));
        add_shortcode('Referrals-Avada', array($this, 'Referrals_Avada'));
        add_shortcode('location-Avada', array($this, 'location_Avada'));
        add_shortcode('profile-avada', array($this, 'profile_avada'));

       

        // Add custom query vars for pagination
        add_filter('query_vars', array($this, 'add_query_vars_filter'));

        // Add rewrite rules for custom pagination URL structure
        add_action('init', array($this, 'custom_rewrite_rules'));


        $this->gameController = new Game_Controller();

    }

    // Handle adding custom query vars for pagination
    function add_query_vars_filter($vars) {
        $vars[] = 'page_num'; // Register the 'page_num' query var for pagination
        return $vars;
    }

    // Custom rewrite rules to change URL structure (e.g., /page/2/ instead of ?page=2)
     // Custom rewrite rules to change URL structure (e.g., /page/2/ instead of ?page=2)
     function custom_rewrite_rules() {
        add_rewrite_rule('^casino/page/([0-9]+)/?', 'index.php?page_num=$matches[1]', 'top');
    }

    // Get Filtered Games
    public function getFilteredGames($filters = [], $offset = 0, $limit = 250) {
        global $wpdb;

      
    
        $game_table = $wpdb->prefix . "casino_games";
        $game_type = $wpdb->prefix . "casino_game_type";
        $game_provider = $wpdb->prefix . "casino_game_provider";
        $game_technology = $wpdb->prefix . "casino_game_technology";
        $game_lobby = $wpdb->prefix . "casino_game_lobby";
    
        $query_game = "SELECT 
                        g.*, 
                        COUNT(l.id) AS totalLobby, /* Count of lobbies for each game */
                        t.name AS type_name, 
                        p.name AS provider_name, 
                        tech.name AS technology_name
                    FROM $game_table g
                    LEFT JOIN $game_type t ON g.type = t.id
                    LEFT JOIN $game_provider p ON g.provider = p.id
                    LEFT JOIN $game_technology tech ON g.technology = tech.id
                    LEFT JOIN $game_lobby l ON g.id = l.local_game_id";
    
        $where_clauses = ["g.enabled = 1"]; // Start with base condition
        $params = [];
    
        // Add filters dynamically
        if (!empty($filters['type'])) {
            // $where_clauses[] = "g.name = %s";

            $type_in = $filters['type']; // Convert to integer for security
            $params[] = $type_in;

            $where_clauses[] = "g.type IN (%s)";

        }
        if (!empty($filters['provider'])) {
            // $where_clauses[] = "p.name = %s";
            $provider_in = $filters['provider']; // Convert to integer for security
            $params[] = $provider_in;
            $where_clauses[] = "g.provider IN (%s)";
        }
        if (!empty($filters['technology'])) {
            // $where_clauses[] = "tech.name = %s";
            $technology_in = $filters['technology']; // Convert to integer for security
            $params[] = $technology_in;

            $where_clauses[] = "g.technology IN (%s)";
        }
    
        // Add WHERE clause if there are filters
        if (!empty($where_clauses)) {
            $query_game .= " WHERE " . implode(" AND ", $where_clauses);
        }


        // Add GROUP BY clause
        $query_game .= " GROUP BY 
                        g.id, g.name, g.type, g.provider, g.technology, 
                        t.name, p.name, tech.name";

    
        // Add LIMIT and OFFSET
        $limit = isset($filters['games']) ? absint($filters['games']) : 250;
        $offset = isset($offset) ? absint($offset) : 0;
    
        $query_game .= " LIMIT %d OFFSET %d";
        $params[] = $limit;
        $params[] = $offset;


        // echo "<br>";
        // echo "<br>";
        // echo "<br>";
        // echo "<br>";
        // echo $query_game;
    
    
        // Prepare and execute the query
        $prepared_query = $wpdb->prepare($query_game, $params);
        $results = $wpdb->get_results($prepared_query);

        // echo "<pre>";
        // print_r($results);
        // echo "</pre>";
        // exit;
    
        // Return the results
        return $results;
    }
    

    /**
     * The shortcode that displays all active games, with pagination and filtering.
     */
    
     public function casino_all_games_shortcode($atts) {
        // Extract attributes with default values
        $atts = shortcode_atts(
            [
                'type' => 'All',
                'provider' => 'All',
                'technology' => 'All',
                'games'      => 'All'
            ],
            $atts
        );
    
        // Get the current page from the URL (use the 'page_num' query var)
        $current_page = get_query_var('page_num') ? max(1, intval(get_query_var('page_num'))) : 1;
        $limit = 10; // Number of records per page
        $offset = ($current_page - 1) * $limit;
    
        // Set up filters for the query
        $filters = [];
        if ($atts['type'] !== 'All') {
            $filters['type'] = $atts['type'];
        }
        if ($atts['provider'] !== 'All') {
            $filters['provider'] = $atts['provider'];
        }
        if ($atts['technology'] !== 'All') {
            $filters['technology'] = $atts['technology'];
        }
        if ($atts['games'] !== 'All') {
            $filters['games'] = $atts['games'];
        }

   
    
        $games = $this->getFilteredGames($filters, $offset, $limit);
    
        // // Output HTML
        ob_start();
        // // if (!empty($games)) {
        // //     echo '<table border="1" class="wp-list-table widefat fixed striped">';
        // //     echo '<thead>
        // //             <tr>
        // //                 <th>Name</th>
        // //                 <th>Type</th>
        // //                 <th>Provider</th>
        // //                 <th>Technology</th>
        // //             </tr>
        // //           </thead>';
        // //     echo '<tbody>';
        // //     foreach ($games as $game) {
        // //         echo '<tr>';
        // //         echo '<td>' . esc_html($game->name) . '</td>';
        // //         echo '<td>' . esc_html($game->type_name) . '</td>';
        // //         echo '<td>' . esc_html($game->provider_name) . '</td>';
        // //         echo '<td>' . esc_html($game->technology_name) . '</td>';
        // //         echo '</tr>';
        // //     }
        // //     echo '</tbody>';
        // //     echo '</table>';
    
        // //     // Pagination Links
        // //     $total_games = 250; // Replace with the actual total number of games for pagination calculation
        // //     $total_pages = ceil($total_games / $limit);
    
        // //     echo '<div class="pagination">';
        // //     if ($current_page > 1) {
        // //         echo '<a href="' . home_url('/page/test/' . ($current_page - 1) . '/') . '" class="prev">Previous</a>';
        // //     }
        // //     if ($current_page < $total_pages) {
        // //         echo '<a href="' . home_url('/page/test/' . ($current_page + 1) . '/') . '" class="next">Next</a>';
        // //     }
        // //     echo '</div>';
        // // } else {
        // //     echo '<p>No games found for the selected filters.</p>';
        // // }
        include plugin_dir_path(__FILE__) . '../public/views/game/index.php';

        return ob_get_clean();
    }


    // Done By Bharat Kumar

    // public function loyaltySurveyAvadaShortCode($atts)
    // {
    //     ob_start();

    //     include plugin_dir_path(_FILE_) . '../loyalty-avada-shortcodes/survey-avada.php';
    //     return ob_get_clean();
    // }



  public function my_new_shortcode($atts){
         ob_start();

        include plugin_dir_path(__FILE__) . '../loyalty-avada-shortcodes/Loyalty-Profile-Avada-Bharat.php';

         return ob_get_clean();
   
}

// Done By Bharat Kumar

        public function EGiftOffers_Avada($atts){
                ob_start();
                include plugin_dir_path(__FILE__) . '../loyalty-avada-shortcodes/EGiftOffers-Avada.php';
                return ob_get_clean();
        }

        public function ReferFriends_Avada($atts){
                ob_start();
                // include plugin_dir_path(__FILE__) . '../loyalty-avada-shortcodes/Loyalty-Profile-Avada-Bharat.php';
                return ob_get_clean();
        }

        public function TransactionHistory_Avada($atts){
                ob_start();
                // include plugin_dir_path(__FILE__) . '../loyalty-avada-shortcodes/Loyalty-Profile-Avada-Bharat.php';
                return ob_get_clean();
        }

        public function LeaderBoard_Avada($atts){
                ob_start();
                // include plugin_dir_path(__FILE__) . '../loyalty-avada-shortcodes/Loyalty-Profile-Avada-Bharat.php';
                return ob_get_clean();
        }

        
        public function Referrals_Avada($atts){
                ob_start();
                // include plugin_dir_path(__FILE__) . '../loyalty-avada-shortcodes/Loyalty-Profile-Avada-Bharat.php';
                return ob_get_clean();
        }

        public function location_Avada($atts){
                ob_start();
                // include plugin_dir_path(__FILE__) . '../loyalty-avada-shortcodes/Loyalty-Profile-Avada-Bharat.php';
                return ob_get_clean();
        }

        public function profile_avada($atts){
                ob_start();
                // include plugin_dir_path(__FILE__) . '../loyalty-avada-shortcodes/Loyalty-Profile-Avada-Bharat.php';
                return ob_get_clean();
        }
    
        
    public function casino_all_games_2_shortcode($atts) {
        // Extract attributes with default values
        $atts = shortcode_atts(
            [
                'type' => 'All',
                'provider' => 'All',
                'technology' => 'All',
                'games'      => 25,
                'numb_of_columns' => $atts['cols'] ?? 0,
                'numb_of_rows' => $atts['rows'],
                "show_nav" => $atts['use_slider'],
                "autoplay" => $atts['slider_type_auto'],
                "live"     => $atts['live'],
                "title"    => $atts['title'],
                'show_title' => $atts['show_title'] ?? ''
            ],
            $atts
        );


        // Get the current page from the URL (use the 'page_num' query var)
        $current_page = get_query_var('page_num') ? max(1, intval(get_query_var('page_num'))) : 1;
        $limit = 10; // Number of records per page
        $offset = ($current_page - 1) * $limit;
    
        // Set up filters for the query
        $filters = [];
        if ($atts['type'] !== 'All') {
            $filters['type'] = $atts['type'];
        }
        if ($atts['provider'] !== 'All') {
            $filters['provider'] = $atts['provider'];
        }
        if ($atts['technology'] !== 'All') {
            $filters['technology'] = $atts['technology'];
        }
        if ($atts['games']) {
            $filters['games'] = $atts['games'];
        }
        if ($atts['numb_of_columns']) {
            $filters['numb_of_columns'] = $atts['numb_of_columns'];
        }
        if (isset($atts['live'])) {
            $filters['live'] = $atts['live'];
        }
        if (isset($atts['title'])) {
            $filters['title'] = $atts['title'];
        }
        if (isset($atts['numb_of_rows'])) {
            $filters['numb_of_rows'] = $atts['numb_of_rows'];
        }
   
        // Fetch games with filters
        $games = $this->gameController->getFilteredGames($filters, $offset, $atts['games']);
        $num_of_rows = max(1, intval($atts['numb_of_rows'])); // Ensure at least 1 row
        $numb_of_columns = max(1, intval($atts['numb_of_columns'])); // Ensure at least 1 column



        // Calculate total number of games
        $total_games = count($games);

        // Debugging: Output total games and number of rows/columns
        // echo "<br><br>Games: $total_games<br>";
        // echo "Rows & Columns: $num_of_rows, $numb_of_columns<br>";

        // Calculate games per row, ensuring at least 1 game per row
        $games_per_row = max(1, ceil($total_games / $num_of_rows));

        // Initialize shortcode content
        $shortcode_content = '<div id="spinner"></div>';
        $shortcode_content .= '<div class="shortcode_div">
          <style>
                .extra-margin {
                    margin-top: -50px !important;
                }
                body .fusion-image-carousel-fixed .awb-swiper .fusion-image-wrapper img {
                    width: 100% !important;
                    height: auto !important;
                    aspect-ratio: 16 / 9; /* Maintain wide aspect ratio */
                    object-fit: cover !important;
                }

                body div.fusion-image-wrapper img {
                    width: 100% !important;
                    height: auto !important;
                    aspect-ratio: 16 / 9;
                    object-fit: cover !important;
                }


           </style>
        ';
        if($atts['show_title'])
        {
            $title = $atts['title'];
            $shortcode_content .="
                <h1> $title </h1>
            ";
        }

        // Divide games into rows
        $rows = $total_games > 0 ? array_chunk($games, $games_per_row) : [];

        
        foreach ($rows as $row_index => $row) {

            $extra_class = ($row_index !== 0) ? ' extra-margin' : '';


            $columns_in_this_row = $atts['show_nav'] == 'yes' ? max(6, min(count($row), $numb_of_columns)):count($row); // Ensure at least 6 columns, but not more than specified number
            $autoplay = $atts['autoplay']?'yes':'no';
            $show_nav = $atts['show_nav']?'yes':'no';
            $shortcode_content .= '
            <a>View More</a>
            <div id="get_content"></div>
            [fusion_images picture_size="auto" class="my-class2' . $extra_class . '" columns="' . esc_attr($columns_in_this_row) . '" show_nav="' . $show_nav . '" autoplay="' . $autoplay . '"]';
        
            $counter = 1; // Counter for the images
            foreach ($row as $game) {
                $id = $game->id;
                $uuid = $game->uuid;
                $name = $game->name;
                $image = $game->image;
        
                $shortcode_content .= '[fusion_image  link="#" image_id="slider' . $counter . '" class="test' . $game->id . '" image="' . esc_url($image) . '?id=' . $uuid . '&local_id=' . $id . '&game=' . $name . '" alt="' . esc_attr($name) . '" /]';
                $counter++;
            }
        
            $shortcode_content .= '[/fusion_images]' ;
        }
        $shortcode_content .="</div>";
        // Return the processed shortcode output
        return do_shortcode($shortcode_content);
       
    }

    // Popup Shortcode

    public function casino_search_popup_shortcode()
    {
       return do_shortcode('[fusion_builder_container type="flex" hundred_percent="no" equal_height_columns="no" menu_anchor="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" class="" id="" background_color="" background_image="" background_position="center center" background_repeat="no-repeat" fade="no" background_parallax="none" parallax_speed="0.3" video_mp4="" video_webm="" video_ogv="" video_url="" video_aspect_ratio="16:9" video_loop="yes" video_mute="yes" overlay_color="" video_preview_image="" border_color="" border_style="solid" padding_top="" padding_bottom="" padding_left="" padding_right=""][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_color="" border_style="solid" border_position="all" spacing="yes" background_image="" background_repeat="no-repeat" padding_top="" padding_right="" padding_bottom="" padding_left="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="small-visibility,medium-visibility,large-visibility" center_content="no" last="true" min_height="" hover_type="none" link="" border_sizes_top="" border_sizes_bottom="" border_sizes_left="" border_sizes_right="" first="true"][fusion_text][casino_search_popup][/fusion_text][fusion_imageframe image_id="6537|full" aspect_ratio="" custom_aspect_ratio="100" aspect_ratio_position="" skip_lazy_load="" lightbox="no" gallery_id="" lightbox_image="" lightbox_image_id="" alt="" link="" linktarget="_self" hide_on_mobile="small-visibility,medium-visibility,large-visibility" sticky_display="normal,sticky" class="" id="" max_width="" sticky_max_width="" align_medium="none" align_small="none" align="none" mask="" custom_mask="" mask_size="" mask_custom_size="" mask_position="" mask_custom_position="" mask_repeat="" style_type="" blur="" stylecolor="" hue="" saturation="" lightness="" alpha="" hover_type="none" margin_top_medium="" margin_right_medium="" margin_bottom_medium="" margin_left_medium="" margin_top_small="" margin_right_small="" margin_bottom_small="" margin_left_small="" margin_top="" margin_right="" margin_bottom="" margin_left="" bordersize="" bordercolor="" borderradius="" z_index="" caption_style="off" caption_align_medium="none" caption_align_small="none" caption_align="none" caption_title="" caption_text="" caption_title_tag="2" fusion_font_family_caption_title_font="" fusion_font_variant_caption_title_font="" caption_title_size="" caption_title_line_height="" caption_title_letter_spacing="" caption_title_transform="" caption_title_color="" caption_background_color="" fusion_font_family_caption_text_font="" fusion_font_variant_caption_text_font="" caption_text_size="" caption_text_line_height="" caption_text_letter_spacing="" caption_text_transform="" caption_text_color="" caption_border_color="" caption_overlay_color="" caption_margin_top="" caption_margin_right="" caption_margin_bottom="" caption_margin_left="" animation_type="" animation_direction="left" animation_color="" animation_speed="0.3" animation_delay="0" animation_offset="" filter_hue="0" filter_saturation="100" filter_brightness="100" filter_contrast="100" filter_invert="0" filter_sepia="0" filter_opacity="100" filter_blur="0" filter_hue_hover="0" filter_saturation_hover="100" filter_brightness_hover="100" filter_contrast_hover="100" filter_invert_hover="0" filter_sepia_hover="0" filter_opacity_hover="100" filter_blur_hover="0"]http://localhost/casino/wp-content/uploads/bbb88760e95e0669bc9047ea3338ad72f64c6906.png[/fusion_imageframe][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container]');
    }


    // Get Registered ShortCodes

    function get_registered_shortcodes() {
        global $shortcode_tags;
    
        $shortcodes = [];
    
        foreach ($shortcode_tags as $shortcode => $callback) {
            if (strpos($shortcode, 'casino') === 0) {
                if (is_array($callback)) {
                    $reflection = new ReflectionMethod($callback[0], $callback[1]);
                } else {
                    $reflection = new ReflectionFunction($callback);
                }
    
                $doc_comment = $reflection->getDocComment();
                preg_match('/\*\s+(.+?)\s*\*/', $doc_comment, $matches);
                $description = isset($matches[1]) ? $matches[1] : 'No description available';
    
                $shortcodes[$shortcode] = [
                    'description' => $description
                ];
            }
        }
    
        return $shortcodes;
    }
    // 


    // E Gift Offers

    function eGiftOffers()
    {
        global $shortcode_tags;
    
        $shortcodes = [];
    
        foreach ($shortcode_tags as $shortcode => $callback) {
            if (strpos($shortcode, 'casino') === 0) {
                if (is_array($callback)) {
                    $reflection = new ReflectionMethod($callback[0], $callback[1]);
                } else {
                    $reflection = new ReflectionFunction($callback);
                }
    
                $doc_comment = $reflection->getDocComment();
                preg_match('/\*\s+(.+?)\s*\*/', $doc_comment, $matches);
                $description = isset($matches[1]) ? $matches[1] : 'No description available';
    
                $shortcodes[$shortcode] = [
                    'description' => $description
                ];
            }
        }
    
        return $shortcodes;

    }
}

// Initialize the handler
new Game_Short_Code_Hanlder();

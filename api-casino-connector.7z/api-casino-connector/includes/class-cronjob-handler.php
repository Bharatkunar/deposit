<?php
class API_CRONJOB_HANDLER {
    public $dbHandler;
    public $casinoApi;
    private static $instance = null;
    private $current_page_option = 'casino_current_page';
    private $per_page = 50;
    private $syncProduct;

    public static function get_instance() {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct() {

        // Initialize other classes
        $this->dbHandler = new DB_Handler();
        $this->casinoApi  = new CasinoApi();
        $this->loyalty = new LoyaltyApiHanlder();
        $this->syncProduct = get_option('casino_product_sync');
        // Add cron job hooks
        add_action( 'init', [ $this, 'schedule_cron_jobs' ] );
        add_action( 'wp_cronjob_fetch_products', [ $this, 'fetch_products' ] );
        add_action( 'wp_cronjob_products_pagination', [ $this, 'products_pagination' ] );
    }

    // Scheduling cron jobs
    public function schedule_cron_jobs() {
        if ( ! wp_next_scheduled( 'wp_cronjob_fetch_products' ) ) {
            wp_schedule_event( time(), 'every_five_minutes', 'wp_cronjob_fetch_products' );
        }
    }

    // Fetch products (pagination handled)
    public function fetch_products() {
        global $wpdb;
    
        $getCurrentPage = $wpdb->prepare("SELECT id, page FROM {$wpdb->prefix}casino_game_cronjob_pagination ORDER BY id DESC LIMIT 1");
        $result = $wpdb->get_results($getCurrentPage);
    
        $pageCount = count($result);
        $page = isset($result[0]->page) ? $result[0]->page : 1;
    
        $pageSize = 100;
    
        // Adjusted API call with query parameters
        $products = $this->loyalty->gameList("?PageNumber={$page}&PageSize={$pageSize}");
    
        $totalCount = $products['responsedata']['totalCount'] ?? 0;
        $totalPages = ceil($totalCount / $pageSize);
    
        if (isset($products['responsedata']['casinoGamelist']) && is_array($products['responsedata']['casinoGamelist'])) {
            foreach ($products['responsedata']['casinoGamelist'] as $product) {
    

                $get_type = $this->dbHandler->createUpdateProvider($wpdb->prefix.'casino_game_type', $product['type']);
                $get_provider = $this->dbHandler->createUpdateProvider($wpdb->prefix.'casino_game_provider', $product['provider']);
                $get_technology = $this->dbHandler->createUpdateProvider($wpdb->prefix.'casino_game_technology', $product['technology']);
    
                $product['type'] = $get_type;
                $product['provider'] = $get_provider;
                $product['technology'] = $get_technology;


                $game_id = $this->dbHandler->createUpdateGame($wpdb->prefix.'casino_games', $product);
    
                if ($product['has_lobby']) {
                    $lobby = $this->casinoApi->gameLobby([], $product['uuid']);
                    $this->dbHandler->createUpdateGameLobby($wpdb->prefix.'casino_game_lobby', $product['uuid'], $game_id, $lobby);
                }
            }
        }
    
        if (empty($products)) {
            error_log('No products fetched or error occurred on page ' . $page);
            return;
        }
    
        $tableData = array(
            'page' => $page + 1,
            'totalPages' => $totalPages
        );
    
        if ($pageCount) {
            $wpdb->update(
                "{$wpdb->prefix}casino_game_cronjob_pagination",
                $tableData,
                ['id' => $result[0]->id]
            );
        } else {
            $wpdb->insert(
                "{$wpdb->prefix}casino_game_cronjob_pagination",
                $tableData
            );
        }
    }
    
}
// Initialize the CronJob handler
$casino_cronjob_handler = API_CRONJOB_HANDLER::get_instance();
?>

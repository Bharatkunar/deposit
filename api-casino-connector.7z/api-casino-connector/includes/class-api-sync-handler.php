<?php
if (!defined('ABSPATH')) exit;

class Api_Sync_Handler {

    public static function init_hooks() {
        add_action('wp_login', [self::class, 'handle_login_sync'], 10, 2);
        add_action('api_sync_run_for_user', [self::class, 'run_all_syncs_for_user']);
    }

    public static function handle_login_sync($user_login, $user) {
        if (!is_a($user, 'WP_User')) {
            $user = get_user_by('login', $user_login);
        }

        if (!$user || !isset($user->ID)) return;

        // if (!as_has_scheduled_action('api_sync_run_for_user', [$user->ID])) {
        //     as_schedule_single_action(time() + 10, 'api_sync_run_for_user', [$user->ID]);
        // }
    }

    public static function run_all_syncs_for_user($user_id) {
        if (!$user_id) return;

        require_once plugin_dir_path(__FILE__) . 'integrations/offers-sync.php';
        Offers_Sync::sync($user_id);

        // Future integrations:
        // require_once plugin_dir_path(__FILE__) . 'integrations/rewards-sync.php';
        // Rewards_Sync::sync($user_id);
    }


    
}

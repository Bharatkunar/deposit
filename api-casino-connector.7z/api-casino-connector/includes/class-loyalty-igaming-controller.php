<?php

class LoyaltyIgamingHandler
{
    private $callbacks = [];


}

?>
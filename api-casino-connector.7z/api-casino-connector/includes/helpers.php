<?php


function loyalty_plugin_log($message, $context = '') {
    $log_dir = plugin_dir_path(__FILE__) . '../../'; // root of plugin
    $log_file = $log_dir . 'loyalty-plugin.log';

    // Format the log entry
    $log_entry = '[' . date('Y-m-d H:i:s') . ']';
    if ($context) {
        $log_entry .= " [$context]";
    }
    $log_entry .= " $message" . PHP_EOL;

    // Write to file
    file_put_contents($log_file, $log_entry, FILE_APPEND);
}


?>
<?php
function casino_add_admin_menu() {
    // Add main menu
    add_menu_page(
        'Casino Connect',  // Page title
        'Casino Connect',  // Menu title
        'manage_options',         // Capability required to access
        'casino_connect',  // Menu slug
        'casino_admin_page', // Function to display the page
        'dashicons-admin-generic' // Icon
    );

    // Add submenu for configuration
    add_submenu_page(
        'casino_connect',           // Parent menu slug
        'Configuration',                  // Submenu title
        'Configuration',                  // Submenu title
        'manage_options',                 // Capability
        'casino_configuration',      // Submenu slug
        'casino_settings_page'       // Function to display the settings page
    );

    
    add_submenu_page(
        'casino_connect',           // Parent menu slug
        'Games',                  // Submenu title
        'Games',                  // Submenu title
        'manage_options',                 // Capability
        'games',      // Submenu slug
        'casino_list_games'       // Function to display the settings page
    );


    add_submenu_page(
        'casino_connect',           // Parent menu slug
        'Game Activity',                  // Submenu title
        'Game Activity',                  // Submenu title
        'manage_options',                 // Capability
        'game-activity',      // Submenu slug
        'casino_list_games_activity'       // Function to display the settings page
    );


    add_submenu_page(
        'casino_connect',           // Parent menu slug
        'Shortcodes',                  // Submenu title
        'Shortcodes',                  // Submenu title
        'manage_options',                 // Capability
        'game-setup',      // Submenu slug
        'casino_game_create_shortcodes'       // Function to display the settings page
    );

    add_submenu_page(
        'casino_connect',           // Parent menu slug
        'Customers',                  // Submenu title
        'Customers',                  // Submenu title
        'manage_options',                 // Capability
        'customers',      // Submenu slug
        'casino_list_customers'       // Function to display the settings page
    );

    add_submenu_page(
        'casino_connect',           // Parent menu slug
        'Merchant limits',                  // Submenu title
        'Merchant limits',                  // Submenu title
        'manage_options',                 // Capability
        'limits',      // Submenu slug
        'casino_limits'       // Function to display the settings page
    );

    add_submenu_page(
        'casino_connect',           // Parent menu slug
        'free spins',                  // Submenu title
        'free spins',                  // Submenu title
        'manage_options',                 // Capability
        'free-spins',      // Submenu slug
        'casino_free_spin_limits'       // Function to display the settings page
    );


    add_submenu_page(
        'casino_connect',           // Parent menu slug
        'orders & transactions',                  // Submenu title
        'orders & transactions',                  // Submenu title
        'manage_options',                 // Capability
        'order-transactions',      // Submenu slug
        'woo_order_transactions'       // Function to display the settings page
    );


    // Add new main menu: WooRoyaltyConnection
    add_menu_page(
        'WoocommerceLoyaltyConnector',
        'WoocommerceLoyaltyConnector',
        'manage_options',
        'woo_royalty_connection',
        'woo_royalty_dashboard_page', // You can define this function as needed
        'dashicons-networking'
    );

    // Submenus for WooRoyaltyConnection
    add_submenu_page(
        'woo_royalty_connection',
        'Order & Transaction',
        'Order & Transaction',
        'manage_options',
        'woo_royalty_order_transaction',
        'woo_royalty_order_transaction_page' // Define this function separately
    );

    add_submenu_page(
        'woo_royalty_connection',
        'Logs/Failed',
        'Logs/Failed',
        'manage_options',
        'woo_royalty_logs_failed',
        'woo_royalty_logs_failed_page' // Define this function separately
    );




}
add_action('admin_menu', 'casino_add_admin_menu');

// Function to render the main page
function casino_admin_page() {
    $db = new DB_Handler();
    $data = $db->dashboard();
    $menu_name = "Casino Admin  Dashboard";
    include plugin_dir_path(__FILE__) . 'views/configuration/dashboard.php';
}

function casino_settings_page() {
    $menu_name = "API Configuration Setup";
    include plugin_dir_path(__FILE__) . 'views/configuration/index.php';
}

function casino_list_games() {
    $menu_name = "List of All Games";
    // check if lobby page is active
    $lobby = isset($_GET['lobby'])?$_GET['lobby']:'';

    $api = new DB_Handler();
    if(!empty($lobby))
    {
        $menu_name = "Lobby List";
        $lobby = $api->getLobbyByGameId($lobby);
        include plugin_dir_path(__FILE__) . 'views/games/lobby.php';
    }
    else
    {
        $api = new DB_Handler();
        $games = $api->getCategoryWiseGames();
        $pagination = $games['pagination'];
    
    
        $type = $games['type'];
        $provider = $games['provider'];
        $technology = $games['technology'];
        $games = $games['items'];
        $pagination = $pagination;

        $current_page = $pagination['current_page'];
        $per_page = $pagination['per_page'];
        $total_records = $pagination['total_records'];
        $total_pages = $pagination['total_pages'];

        $current_total = count($games);


 
        include plugin_dir_path(__FILE__) . 'views/games/index.php';
    }
    

}



// 
function casino_display_game_setup() {
    // check if lobby page is active
    $lobby = isset($_GET['lobby'])?$_GET['lobby']:'';

    $api = new DB_Handler();
    if(!empty($lobby))
    {
        $menu_name = "Lobby List";
        $lobby = $api->getLobbyByGameId($lobby);
        include plugin_dir_path(__FILE__) . 'views/games/display_game.php';
    }
    else
    {
        $menu_name = "Lobby List";

        $games = $api->getCategoryWiseGames();
        $pagination = $games['pagination'];
    
    
        $type = $games['type'];
        $provider = $games['provider'];
        $technology = $games['technology'];
        $games = $games['items'];
        $pagination = $pagination;
        
    
    
        include plugin_dir_path(__FILE__) . 'views/games/index.php';
    }
    

}


function casino_stats_page() {
    include plugin_dir_path(__FILE__) . 'views/games/stats.php';
}



function casino_game_create_shortcodes()
{
    $api = new DB_Handler();
    $gameController = new Game_Controller();
    $gameShortCodeHandler = new Game_Short_Code_Hanlder();
    $loyaltyShortCodeHandler = new RoboRewardLoyaltyShortCodeHandler();
    $codes = $api->getAllShortCodes();
    $loyaltyCodes = $loyaltyShortCodeHandler->get_registered_shortcodes();
    


    $shortcodes = $gameShortCodeHandler->get_registered_shortcodes();
    if(isset($_GET['view']))
    {
        
        $pagination = $games['pagination'];
        $games = $api->getCategoryWiseGames(1);

        $activeResult = $gameController->getTotalGamesByStatus(1);
        $inactiveResult = $gameController->getTotalGamesByStatus(0);


        // Extract the count value safely
        $active = $activeResult[0]->totalGames;
        $inactive = $inactiveResult[0]->totalGames;
    
        $type = $games['type'];
        $provider = $games['provider'];
        $technology = $games['technology'];
        $games = $games['items'];
        $pagination = $pagination;

        $current_page = $pagination['current_page'];
        $per_page = $pagination['per_page'];
        $total_records = $pagination['total_records'];
        $total_pages = $pagination['total_pages'];

        $current_total = count($games);
        if($_GET['view'] == 'short_code')
        {
            $menu_name = "Create New Shortcode";

            include plugin_dir_path(__FILE__) . 'views/games/create_game_shortcode.php';
        }
        else if($_GET['view'] == 'delete')
        {
            $id = $_GET['delete_id'];
            $api->deleteSingleShortCode($id);
            include plugin_dir_path(__FILE__) . 'views/games/display_game.php';
        }
        else
        {
            $edit_id = $_GET['edit_id'];
            $menu_name = "Edit Shortcode";
            $singleShortCode = $api->getSingleShortCode($edit_id);

    
        
            include plugin_dir_path(__FILE__) . 'views/games/edit_game_shortcode.php';
        }
        

    }
    
    else
    {
        $menu_name = "Shortcodes Management";
        include plugin_dir_path(__FILE__) . 'views/games/display_game_2.php';
    }
}


function casino_list_games_activity() {
    $api = new DB_Handler();
    $menu_name = "";
    $games = $api->getGameActivity();


    if(isset($_GET['view']))
    {
        if($_GET['view'] == 'sessions')
        {
            $menu_name = "Game Sessions";

            $sessions = $api->getGameSessions($_GET['game_id']);
            include plugin_dir_path(__FILE__) . 'views/games/game_sessions.php';
        }
        else
        {
            $menu_name = "Game Activities";
            $transactions = $api->getGameSessionsLogs($_GET['log_id'],$_GET['session_id'],$_GET['player_id']);
            include plugin_dir_path(__FILE__) . 'views/games/game_transactions.php';
        }

    
    }   
    else
    {
        $menu_name = "List Of All Games Played";

        $completed = $games['completed'];
        $started = $games['started'];
        $enabled = $games['enabled'];
        $pagination = $games['pagination'];
        $current_page = $pagination['current_page'];
        $per_page = $pagination['per_page'];
        $total_records = $pagination['total_records'];
        $total_pages = $pagination['total_pages'];
    
        include plugin_dir_path(__FILE__) . 'views/games/activity.php';
    }
    

}

function casino_list_customers() {
    $db_handler = new DB_Handler();

    $view = isset($_REQUEST['view'])?$_REQUEST['view']:'';
    $game_history = isset($_REQUEST['game_history'])?$_REQUEST['game_history']:'';
    $customer_id = isset($_REQUEST['customer_id'])?$_REQUEST['customer_id']:'';


    if(!empty($view))
    {
        
        if($view == 'transaction')
        {
            $menu_name = "Transaction";

            $customers = $db_handler->getCustomerTransactionHistory($customer_id);
            include plugin_dir_path(__FILE__) . 'views/customers/transaction.php';
        }
        elseif($view == 'balance')
        {
            $menu_name = "Add Balance";
            include plugin_dir_path(__FILE__) . 'views/customers/add_balance.php';
        }
        else
        {
            $menu_name = "Game History";
            $customers = $db_handler->getCustomerGameHistory($customer_id);
            include plugin_dir_path(__FILE__) . 'views/customers/game_history.php';
        }
    }
    else
    {
        $menu_name = "List Of Customers";
        $game_users = $db_handler->get_customers('game_customer');
        include plugin_dir_path(__FILE__) . 'views/customers/index.php';
    }


}

function casino_limits() {
    $db_handler = new casinoApi();
    $limits = $db_handler->getLimits('limits');
    $menu_name = "Merchant Limits";
    include plugin_dir_path(__FILE__) . 'views/games/limits.php';
}

function casino_free_spin_limits() {
    $db_handler = new casinoApi();
    $freeSpins = $db_handler->getLimitFreeSpin('limits/freespin');
    include plugin_dir_path(__FILE__) . 'views/games/free_spin.php';
}


function casino_jackpots() {
    $db_handler = new casinoApi();
    $jackpot = $db_handler->jackpots('jackpots');
    include plugin_dir_path(__FILE__) . 'views/games/jackpots.php';
}

function casino_add_balance_to_customers() {
    $db_handler = new DB_Handler();
    $game_users = $db_handler->get_customers('game_customer');

    include plugin_dir_path(__FILE__) . 'views/customers/add_a.php';
}

// Woocommerce
function woo_royalty_dashboard_page()
{
    echo "this page is going to display order & transaction details for the customers";
}

?>
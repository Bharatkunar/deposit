<?php

class Bharat_CallBack_Handler
{
   
    private $bharatController;
    
    public function __construct()
    {
        $this->bharatController = new LoyaltyApiHanlder();
    }

    public function get_call_back_actions()
    {

        $array = [
            'free_play_visit',
            'my_offers',
            'transaction_history',
            'egift_offer',
            'leader_board',
            'referal_stats',
            'home_page',
            'survey',
            'location'
        ];

        wp_send_json([
            'status' => 200,
            'message' => 'success',
            'data' => $array
        ]);
    }

    public function syncAllApis()
    {
       
       $bharatController = new LoyaltyApiHanlder(); // Create an instance here

       $freePlayData =  $bharatController->freePlayVisits('automation'); // Use instance here

       $getTransactionHistory = $bharatController->getTransactionHistory('automation'); // Use instance here
    }


    
    // Function to handle the callback API
    public static function handle_callback($request)
    {
        global $wpdb;



        $bharatController = new LoyaltyApiHanlder(); // Create an instance here

        $action = $request->get_param('action');
        $loyalty_contact = $request->get_param('loyalty_contact');
       
        $table = $wpdb->prefix . 'loyalty_webhook_calls';
        $tableArray = [
            'data'      => json_encode($request->get_params(),true),
            'action'    => $action,
            'contact_id' => $loyalty_contact
        ];
        $insert = $wpdb->insert($table, $tableArray);
        if (false === $insert) {
            // Insert failed – show error message
            echo '<pre>';
            echo 'Insert failed: ' . $wpdb->last_error . "\n";
            echo 'Query: ' . $wpdb->last_query . "\n";
            echo 'Data: ';
            print_r($tableArray);
            echo '</pre>';
        } else {
            echo 'Insert successful. Insert ID: ' . $wpdb->id;
        }
       
        switch ($action) {
            case 'free_play_visit':
                $loyaltyController->freePlayVisits(); // Use instance here
            case 'my_offers':
                $loyaltyController->myOffers(); // Use instance here
            case 'transaction_history':
                $loyaltyController->getTransactionHistory(); // Use instance here
           
            case 'popup_transaction':
                $contact_id = $request->get_param('ContactID');
      
                // Get the contact_id of the currently logged-in user
                $row = $wpdb->get_row("
                    SELECT *
                    FROM wp_usermeta
                    WHERE meta_value = '{$contact_id}'
                    LIMIT 1
                ", ARRAY_A);

                // Check if query failed
                if ( $row === null ) {
                    echo "❌ Query failed or returned no results.<br>";
                    echo "MySQL Error: " . $wpdb->last_error . "<br>";
                    echo "Last SQL: " . $wpdb->last_query . "<br>";
                }
                else
                {
                    $user_id = $row['user_id'];
                }


           
                update_user_meta($user_id, 'show_popup_7330', true);
                update_user_meta($user_id, 'loyalty_offer_id', $_GET['OfferID']);

                // Retrieve Offer Details Now

                $offerData = $bharatController->viewOfferById($_GET['OfferID']);
                       
           
                $offerData = $offerData['responsedata'];
          
         




                update_user_meta($user_id, 'loyalty_offer_description', $offerData['offerDescription'] );



                $options = [
                    'cluster' => 'ap2',
                    'useTLS' => true,
                ];
                
                $pusher = new Pusher\Pusher(
                    '4994bb580820ff5f007d',  // ✅ Your app key
                    '86252a33d136259f80fc',  // ✅ Your secret
                    '2016674',               // ✅ Your app ID
                    $options                 // ✅ Cluster and TLS settings
                );
                
                // ✅ Sends a custom event to user-<user_id> channel
                $pusher->trigger('user-' . $user_id, 'popup-7330', [
                    'offer_id' => $_GET['OfferID'] ?? null,
                    'loyalty_offer_description' => $offerData['offerDescription'],
                    'contactid' => $contact_id
                ]);

                break;

            case 'get_actions':
                $array = [
                    'free_play_visit',
                    'my_offers',
                    'transaction_history',
                    'egift_offer',
                    'leader_board',
                    'referal_stats',
                    'home_page',
                    'survey',
                    'location'
                ];

                wp_send_json([
                    'status' => 200,
                    'message' => 'success',
                    'data' => $array
                ]);
            default:
                new WP_REST_Response('Unknown action.', 400);
        }

        return wp_send_json([
            'status' => 200,
            'message' => 'success',
            'action' => $action
        ]);
    }
}

$bharatCallBackHandler = new Bharat_CallBack_Handler();
 
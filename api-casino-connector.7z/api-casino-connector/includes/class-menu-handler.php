<?php

class FrontMenuHandler {

    // Constructor to hook the shortcodes
    public function __construct() {
        // Register shortcodes
        add_shortcode('casino_play_game_page', array($this, 'casino_play_game_shortcode'));
        add_shortcode('casino_login_form', array($this, 'casino_login_form_shortcode'));
        add_shortcode('casino_register_form', array($this, 'casino_register_form_shortcode'));

        add_shortcode('casino_forgetpassword_form', array($this, 'casino_forgetpassword_form_shortcode'));


        add_shortcode('casino_dashboard_page', array($this, 'casino_dashboard_page_shortcode'));
        add_shortcode('casino_get_game_lobby_page', array($this, 'casino_get_game_lobby_shortcode'));
        add_shortcode('casino_otp_form', array($this, 'casino_otp_form_shortcode'));



        add_action('init', [$this, 'add_custom_rewrite_rules']);

        add_filter('query_vars', [$this, 'register_query_vars']);
        add_action('template_redirect',  [$this, 'redirect_non_logged_in_users_from_dashboard']);



    }
    public function my_plugin_add_query_vars($vars) {
        $vars[] = 'page'; // Add 'page' to recognized query vars
        return $vars;
    }
    public function add_custom_rewrite_rules() {
        // Game lobby rule remains the same
        add_rewrite_rule(
            '^gamelobby/([0-9]+)/?$',
            'index.php?pagename=game-lobby&game_id=$matches[1]',
            'top'
        );
        
    
        // Flush rewrite rules once after adding rules
        if ( ! get_option( 'my_rewrite_rules_flushed' ) ) {
            flush_rewrite_rules(); // Run only once when plugin/theme is activated
            update_option( 'my_rewrite_rules_flushed', true );
        }
    }
    
    
    public function register_query_vars($vars) {
        $vars[] = 'game_id'; // Register the 'game_id' query var
        $vars[] = 'page'; // Register the 'game_id' query var

        return $vars;
    }

    // Plugin activation function
    public function casino_activate_plugin() {
        // Define the pages and their shortcodes
        $pages = array(
            'Dashboard'   => '[casino_dashboard_page]',
        );
   
        // Loop through the pages and create them if they don't exist
        foreach ($pages as $title => $shortcode) {
            if (!get_page_by_title($title)) {
                wp_insert_post(array(
                    'post_title'   => $title,
                    'post_content' => $shortcode,
                    'post_status'  => 'publish',
                    'post_type'    => 'page',
                    'post_author'  => 1
                ));
                casino_plugin_log("$title page created successfully.");
            }
        }
    
        // Get the menu location for "main_navigation"
        $assigned_menu = get_nav_menu_locations();
        $menu_location = 'main_navigation'; // You can replace this with your desired location
    
        if (isset($assigned_menu[$menu_location])) {
            $menu_id = $assigned_menu[$menu_location];
            $menu = wp_get_nav_menu_object($menu_id);
            
            // Get the menu items in the current "Home Main Menu"
            $menu_items = wp_get_nav_menu_items($menu_id);
            
            // Loop through the pages and add them to the menu
            foreach ($pages as $title => $shortcode) {
                if ($title === 'Otp' || $title === 'Dashboard') {
                    continue; // Skip adding OTP to menu
                }
                // Check if the menu already has an item for this page
                $existing_menu_item = false;
                foreach ($menu_items as $item) {
                    if ($item->title === $title) {
                        $existing_menu_item = true;
                        break;
                    }
                }
    
                if (!$existing_menu_item) {
                    // Get the page URL
                    $page = get_page_by_title($title);
                    if ($page) {
                        // Add menu item
                        wp_update_nav_menu_item($menu_id, 0, array(
                            'menu-item-title'   => $title,
                            'menu-item-url'     => get_permalink($page->ID),
                            'menu-item-status'  => 'publish'
                        ));
                        casino_plugin_log("$title added to the $menu->name menu.");
                    }
                }
            }
        } else {
            casino_plugin_log('No menu assigned to main_navigation location.');
        }
    }
    
        // Redirect User

        function redirect_non_logged_in_users_from_dashboard() {
            if (is_page('dashboard') && !is_user_logged_in()) {
                wp_redirect(home_url('/login')); // Redirect to login page
                exit;
            }
        }

    // Shortcode for the game page
    public function casino_play_game_shortcode() {
        ob_start();

        $page = get_query_var('page'); // Retrieve the 'game_id' from the URL
        $page = $page?$page:1;
        $api = new casinoApi();

        try {
            $games = $api->get_games('games?expand=tags,parameters,images,related_games',$page);
         
        } catch (Exception $e) {
            $games = [];
            error_log('Error fetching games: ' . $e->getMessage());
        }
        // Include the game page view
        include plugin_dir_path(__FILE__) . '../public/views/game/index.php';
        return ob_get_clean();
    }

    public function casino_get_game_lobby_shortcode() {
        $game_id = get_query_var('game_id'); // Retrieve the 'game_id' from the URL
     
        if (!$game_id) {
            return 'Game ID not found.';
        }

        $api = new casinoApi();
   
        try {
            $games = $api->gameLobby([
                'game_uuid' => 'efec450ddc51a625d94fe75d0ddc037ccac9259a'
            ],$game_id);
            $games = $games['lobby'];
        } catch (Exception $e) {
            $games = [];
            error_log('Error fetching games: ' . $e->getMessage());
        }
        // Include the game page view
        include plugin_dir_path(__FILE__) . '../public/views/game/lobby.php';
        return ob_get_clean();
    }

    // Shortcode for the login form
    public function casino_login_form_shortcode() {
        ob_start();
        include plugin_dir_path(__FILE__) . '../public/views/authentication/gusta_login.php';
        return ob_get_clean();
    }
    public function casino_register_form_shortcode() {
        ob_start();
        include plugin_dir_path(__FILE__) . '../public/views/authentication/gusta_register.php';
        return ob_get_clean();
    }
    public function casino_otp_form_shortcode() {
        ob_start();
        include plugin_dir_path(__FILE__) . '../public/views/authentication/otp.php';
        return ob_get_clean();
    }
    
    

    public function casino_forgetpassword_form_shortcode() {
        ob_start();
        include plugin_dir_path(__FILE__) . '../public/views/authentication/forget_password.php';
        return ob_get_clean();
    }
}

// Instantiate the class to register the shortcodes
new FrontMenuHandler();

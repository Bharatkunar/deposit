<div class="wrap">
    <h1 class="wp-heading-inline">Game Lobby</h1>

    <div class="games-grid">
        <?php if (!empty($games)): ?>
            <?php 
                // echo "<pre>";
                // print_r($games);
                // echo "</pre>";
            ?>
            <?php foreach ($games as $game): ?>
                <div class="game-card">
                    <div class="game-header">
                        <strong><?php echo esc_html($game['name']); ?></strong>
                    </div>
                    <div class="game-body">
                        <div class="game-details">
                            <p><strong>name:</strong> <?php echo esc_html($game['name']); ?></p>
                            <p><strong>Is Open:</strong> <?php echo esc_html($game['isOpen']); ?></p>
                            <p><strong>Open Time:</strong> <?php echo esc_html($game['openTime']); ?></p>
                            <p><strong>Close Time:</strong> <?php echo esc_html($game['closeTime']); ?></p>
                            <p><strong>Technology:</strong> <?php echo esc_html($game['technology']); ?></p>
                        </div>
                    </div>
                </div>
        
            <?php endforeach; ?>
        <?php else: ?>
            <p>No games found for this lobby.</p>
        <?php endif; ?>
    </div>
</div>



<style>
    .wrap {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
    }

    .wp-heading-inline {
        font-size: 2rem;
        font-weight: bold;
        color: #0073aa;
    }

    .description {
        font-size: 1.2rem;
        color: #555d66;
        margin-bottom: 20px;
    }

    .games-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
    }

    .game-card {
        background: #ffffff;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 15px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s, box-shadow 0.2s;
    }

    .game-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 6px 10px rgba(0, 0, 0, 0.15);
    }

    .game-header {
        font-size: 1.4rem;
        font-weight: bold;
        color: #0073aa;
        margin-bottom: 10px;
    }

    .game-body p {
        font-size: 0.9rem;
        margin: 5px 0;
        color: #555d66;
    }

    .game-footer {
        margin-top: 15px;
        text-align: center;
    }

    .play-game-button {
        display: inline-block;
        padding: 10px 20px;
        font-size: 0.9rem;
        color: #ffffff;
        background-color: #0073aa;
        border-radius: 5px;
        text-decoration: none;
        transition: background-color 0.2s, transform 0.2s;
    }

    .play-game-button:hover {
        background-color: #005f8d;
        transform: scale(1.05);
    }

    .no-games-message {
        font-size: 1.1rem;
        color: #cc0000;
        text-align: center;
        margin-top: 20px;
    }

    #spinner {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: rgba(0, 0, 0, 0.8);
        color: white;
        text-align: center;
        padding: 20px;
        border-radius: 8px;
        z-index: 1000;
    }
    .spinner {
        margin: 10px auto;
        width: 40px;
        height: 40px;
        border: 5px solid #ccc;
        border-top-color: #3498db;
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }
    @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
    .pagination-controls {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 20px;
    gap: 10px;
}

.pagination-button {
    display: inline-block;
    padding: 10px 20px;
    font-size: 1rem;
    color: #ffffff;
    background-color: #0073aa;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.2s, transform 0.2s;
}

.pagination-button:hover {
    background-color: #005f8d;
    transform: scale(1.05);
}

.current-page {
    font-size: 1rem;
    font-weight: bold;
    color: #333;
}

</style>

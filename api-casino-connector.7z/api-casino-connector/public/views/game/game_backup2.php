<style>
/* General Page Styling */
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f9;
    margin: 0;
    padding: 0;
    color: #333;
}

.wrap {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

h1.wp-heading-inline {
    font-size: 24px;
    color: #1d3557;
    text-align: center;
    margin-bottom: 10px;
}

.description {
    text-align: center;
    font-size: 16px;
    color: #555;
    margin-bottom: 20px;
}

/* Slider Container */
.slider-container {
    display: flex;
    overflow-x: auto;
    gap: 15px;
    margin-bottom: 30px;
    scrollbar-width: thin; /* Firefox scrollbar */
    scrollbar-color: #1d3557 #e4e4e4; /* Thumb color, Track color */
}

.slider-container::-webkit-scrollbar {
    height: 8px; /* Horizontal scrollbar height */
}

.slider-container::-webkit-scrollbar-thumb {
    background-color: #1d3557; /* Thumb color */
    border-radius: 4px;
}

.slider-container::-webkit-scrollbar-track {
    background-color: #e4e4e4; /* Track color */
    border-radius: 4px;
}

.game-thumbnail {
    width: 200px;
    height: 120px;
    object-fit: cover;
    border-radius: 8px;
    cursor: pointer;
    transition: transform 0.3s ease;
}

.game-thumbnail:hover {
    transform: scale(1.05);
}

/* Spinner Styling */
#spinner {
    text-align: center;
    margin-top: 10px;
}

.spinner {
    border: 4px solid #f3f3f3;
    border-radius: 50%;
    border-top: 4px solid #3498db;
    width: 30px;
    height: 30px;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% {
        transform: rotate(0deg);
    }
    100% {
        transform: rotate(360deg);
    }
}

/* Pagination Controls */
.pagination-controls {
    text-align: center;
    margin: 20px 0;
}

.pagination-button {
    text-decoration: none;
    color: #1d3557;
    padding: 10px 15px;
    border: 1px solid #1d3557;
    border-radius: 4px;
    margin: 0 5px;
    transition: background-color 0.3s ease, color 0.3s ease;
}

.pagination-button:hover {
    background-color: #1d3557;
    color: #fff;
}

.current-page {
    font-size: 14px;
    color: #555;
}

.no-games-message {
    text-align: center;
    font-size: 16px;
    color: #888;
}
</style>


<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</head>
<div class="wrap">
    <h1 class="wp-heading-inline">Explore Our Game Collection</h1>
    <p class="description">Discover and play from our curated selection of games, tailored for every gaming enthusiast!</p>

    <div class="slider-container">
        <?php if (!empty($games)) : ?>
            <?php foreach ($games as $game) : ?>
                <img src="<?php echo esc_url($game->image); ?>" alt="<?php echo esc_html($game->name); ?>" class="game-thumbnail" data-id="<?php echo esc_attr($game->uuid); ?>" data-name="<?php echo esc_html($game->name); ?>" data-localid="<?php echo esc_attr($game->id); ?>" />
            <?php endforeach; ?>
        <?php else : ?>
            <p class="no-games-message">No games found. Please check back later for new additions!</p>
        <?php endif; ?>
    </div>

    <div id="spinner" style="display: none;">
        <div class="spinner"></div>
        <p>Launching game, please wait...</p>
    </div>
</div>

<script>
    $(document).ready(function() {
    // Ensure the click event is not bound multiple times
    $('.game-thumbnail').off('click').on('click', function() {
        const api_game_id = $(this).data('id');
        const gameId = $(this).data('localid');
        const name = $(this).data('name');
        playGame(api_game_id, gameId, name);
    });

    function playGame(api_game_id, gameId, name) {
        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            method: 'POST',
            dataType: 'json',
            data: {
                action: 'play_game',
                game_uuid: api_game_id,
                game_id: gameId,
                game_name: name
            },
            beforeSend: function() {
                $('#spinner').show();
            },
            success: function(response) {
                $('#spinner').hide();
                if (response.success) {
                    if (response?.data?.game_url) {
                        window.location.href = response?.data?.game_url;
                    }
                } else {
                    alert('Error: ' + response?.data?.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', error);
                alert('Failed to start the game.');
            }
        });
    }
});
</script>

<style>
/* General Page Styling */
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f9;
    margin: 0;
    padding: 0;
    color: #333;
}

.wrap {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

h1.wp-heading-inline {
    font-size: 24px;
    color: #1d3557;
    text-align: center;
    margin-bottom: 10px;
}

.description {
    text-align: center;
    font-size: 16px;
    color: #555;
    margin-bottom: 20px;
}

/* Game Grid Styling */
.games-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
}

.game-card {
    background-color: #f8f9fa;
    border: 1px solid #e1e5eb;
    border-radius: 8px;
    overflow: hidden;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.game-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}

.game-header {
    text-align: center;
    padding: 10px;
    background-color: #1d3557;
    color: #fff;
}

.game-thumbnail {
    max-width: 100%;
    border-radius: 4px;
    margin-bottom: 10px;
}

.game-body {
    padding: 15px;
}

.game-body p {
    margin: 8px 0;
    font-size: 14px;
    color: #555;
}

.game-footer {
    padding: 10px;
    background-color: #f1f3f5;
    text-align: center;
}

.play-game-button {
    text-decoration: none;
    color: #fff;
    background-color: #e63946;
    padding: 10px 20px;
    border-radius: 4px;
    font-size: 14px;
    display: inline-block;
    transition: background-color 0.3s ease;
}

.play-game-button:hover {
    background-color: #d62828;
}

/* Spinner Styling */
#spinner {
    text-align: center;
    margin-top: 10px;
}

.spinner {
    border: 4px solid #f3f3f3;
    border-radius: 50%;
    border-top: 4px solid #3498db;
    width: 30px;
    height: 30px;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% {
        transform: rotate(0deg);
    }
    100% {
        transform: rotate(360deg);
    }
}

/* Pagination Controls */
.pagination-controls {
    text-align: center;
    margin: 20px 0;
}

.pagination-button {
    text-decoration: none;
    color: #1d3557;
    padding: 10px 15px;
    border: 1px solid #1d3557;
    border-radius: 4px;
    margin: 0 5px;
    transition: background-color 0.3s ease, color 0.3s ease;
}

.pagination-button:hover {
    background-color: #1d3557;
    color: #fff;
}

.current-page {
    font-size: 14px;
    color: #555;
}

.no-games-message {
    text-align: center;
    font-size: 16px;
    color: #888;
}
</style>

<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</head>
<div class="wrap">
    <h1 class="wp-heading-inline">Explore Our Game Collection</h1>
    <p class="description">Discover and play from our curated selection of games, tailored for every gaming enthusiast!</p>

    <div class="games-grid">
     
        <?php if (!empty($games)) : ?>
            <?php foreach ($games as $game) : ?>
            
                <div class="game-card">
                    <div class="game-header">
                        <img src="<?php echo esc_url($game->image); ?>" alt="<?php echo esc_html($game->name); ?>" class="game-thumbnail" />
                        <strong><?php echo esc_html($game->name); ?></strong>
                    </div>
                    <div class="game-body">
                        <p><strong>Type:</strong> <?php echo esc_html($game->type_name); ?></p>
                        <p><strong>Provider:</strong> <?php echo esc_html($game->provider_name); ?></p>
                        <p><strong>Technology:</strong> <?php echo esc_html($game->technology_name); ?></p>
                        <p><strong>Lobby:</strong> 
                            <?php   
                            if($game->has_lobby):

                            ?>
                            <a href="<?php echo esc_url(get_site_url(null, 'game-lobby?game_id=' . $game->totalLobby)); ?>">
                                Yes
                            </a>
                            <?php else: ?>
                            No

                            <?php endif; ?>
                            
                        </p>                        
                        <p><strong>Mobile:</strong> <?php echo $game->is_mobile ? 'Yes' : 'No'; ?></p>
                        <p><strong>Free Spins:</strong> <?php echo $game->has_freespins ? 'Yes' : 'No'; ?></p>
                        <p><strong>Label:</strong> <?php echo esc_html($game->label ?? '-'); ?></p>
                    </div>
                    <div class="game-footer">
                        <a class="play-game-button play-game-btn" data-name="<?php echo $game->name; ?>" data-id="<?php echo esc_attr($game->uuid); ?>">Play Game</a>
                    </div>
                    <div id="spinner" style="display: none;">
                        <div class="spinner"></div>
                        <p>Launching game, please wait...</p>
                    </div>
                </div>
            <?php endforeach; ?>
         


        <?php else : ?>
            <p class="no-games-message">No games found. Please check back later for new additions!</p>
        <?php endif; ?>
    </div>
    <!-- <div class="pagination-controls">
                <?php if (!empty($games['_links'])) : ?>
                    <?php if (!empty($games['_links']['prev'])) : ?>
                        <a href="<?php echo $games['_meta']['currentPage'] - 1 ?>" class="pagination-button prev-button">Previous</a>
                    <?php endif; ?>

                    <span class="current-page">
                        Page <?php echo esc_html($games['_meta']['currentPage']); ?> of <?php echo esc_html($games['_meta']['pageCount']); ?>
                    </span>

                    <?php if (!empty($games['_links']['next'])) : ?>
                        <a href="?page=<?php echo $games['_meta']['currentPage'] + 1 ?>" class="pagination-button next-button">Next</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>   -->
</div>

<script>

    $(document).ready((e) =>{
        
        let play = $('.play-game-btn');
        play.on('click',function() {
            const gameId = $(this).data('id');
            const name = $(this).data('name');
            playGame(gameId,name);
        })

        function playGame(gameId,name)
        {
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                method: 'POST',
                dataType: 'json',
                data: {
                    action: 'play_game',
                    game_uuid: gameId,
                    game_name:name
                },
                beforeSend: function() {
                    // Optional: Add a loading spinner or message
                    $('#spinner').show();

                },
                success: function(response) {
                    $('#spinner').hide();
                    if (response.success) {
                        if (response?.data?.game_url) {
                            window.location.href = response?.data?.game_url;
                        }
                    } else {
                        alert('Error: ' + response?.data?.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX error:', error);
                    alert('Failed to start the game.');
                }
            });
        }
    })
    
</script>
<?php
$contact_id = isset($_SESSION['contact_id']) ? $_SESSION['contact_id'] : null;


?>
<main class="dashboard-main">
    <section class="dashboard-stats">
        <div class="stat-box">
            <h3>Total Games Played</h3>
            <p><?php echo $dasboard['totalGamesPlayed']; ?></p>
        </div>
        <div class="stat-box">
            <h3>Total Won</h3>
            <p><?php echo $dasboard['totalWin']; ?></p>
        </div>
        <div class="stat-box">
            <h3>Winning Ratio</h3>
            <p><?php echo $dasboard['ratio']; ?></p>
        </div>
        <div class="stat-box">
            <h3>Current Balance</h3>
            <p>$<?php echo $dasboard['customerBalance']; ?></p>
        </div>
    </section>

    <section class="content-section">
        <h2> Latest Transactions</h2>
        <table class="dashboard-games-table">
            <thead>
                <tr>
                    <th>user </th>
                    <th>game</th>
                    <th>Bet Amount</th>
                    <th>Bet Amount</th>
                    <th>Win Amount</th>
                    <th>Net Amount</th>
                    <th>Status</th>
                    <th>Balance</th>
                    <th>Played At</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($dasboard['latestTransactions'] as $transactions):
                ?>
                    <tr>
                        <td><?php echo $transactions['contactId']; ?></td>
                        <td><?php echo $transactions['gameUuid']; ?></td>
                        <td><?php echo $transactions['roundId']; ?></td>
                        <td><?php echo $transactions['betAmount']; ?></td>
                        <td><?php echo $transactions['winAmount']; ?></td>
                        <td><?php echo $transactions['netAmount']; ?></td>
                        <td><?php echo $transactions['status']; ?></td>
                        <td><?php echo $transactions['currentBalance']; ?></td>
                        <td><?php echo $transactions['playedAt']; ?></td>
                    </tr>

                <?php endforeach; ?>
            </tbody>
        </table>
    </section>
</main>
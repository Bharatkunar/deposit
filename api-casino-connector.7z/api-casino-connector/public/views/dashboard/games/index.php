

<main class="dashboard-main">
                <section class="content-section">
                    <h2>Game Overview</h2>
                    <table class="dashboard-games-table">
                        <thead>
                            <tr>
                                <th>Game Name</th>
                                <th>Player Name</th>
                                <th>Language</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($games as $game){
                        
                        ?>
                        <tr>
                            <td ><?php echo esc_html($game->game_name); ?></td>
                            <td><?php echo esc_html($game->language); ?></td>
                            <td >
                                <span>
                                    <?php echo esc_html($game->status); ?>
                                </span>
                            </td>
                        </tr>
                    <?php }?>
                        </tbody>
                    </table>
                </section>
</main>


    
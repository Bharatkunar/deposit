<main class="dashboard-main">
                <section class="content-section">
                    <h2>User Balance History</h2>
                    <table class="dashboard-games-table">
                        <thead>
                            <tr>
                                <th> Current Balance </th>
                                <th> Last Balance </th>
                                <th> BalanceIn </th>
                                <th> Type </th>
                                <th> Date </th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($games as $game){
                            ?>
                            <tr>
                                <td ><?php echo esc_html($game->current_balance); ?></td>
                                <td ><?php echo esc_html($game->last_balance); ?></td>
                                <td><?php echo esc_html($game->balance_in); ?></td>
                                <td><?php echo esc_html($game->type); ?></td>
                                <td><?php echo esc_html($game->created_at); ?></td>
                            </tr>
                        <?php }?>
                        </tbody>
                    </table>
                </section>
</main>

<aside class="dashboard-sidebar">
    <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Dashboard</a></li>
        <li><a href="#">All Games</a></li>
        <li><a href="#">Balance History</a></li>
        <li><a href="#">Play a Game</a></li>
    </ul>
</aside>

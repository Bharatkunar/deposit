<main class="dashboard-main">
    <section class="content-section">
        <h2>Game Overview</h2>
        <table class="dashboard-games-table">
            <thead>
                <tr>
                    <th>Game ID</th>
                    <th>Player ID</th>
                    <th>Language</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>12345</td>
                    <td>player1</td>
                    <td>English</td>
                    <td>Active</td>
                </tr>
            </tbody>
        </table>
    </section>
</main>

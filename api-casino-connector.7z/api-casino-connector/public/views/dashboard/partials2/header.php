<body class="dashboard-page">

    <!-- Dashboard Container -->
    <div class="custom-dashboard-container">
        <!-- Header Section -->
        <header class="dashboard-header">
            <h4>Welcome to Your Dashboard</h4>
            <div class="user-info">
            <a href="<?php echo wp_logout_url(home_url()) ?>">Logout</a>             </div>
        </header>
        
        <!-- Dashboard Content (Sidebar + Main Content) -->
        <div class="dashboard-content">
            <!-- Sidebar Section -->
            <aside class="dashboard-sidebar">
                <ul>
                    <li><a href="<?php echo esc_url( site_url( '/' ) ); ?>">Website</a></li>
                    <li><a href="<?php echo esc_url( site_url( '/dashboard' ) ); ?>">Dashboard</a></li>
                    <li><a href="<?php echo esc_url( site_url( '/dashboard/balance-history' ) ); ?>">Balance History</a></li>
                </ul>
            </aside>

            <!-- Main Content Section -->
             
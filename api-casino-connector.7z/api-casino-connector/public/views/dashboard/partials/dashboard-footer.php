<div class="dashboard-footer">
    <p>&copy; <?php echo date('Y'); ?> Your Company Name. All rights reserved.</p>
    <ul class="footer-nav">
        <li><a href="<?php echo esc_url( site_url( '/privacy-policy' ) ); ?>">Privacy Policy</a></li>
        <li><a href="<?php echo esc_url( site_url( '/terms-of-service' ) ); ?>">Terms of Service</a></li>
    </ul>
</div>
</div> <!-- Closing div for .custom-dashboard-container or .dashboard-main -->

<style>

</style>
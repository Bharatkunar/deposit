<?php
// dashboard-sidebar.php
?>
<div class="dashboard-sidebar">
    <ul>
        <li><a href="<?php echo esc_url( site_url( '/' ) ); ?>">Website</a></li>
        <li><a href="<?php echo esc_url( site_url( '/dashboard' ) ); ?>">Dashboard</a></li>
        <li><a href="<?php echo esc_url( site_url( '/dashboard/balance-history' ) ); ?>">Balance History</a></li>
    </ul>
</div>


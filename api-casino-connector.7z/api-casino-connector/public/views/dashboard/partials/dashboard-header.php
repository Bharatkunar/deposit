<div class="custom-dashboard-container">
<div class="dashboard-header">
        <h1>Welcome to Your Dashboard</h1>
        <div class="user-info">
            <a href="<?php echo wp_logout_url(home_url()) ?>">Logout</a> 
        </div>
</div>


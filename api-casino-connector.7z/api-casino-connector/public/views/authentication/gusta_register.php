
<style>

#signup-modal {
    --background-side-menu: #1e1e2f;
    --primary-color: #facc15;
    --text-color: #ffffff;
    font-family: Arial, sans-serif;
    color: var(--text-color);
    overflow: hidden;
    height: 100%;
    width: 100%;
    overflow: hidden;

    
  }

#signup-modal .fusion-modal-content {
    position: relative;
    display: flex;
    flex-direction: column;
    padding: 24px;
    width: 100%;
    min-width: 100%;
    border-radius: 8px;
    box-shadow: 4px 4px 20px rgba(0, 11, 45, .5);
    background: var(--background-side-menu);
    overflow: hidden;
    animation: WizPopupWrapper_slide_in__VWg2O .3s ease-in-out;
}

</style>


<!-- Signup Form -->
<!-- Signup Modal Wrapper -->
<div id="signup-modal">
  <div class="WizPopupBody_wrapper__5pKBD">
    <div class="WizPopupBody_wrapper__content__MeLJD">
      <div class="WizPopupBody_wrapper__content_inner__h7aDQ" id="signup-form-container">

        <!-- Signup Form -->
        <form class="WizForm_base__gGggs signup-form" autocomplete="off">
           <!-- Username -->
          <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required autocomplete="off">
          </div>

          <!-- Email -->
          <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc">
            <label for="email">Email</label>
            <input type="text" id="useremail" name="email" required autocomplete="off">
          </div>

          <!-- Phone Code + Phone Number -->
          <div >
            
            <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc">
              <label for="mobilePhone">Phone</label>
              <input type="number" id="mobilePhone" name="mobilePhone" inputmode="numeric" pattern="[0-9]*" required>
            </div>
          </div>

          <!-- Password -->
          <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_end__A97st">
            <label for="password">Password</label>
            <input type="text" id="userpassword" name="userpassword" required>
          </div>

          <!-- Password Hints -->
          <div class="WizPasswordHints_hints__list__ztQA3 WizPasswordHints_show__5mBSP WizPasswordHints_line__lmIMa">
            <p><i><svg width="10" height="11"><circle cx="5" cy="5.5" r="3" fill="currentColor" /></svg></i> Minimum 8, maximum 30 Latin characters</p>
            <p><i><svg width="10" height="11"><circle cx="5" cy="5.5" r="3" fill="currentColor" /></svg></i> At least one number</p>
            <p><i><svg width="10" height="11"><circle cx="5" cy="5.5" r="3" fill="currentColor" /></svg></i> No spaces</p>
            <p><i><svg width="10" height="11"><circle cx="5" cy="5.5" r="3" fill="currentColor" /></svg></i> One lowercase letter</p>
            <p><i><svg width="10" height="11"><circle cx="5" cy="5.5" r="3" fill="currentColor" /></svg></i> One capital letter</p>
          </div>

          <!-- Newsletter -->
          <div class="WizForm_row__QIO2O">
            <div class="WizToggleBox_base__YKIBS WizToggleBox_primary-outlined__ayNtP WizToggleBox_XS__YsWr_">
              <label for="isEmailNewsletter" style="cursor: pointer;">
                <input type="checkbox" id="isEmailNewsletter" name="isEmailNewsletter">
                <span></span>
                I want to receive promotional info and product updates.
              </label>
            </div>
          </div>

          <!-- Register Button -->
          <button class="WizButton_base__ojkNL WizButton_primary-contained__xOImR WizButton_L__UZfj4 WizButton_WizFullWidth__DvHSM" type="submit">
            <span class="WizButton_text__oCBg0">Register</span>
            <span class="WizRipple-wrapper"></span>
          </button>

          

          <!-- Already Have an Account -->
          <div class="Signup_alreadyHaveAccountContainer__tkc_T">
            Already have an account? <span class="Signup_alreadyHaveAccountContainer__button__9gbcD">Sign in</span>
          </div>

          <!-- Terms -->
          <div class="Signup_infoMessage__I2SAb">
            By clicking Register, you accept our
            <a href="#" rel="noreferrer" target="_blank">Terms & Conditions</a>
            and confirm you're over 18 years old.
          </div>
        </form>

      </div>
    </div>
  </div>
</div>

<!-- OTP Form Template (Hidden, for JavaScript use) -->
<template id="otp-form-template">
  <form class="WizForm_base__gGggs otp-verification" autocomplete="off">
    <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc">
      <label for="otp">Enter OTP</label>
      <input type="text" id="otp" name="otp" required>
      <input type="hidden" id="action" name="casino_verify_otp">
    </div>
    <input type="hidden" id="otpVerificationId" name="otpVerificationId" value="">
    <div class="WizForm_error__To6eX" style="display: none; color: white; font-size: 12px; margin-bottom: 10px;"></div>
    <button class="WizButton_base__ojkNL WizButton_primary-contained__xOImR WizButton_L__UZfj4 WizButton_WizFullWidth__DvHSM" type="submit">
      <span class="WizButton_text__oCBg0">Verify OTP</span>
      <span class="WizRipple-wrapper"></span>
    </button>
    <button style="display:none" class="fusion-button button-default button-medium button default medium" type="button" data-dismiss="modal">Close</button>
  </form>
</template>





<script>
  $(document).ready(function () {
    // Handle signup form submit
    $(document).on('submit', '.signup-form', function (e) {
      e.preventDefault();

      const $form = $(this);
      const $btn = $form.find('button[type="submit"]');
      let $errorBox = $form.find('.WizForm_error__To6eX');

      if ($errorBox.length === 0) {
        $errorBox = $('<div class="WizForm_error__To6eX" style="color:red; margin-top:10px;"></div>');
        $form.prepend($errorBox);
      }

      const formData = {
        action: 'casino_register_user',
        username: $form.find('#username').val(),
        email: $form.find('#useremail').val(),
        password: $form.find('#userpassword').val(),
        mobilePhone: $form.find('#mobilePhone').val()
      };

      $errorBox.hide().text('');
      $btn.prop('disabled', true).append('<span class="loading-spinner">⏳</span>');

      $.ajax({
        type: 'POST',
        url: '<?php echo admin_url('admin-ajax.php'); ?>',
        data: formData,
        success: function (response) {
          const otpVerificationId = response?.data?.data?.otpMeta?.otpVerificationId;

          if (response.success && otpVerificationId) {
            const $container = $('#signup-form-container');
            const $template = $('#otp-form-template');

            if ($container.length && $template.length) {
              const $clone = $($template.html());
              $clone.find('#otpVerificationId').val(otpVerificationId);
              $container.empty().append($clone);
            }
          } else {
            $errorBox.text(response?.data?.message || 'Registration failed.').show();
          }
        },
        error: function () {
          $errorBox.text('Something went wrong. Please try again.').show();
        },
        complete: function () {
          $btn.prop('disabled', false).find('.loading-spinner').remove();
        }
      });
    });

    // Handle OTP verification
    $(document).on('submit', '.otp-verification', function (e) {
      e.preventDefault();

      const $form = $(this);
      const $btn = $form.find('button[type="submit"]');
      const $otpInput = $form.find('#otp');
      const $otpVerificationIdInput = $form.find('#otpVerificationId');


      let $errorBox = $form.find('.WizForm_error__To6eX');

      if ($errorBox.length === 0) {
        $errorBox = $('<div class="WizForm_error__To6eX" style="color:red; margin-top:10px;"></div>');
        $form.prepend($errorBox);
      }

      $btn.prop('disabled', true).append('<span class="loading-spinner">⏳</span>');

      const data = {
        action: 'casino_verify_otp',
        otp: $otpInput.val(),
        otpVerificationId: $otpVerificationIdInput.val()
      };

      $.ajax({
        type: 'POST',
        url: '<?php echo admin_url("admin-ajax.php"); ?>',
        data: data,
        success: function (response) {
          if (response.success) {
            $errorBox.html(response.data.message || 'Login successfull').show(); // changed `.text()` to `.html()`
            window.location.href = response.data.redirect;
          } else {
            $errorBox.html(response.data.message || 'Login failed').show(); // changed `.text()` to `.html()`
          }
        },
        error: function () {
          alert('Something went wrong while verifying OTP.');
        },
        complete: function () {
          $btn.prop('disabled', false).find('.loading-spinner').remove();
        }
      });
    });
  });
</script>






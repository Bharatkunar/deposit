<style>
#gusta-modal {
  overflow: hidden;
  height: 100%;
  width: 100%;
}

#gusta-modal .fusion-modal-content {
  position: relative;
  display: flex;
  flex-direction: column;
  padding: 24px;
  width: 100%;
  min-width: 100%;
  border-radius: 8px;
  box-shadow: 4px 4px 20px rgba(0, 11, 45, .5);
  background: var(--background-side-menu);
  overflow: hidden;
  animation: WizPopupWrapper_slide_in__VWg2O .3s ease-in-out;
}


#forgetpassword-modal {
    --background-side-menu: #1e1e2f;
    --primary-color: #facc15;
    --text-color: #ffffff;
    font-family: Arial, sans-serif;
    color: var(--text-color);
    overflow: hidden;
    height: 100%;
    width: 100%;
    overflow: hidden;

    
  }

#forgetpassword-modal .fusion-modal-content {
    position: relative;
    display: flex;
    flex-direction: column;
    padding: 24px;
    width: 100%;
    min-width: 100%;
    border-radius: 8px;
    box-shadow: 4px 4px 20px rgba(0, 11, 45, .5);
    background: var(--background-side-menu);
    overflow: hidden;
    animation: WizPopupWrapper_slide_in__VWg2O .3s ease-in-out;
}
</style>
<div id="forgetpassword-modal">
    <div class="WizPopupWrapper_wrapper__uyVeb">
    <div class="WizPopupWrapper_wrapper__container__D4qDj">
        
        <!-- Close Button -->
        <button 
        type="button" 
        class="WizIconButton_base__JfGpY WizPopupWrapper_close__hKtRn"
        >
        <div class="WizIconButton_children__Xqp6z"></div>
        </button>

        <!-- Modal Content -->

        <form 
        class="WizForm_base__gGggs forgetpassword"
        autocomplete="off"
        >
        <h2 class="forgotPassword_form_infoMessage__jhCOP">
            Enter your email address
        </h2>

        <!-- Email Input -->
        <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc">
            <label for="email">Email</label>
            <input 
            type="text" 
            name="email" 
            id="email" 
            value=""
            />
        </div>

        <!-- Submit Button -->
        <div 
            class="WizButtonContainer_container__r4v3N WizButtonContainer_end__GdfvQ WizButtonContainer_row__FVI8Q WizButtonContainer_fullWidth__d5Jzj" 
            data-button-container="wrapper"
        >
            <button 
            class="WizButton_base__ojkNL WizButton_primary-contained__xOImR WizButton_L__UZfj4 WizButton_WizFullWidth__DvHSM" 
            type="submit" 
            disabled
            >
            <span class="WizButton_text__oCBg0">SUBMIT</span>
            <span class="WizRipple-wrapper"></span>
            </button>
        </div>
        </form>
    </div>

    <!-- Optional Footer -->
    <div class="WizPopupFooter_container__RJHAS"></div>
    </div>
</div>


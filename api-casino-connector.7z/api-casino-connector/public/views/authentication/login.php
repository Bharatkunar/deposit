<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 400px;
            margin: 50px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .btn {
            display: block;
            width: 100%;
            padding: 10px;
            font-size: 16px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .error, .success {
            color: #fff;
            padding: 10px;
            margin-bottom: 15px;
            text-align: center;
            border-radius: 4px;
        }
        .error {
            background-color: #e74c3c;
        }
        .success {
            background-color: #2ecc71;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login to Loyalty Casino</h2>
        <form method="POST" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <?php wp_nonce_field('casino_login_nonce', 'casino_login_nonce_field'); ?>
            <input type="hidden" name="action" value="casino_login_user">
            <?php if (isset($_GET['message']) && !empty($_GET['message'])): ?>
                <div class="<?= $_GET['status'] === 'error' ? 'error' : 'success'; ?>">
                    <?= htmlspecialchars($_GET['message']); ?>
                </div>
            <?php endif; ?>
            <div class="form-group">
                <label for="username">Username or Email</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <?php wp_nonce_field('casino_login_nonce', 'casino_login_nonce_field'); ?>
            <input type="hidden" name="action" value="casino_login_user" />

            <button type="submit" class="btn">Login</button>
        </form>
    </div>
</body>
</html>


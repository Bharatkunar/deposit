<style>
#gusta-modal {
  overflow: hidden;
  height: 100%;
  width: 100%;
}

#gusta-modal .fusion-modal-content {
  position: relative;
  display: flex;
  flex-direction: column;
  padding: 24px;
  width: 100%;
  min-width: 100%;
  border-radius: 8px;
  box-shadow: 4px 4px 20px rgba(0, 11, 45, .5);
  background: var(--background-side-menu);
  overflow: hidden;
  animation: WizPopupWrapper_slide_in__VWg2O .3s ease-in-out;
}


#signup-modal {
    --background-side-menu: #1e1e2f;
    --primary-color: #facc15;
    --text-color: #ffffff;
    font-family: Arial, sans-serif;
    color: var(--text-color);
    overflow: hidden;
    height: 100%;
    width: 100%;
    overflow: hidden;

    
  }

#signup-modal .fusion-modal-content {
    position: relative;
    display: flex;
    flex-direction: column;
    padding: 24px;
    width: 100%;
    min-width: 100%;
    border-radius: 8px;
    box-shadow: 4px 4px 20px rgba(0, 11, 45, .5);
    background: var(--background-side-menu);
    overflow: hidden;
    animation: WizPopupWrapper_slide_in__VWg2O .3s ease-in-out;
}
</style>

<div id="gusta-modal">
  <div class="WizPopupBody_wrapper__5pKBD">
    <div class="WizPopupBody_wrapper__content__MeLJD">
      <div class="WizPopupBody_wrapper__content_inner__h7aDQ">

        <form method="post" class="WizForm_base__gGggs login">
          <!-- Username / Email -->
          <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc">
            <label for="email">Username/Email</label>
            <input type="text" name="email" id="email" required>
          </div>

          <!-- Password -->
          <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_end__A97st">
            <label for="password">Password</label>
            <input type="text" name="password" id="password" required>

            <button type="button" class="WizIconButton_base__JfGpY" id="toggle-password" style="position: absolute; right: 4px; top: 4px; height: 36px; width: 36px;">
              <div class="WizIconButton_children__Xqp6z">
                <svg class="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-1jekisg" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="VisibilityOffIcon">
                  <path d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7M2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2m4.31-.78 3.15 3.15.02-.16c0-1.66-1.34-3-3-3z"></path>
                </svg>
              </div>
              <span class="WizRipple-wrapper"></span>
            </button>
          </div>

          <!-- Remember me & Forgot password -->
          <div class="WizForm_row__QIO2O" style="grid-template-columns: 1fr 1fr; justify-content: space-between;">
            <div class="WizToggleBox_base__YKIBS WizToggleBox_primary-outlined__ayNtP WizToggleBox_XS__YsWr_ undefined">
              <label for="remember" style="cursor: pointer;">
                <input type="checkbox" name="remember" id="remember"><span></span>Remember Me
              </label>
            </div>
          </div>

          <!-- Error message display -->
          <div class="WizForm_error__To6eX" style="display: none; color: white; font-size: 12px; margin-bottom: 10px;"></div>

          <!-- WP Nonce and Action -->
          <?php wp_nonce_field('casino_login_nonce', 'casino_login_nonce_field'); ?>
          <input type="hidden" name="action" value="casino_login_user">

          <!-- Login Button -->
          <div class="WizButtonContainer_container__r4v3N WizButtonContainer_end__GdfvQ WizButtonContainer_row__FVI8Q WizButtonContainer_fullWidth__d5Jzj" data-button-container="wrapper">
            <button class="WizButton_base__ojkNL WizButton_primary-contained__xOImR WizButton_L__UZfj4 WizButton_WizFullWidth__DvHSM" type="submit">
              <span class="WizButton_text__oCBg0">Log In</span>
              <span class="WizRipple-wrapper"></span>
            </button>
          </div>

          <!-- Create Account Link -->
          <div class="Signup_alreadyHaveAccountContainer__tkc_T">
            <span class="Signup_alreadyHaveAccountContainer__button__9gbcD toggle-auth" data-view="signup">Create Account</span>
          </div>
          <button style="display:none" class="fusion-button button-default button-medium button default medium" type="button" data-dismiss="modal">Close</button>
        </form>

      </div>
    </div>
  </div>
</div>


<script>
jQuery(document).ready(function ($) {

    $('.login').on('submit', function (e) {
    e.preventDefault();

  const $form = $(this);
  const $btn = $form.find('button[type="submit"]');
  const $spinner = $('<span class="Toastify__spinner WizButton-spinner"></span>');
  const $errorBox = $form.find('.WizForm_error__To6eX');

  $errorBox.hide().html('');
  $btn.prop('disabled', true).append($spinner);

  $.ajax({
    type: 'POST',
    url: ajax_object.ajax_url,
    data: {
      action: 'casino_login_user',
      email: $('#email').val(),
      password: $('#password').val(),
    },
    success: function (response) {
      if (response.success) {
        $errorBox.html(response.data.message || 'Login successfull').show(); // changed `.text()` to `.html()`
        window.location.href = response.data.redirect;

      } else {
        $errorBox.html(response.data.message || 'Login failed').show(); // changed `.text()` to `.html()`
      }
    },
    error: function () {
      $errorBox.html('Something went wrong. Please try again.').show();
    },
    complete: function () {
      $btn.prop('disabled', false);
      $spinner.remove();
    }
  });
});
  
$('#toggle-password').on('click', function () {
    const $passwordInput = $('#password');
    const currentType = $passwordInput.attr('type');
    $passwordInput.attr('type', currentType === 'password' ? 'text' : 'password');
  });

});
</script>

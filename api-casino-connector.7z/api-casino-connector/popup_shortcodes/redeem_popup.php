<?php
// Redeem Popup Content with static form and redeem ID

echo '<div class="redeem-popup-message">';
echo "<p id = 'offer_description'></p>";
echo '</div>';

echo '<form id="redeem-offer-form">';
echo '<input type="hidden" id="offer_id" name="offer_id" value="">';
echo '<input type="hidden" id="contactid" name="offer_id" value="">';
echo '</form>';
?>

<script>
jQuery(document).ready(function ($) {
  $('#redeem-popup-offer').on('click', function (e) {
    e.preventDefault();
    var offerId = $('#offer_id').val();
    var contactid = $('#contactid').val();

    if (!offerId) {
      alert('Offer ID not found.');
      return;
    }

    if (!contactid) {
      alert('Contact ID not found.');
      return;
    }

    $.ajax({
      url: ajax_object.ajax_url, // Should be localized from WordPress
      type: "POST",
      data: {
        action: "redeemOffer", // Must match PHP function hook
        offer_id: offerId,
        contact_id : contactid
      },
      success: function (response) {
        try {
          var data = JSON.parse(response);
          if (data?.data?.statusCode) {
            alert("Offer successfully redeemed!");
            const popup = document.querySelector('#awb-oc-7330');
            popup.classList.remove('awb-show');          } else {
            alert("Redemption failed. Please try again.");
          }
        } catch (e) {
          alert("Unexpected response. Please try again.");
        }
      },
      error: function () {
        alert("Error redeeming the offer. Please try again.");
      }
    });
  });
});
</script>



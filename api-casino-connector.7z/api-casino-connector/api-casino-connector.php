<?php

/**
 * Plugin Name: Casino Games & Sports Betting
 * Description: Build an online casino coupled with RoboRewards loyalty technology.
 * Version: 1.0
 * Author: By RoboRewards
 */

// Define plugin version


define('CASINO_PLUGIN_VERSION', '1.0');
define('casino_DEVELOPMENT_MODE', true);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include required files
require_once __DIR__ . '/vendor/autoload.php'; // adjust if in plugin

require_once plugin_dir_path(__FILE__) . 'includes/class-utils-handler.php';

require_once plugin_dir_path(__FILE__) . 'includes/class-utils-handler.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-loyalty-controller.php';

require_once plugin_dir_path(__FILE__) . 'includes/class-db-handler.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-casino-api.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-game-controller.php';

require_once plugin_dir_path(__FILE__) . 'admin/casino-admin-menu.php';
require_once plugin_dir_path(__FILE__) . 'includes/casino-settings.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-menu-handler.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-auth-controller.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-logger.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-dashboard-handler.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-api-callback-handler.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-cronjob-handler.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-game-shortcode-handler.php';
require_once plugin_dir_path(__FILE__) . 'includes/casino-schema-handler.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-customer-controller.php';

require_once plugin_dir_path(__FILE__) . 'includes/class-roborewardloyalty-shortcode-handler.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-loyalty-cronjob-handler.php';
require_once plugin_dir_path(__FILE__) . 'includes/loyalty-callback-handler.php';
require_once plugin_dir_path(__FILE__) . 'includes/loyalty-schema-handler.php';
require_once plugin_dir_path(__FILE__) . 'includes/loyalty-woocommerce-schema-handler.php';
require_once plugin_dir_path(__FILE__) . 'includes/class_webhook_handler.php';
require_once plugin_dir_path(__FILE__) . 'includes/bharat-callback-handler.php';

// Woocommerce Handler
require_once plugin_dir_path(__FILE__) . 'includes/class-woocommerce-handler.php';

require_once plugin_dir_path(__FILE__) . 'includes/class-api-sync-handler.php';

// Load offers sync logic (so it's available when main handler calls it)
require_once plugin_dir_path(__FILE__) . 'includes/integrations/offers-sync.php';



add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('bootstrap-cdn', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css');
});

// add_action('plugins_loaded', function () {
//     Api_Sync_Handler::init_hooks(); // Register login hook and Action Scheduler callbacks
// });


add_action('init', function () {
    if (is_user_logged_in()) {
        $user_id = get_current_user_id();
        // Offers_Sync::sync($user_id);
    }
});

function enqueue_loyalty_profile_avada_styles() {
    // Only enqueue on pages where the shortcode is used
    if ( is_singular() && has_shortcode(get_post()->post_content, 'loyalty_profile') ) {
        wp_enqueue_style(
            'loyalty-avada-shortcode-style',
            site_url('/wp-content/uploads/fusion-styles/c186b3af6debe00632fb1a47899c12a3.min.css'),
            array(),
            '3.9.1'
        );
    }
}
add_action('wp_enqueue_scripts', 'enqueue_loyalty_profile_avada_styles');

add_action('rest_api_init', function () {
    // Register the endpoint for the callback API
    register_rest_route('api-casino/v1', '/callback', [
        'methods' => ['GET', 'POST'],
        'callback' => ['API_Callback_Handler', 'handle_callback'],  // Point to the handle_callback method
        'permission_callback' => '__return_true', // Be careful: This allows anyone to trigger the cron
    ]);

    register_rest_route('api-casino/v1', '/trigger-cron', [
        'methods' => ['GET'], // Allow both GET and POST requests
        'callback' => 'trigger_cronjob',
    ]);

    register_rest_route('api-loyalty/v1', '/trigger-cron', [
        'methods' => ['GET'], // Allow both GET and POST requests
        'callback' => 'trigger_loyalty_cronjob',
    ]);

    register_rest_route('api-loyalty/v1', '/callback', [
        'methods' => ['GET'], // Allow both GET and POST requests
        'callback' => ['Loyalty_CallBack_Handler', 'handle_callback'],  // Point to the handle_callback method
        'permission_callback' => '__return_true', // Be careful: This allows anyone to trigger the cron

    ]);



    // Register by Bharat

    register_rest_route('Bharat_CallBack_Handler/v1', '/callback', [
        'methods' => ['GET'], // Allow both GET and POST requests
        'callback' => ['Bharat_CallBack_Handler', 'handle_callback'],  // Point to the handle_callback method
        'permission_callback' => '__return_true', // Be careful: This allows anyone to trigger the cron

    ]);

    register_rest_route('api-woocommerce/v1', '/callback', [
        'methods' => ['GET'], // Allow both GET and POST requests
        'callback' => ['Loyalty_CallBack_Handler', 'handle_callback'],  // Point to the handle_callback method
        'permission_callback' => '__return_true', // Be careful: This allows anyone to trigger the cron
    ]);
    register_rest_route('api-get-games/v1', '/get-games', [
        'methods' => ['GET'], // Allow both GET and POST requests
        'callback' => ['Loyalty_CallBack_Handler', 'get_games'], // Point to the handle_callback method
    ]);

    register_rest_route('api-get-games-filters/v1', '/get-filters', [
        'methods' => ['GET'], // Allow both GET and POST requests
        'callback' => ['Loyalty_CallBack_Handler', 'getGameFiltersList'], // Point to the handle_callback method
    ]);
    register_rest_route('api-get-shortcode-list/v1', '/get-shortcodes', [
        'methods' => ['GET'], // Allow both GET and POST requests
        'callback' => ['Loyalty_CallBack_Handler', 'get_shortcode_list'], // Point to the handle_callback method
    ]);
    register_rest_route('api-create-shortcode/v1', '/create-shortcode', [
        'methods' => ['POST'], // Allow both GET and POST requests
        'callback' => ['Loyalty_CallBack_Handler', 'create_shortcode'], // Point to the handle_callback method
    ]);
    register_rest_route('api-get-single-shortcode/v1', '/get-shortcode', [
        'methods' => ['GET'], // Allow both GET and POST requests
        'callback' => ['Loyalty_CallBack_Handler', 'get_single_shortcode'], // Point to the handle_callback method
    ]);


    register_rest_route('api-webhook/v1', '/receive', [
        'methods'             => ['POST'], // Webhooks usually POST data
        'callback'            => ['Webhook_Handler', 'handle_webhook'],
        'permission_callback' => '__return_true', // Public access
    ]);

    register_rest_route('api-webhook/v1', '/acknowledge', [
        'methods'             => ['POST'], // Webhooks usually POST data
        'callback'            => ['Webhook_Handler', 'handle_webhook'],
        'permission_callback' => '__return_true', // Public access
    ]);

});

// Cronjob Handler

function trigger_cronjob()
{
    // Check for nonce or other security measures here (optional)
    // Manually trigger your cron job
    do_action('wp_cronjob_fetch_products');
    return new WP_REST_Response('Cron job triggered successfully', 200);
}

function trigger_loyalty_cronjob()
{
    do_action('wp_cronjob_hit_callbacks');
    return new WP_REST_Response('Cron job triggered successfully', 200);
}


// Hook for plugin activation
register_activation_hook(__FILE__, 'casino_activate_plugin');

// Hook for plugin deactivation
register_deactivation_hook(__FILE__, 'casino_deactivate');



// get ip address

function get_client_ip()
{
    $ip = '';

    // Check for shared internet/ISP proxy
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // Multiple IPs might be present (comma-separated), take the first one
        $ip = trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
    } elseif (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        // Check for IP from shared Internet/ISP
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } else {
        // Use REMOTE_ADDR if no other header is available
        $ip = $_SERVER['REMOTE_ADDR'];
    }

    return $ip;
}



function inject_wp_popup_response()
{
    $wp_popup_response = get_option('popup_api_response'); // Get stored value
    echo "<script>window.wpPopupResponse = " . json_encode($wp_popup_response) . ";</script>";
}
add_action('wp_head', 'inject_wp_popup_response');


function vendor_registration_on_activation()
{
    // Get the server's IP address
    // $server_ip = get_client_ip(); // For server IP

    // // Your base URL (can be dynamic depending on plugin settings)
    // $base_url = get_site_url();
    // // Prepare the data for the API request
    // $data = array(
    //     'base_url' => $base_url,
    //     'ip_address' => $server_ip,
    //     'callback_url' => get_option('casino_callback_url'), // Initially empty; will be updated later
    // );

    $loyalty = new LoyaltyApiHanlder();
    $response = $loyalty->merchantDetails();

  
    // Make the API request
    // $response = vendor_registration_api_request($data);


    // Check the response
    if ($response && isset($response['statusCode']) && $response['statusCode']) {
        // Store the vendor ID or data in the plugin options or database
        update_option('casino_merchant_id', $response['responsedata']['casinoMerchantId']);
        update_option('casino_merchant_key', $response['responsedata']['casinoMerchantKey']);
        update_option('casino_base_url', $response['responsedata']['casinoBaseUrl']);
        // Optionally store other data like base_url, callback_url, etc.
    } else {
        // Handle the error
        error_log('Vendor registration failed: ' . json_encode($response));
    }
}

function vendor_registration_api_request($data)
{
    // API URL (update with your actual API URL)
    $api_url = 'https://abmkoders.com/api.php'; // Replace with your API URL

    // Make the API request using wp_remote_post
    $response = wp_remote_post($api_url, array(
        'method'    => 'POST',
        'body'      => $data,
        'headers'   => array(
            'Content-Type' => 'application/x-www-form-urlencoded',
        ),
    ));

    // Check for errors in the response
    if (is_wp_error($response)) {
        return null;
    }

    // Decode the response body
    $response_body = wp_remote_retrieve_body($response);
    return json_decode($response_body, true);
}

function check_assigned_menu($location)
{
    // Get the assigned menu for the given location
    $assigned_menu = get_nav_menu_locations();

    if (isset($assigned_menu[$location])) {
        $menu_id = $assigned_menu[$location];
        $menu = wp_get_nav_menu_object($menu_id);

        if ($menu) {
            return 'Assigned menu: ' . $menu->name;
        } else {
            return 'Menu assigned to this location, but cannot fetch menu details.';
        }
    } else {
        return 'No menu assigned to this location.';
    }
}

// Example: Checking the "main_navigation" location
// echo check_assigned_menu('main_navigation');

// Create tables on activation

function casino_activate_plugin()
{

    $schema_handler = new Schema_Handler();
    $schema_handler->create_or_update_tables();

    // Create default pages
    $menu_handler = new FrontMenuHandler();
    $menu_handler->casino_activate_plugin();
    // Flush rewrite rules to apply the new URL structure


    $loyaltySchemaHandler = new Loyalty_Schema_handler();
    $loyaltySchemaHandler->create_or_update_tables();


    // Woocommerce Loyalty Connection

    $loyaltyWoocommerceSchema = new Loyalty_Woocommerce_Schema_handler();
    $loyaltyWoocommerceSchema->create_or_update_tables();


    flush_rewrite_rules();



    $callback_url = get_site_url() . "/wp-json/api-loyalty/v1/callback";
    update_option('loyalty_callback', $callback_url);

    // activate Roles
    add_role(
        'game_customer',
        __('Game Customer', 'casino'),
        array(
            'read'         => true,  // Allows read-only access
            'edit_posts'   => false, // Cannot edit posts
            'delete_posts' => false, // Cannot delete posts
        )
    );

    $handler = new casino_Dashboard_Handler();
    $handler->add_custom_dashboard_endpoints();

    // send activation to the server

    vendor_registration_on_activation();

    casino_plugin_log('Plugin activated successfully.');
}


function restrict_dashboard_access()
{
    if (!is_user_logged_in() && is_page('dashboard')) {
        wp_redirect(home_url('/login'));
        exit;
    }
}
add_action('template_redirect', 'restrict_dashboard_access');


function casino_enqueue_dashboard_styles()
{
    // Enqueue the dashboard CSS only if the user is logged in or on a specific dashboard page
    if (is_page('dashboard') || is_user_logged_in()) {
        wp_enqueue_style(
            'casino-dashboard-styles', // Handle for the style
            plugin_dir_url(__FILE__) . 'assets/admin/css/dashboard.css', // Path to the CSS file
            array(), // Dependencies (none in this case)
            '1.0.0', // Version of the style
            'all' // Media type
        );
    }
}
add_action('wp_enqueue_scripts', 'casino_enqueue_dashboard_styles');


function casino_enqueue_dashboard_scripts()
{
    // Ensure jQuery is enqueued
    wp_enqueue_script('jquery');

    if (is_page('dashboard') || is_user_logged_in()) {
        wp_enqueue_script(
            'casino-dashboard-scripts',
            plugin_dir_url(__FILE__) . 'assets/frontend/script.js',
        );
    }
}
add_action('wp_enqueue_scripts', 'casino_enqueue_dashboard_scripts');



function loyalty_enqueue_styles()
{
    // Bootstrap 3.2.0
    wp_enqueue_style('bootstrap-css', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css');

    // FontAwesome (for icons)
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');

    // Custom CSS with versioning
    $css_version = filemtime(plugin_dir_path(__FILE__) . 'loyalty/assets/css/style.css'); // Gets file modification time
    wp_enqueue_style('loyalty-style', plugin_dir_url(__FILE__) . 'loyalty/assets/css/style.css', [], $css_version);
}
add_action('wp_enqueue_scripts', 'loyalty_enqueue_styles');


function casino_enqueue_styles()
{
  // Custom CSS with versioning
    $css_version = filemtime(plugin_dir_path(__FILE__) . 'assets/casino/css/style.css'); // Gets file modification time
    wp_enqueue_style('casino-style', plugin_dir_url(__FILE__) . 'assets/casino/css/style.css', [], $css_version);
}
add_action('wp_enqueue_scripts', 'casino_enqueue_styles');


// Auth Bottons

function render_auth_buttons() {
    if (is_user_logged_in()) {
        $dashboard_url = home_url('/dashboard');
        $logout_url = wp_logout_url(home_url());

        return '
            <div class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-end fusion-content-layout-row fusion-flex-align-items-center">
                <div class="auth-buttons-row" style="display: flex; gap: 10px; align-items: center;">
                    <a class="fusion-button button-flat button-medium button-custom fusion-button-default button-1 fusion-button-default-span fusion-button-default-type"
                       style="--button_accent_color: var(--awb-color1);
                              --button_accent_hover_color: var(--awb-color1);
                              --button_border_hover_color: var(--awb-color1);
                              --button_border_width-top: 2px;
                              --button_border_width-right: 2px;
                              --button_border_width-bottom: 2px;
                              --button_border_width-left: 2px;
                              --button-border-radius-top-left: 5px;
                              --button-border-radius-top-right: 5px;
                              --button-border-radius-bottom-right: 5px;
                              --button-border-radius-bottom-left: 5px;
                              --button_gradient_top_color: var(--awb-color4);
                              --button_gradient_bottom_color: var(--awb-color4);
                              --button_gradient_top_color_hover: var(--awb-color4);
                              --button_gradient_bottom_color_hover: var(--awb-color4);
                              cursor: pointer;"
                       href="' . esc_url($dashboard_url) . '" target="_self">
                        <span class="fusion-button-text">Dashboard</span>
                    </a>

                    <a class="fusion-button button-flat button-medium button-default fusion-button-default button-2 fusion-button-default-span fusion-button-default-type"
                       style="--button-border-radius-top-left: 5px;
                              --button-border-radius-top-right: 5px;
                              --button-border-radius-bottom-right: 5px;
                              --button-border-radius-bottom-left: 5px;
                              cursor: pointer;"
                       href="' . esc_url($logout_url) . '" target="_self">
                        <span class="fusion-button-text">Logout</span>
                    </a>
                </div>
            </div>
        ';
    } else {
        return '
            <div class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-end fusion-content-layout-row fusion-flex-align-items-center">
                <div class="auth-buttons-row" style="display: flex; gap: 10px; align-items: center;">
                    <a class="fusion-button button-flat button-medium button-custom fusion-button-default button-1 fusion-button-default-span fusion-button-default-type"
                       style="--button_accent_color: var(--awb-color1);
                              --button_accent_hover_color: var(--awb-color1);
                              --button_border_hover_color: var(--awb-color1);
                              --button_border_width-top: 2px;
                              --button_border_width-right: 2px;
                              --button_border_width-bottom: 2px;
                              --button_border_width-left: 2px;
                              --button-border-radius-top-left: 5px;
                              --button-border-radius-top-right: 5px;
                              --button-border-radius-bottom-right: 5px;
                              --button-border-radius-bottom-left: 5px;
                              --button_gradient_top_color: var(--awb-color4);
                              --button_gradient_bottom_color: var(--awb-color4);
                              --button_gradient_top_color_hover: var(--awb-color4);
                              --button_gradient_bottom_color_hover: var(--awb-color4);
                              cursor: pointer;"
                       href="#" data-toggle="modal" data-target=".fusion-modal.login" target="_self">
                        <span class="fusion-button-text">Log in</span>
                    </a>

                    <a class="fusion-button button-flat button-medium button-default fusion-button-default button-2 fusion-button-default-span fusion-button-default-type"
                       style="--button-border-radius-top-left: 5px;
                              --button-border-radius-top-right: 5px;
                              --button-border-radius-bottom-right: 5px;
                              --button-border-radius-bottom-left: 5px;
                              cursor: pointer;"
                       href="#" data-toggle="modal" data-target=".fusion-modal.signup" target="_self">
                        <span style="white-space: nowrap;" class="fusion-button-text">Sign Up</span>
                    </a>
                </div>
            </div>
        ';
    }
}
add_shortcode('auth_buttons', 'render_auth_buttons');



add_action('wp_enqueue_scripts', function () {
    if (function_exists('Avada')) {
        wp_enqueue_style('fusion-dynamic-css');
    }
});




function loyalty_enqueue_scripts()
{
    // Deregister the default jQuery (Optional: If you want to replace WP's jQuery)
    wp_deregister_script('jquery');

    // Register and enqueue local jQuery
    wp_register_script(
        'jquery',
        plugin_dir_url(__FILE__) . 'loyalty/assets/js/jquery-3.6.0.min.js',
        array(),
        '3.6.0',
        true
    );
    wp_enqueue_script('jquery');
    // Enqueue custom script with jQuery dependency
    wp_enqueue_script(
        'loyalty-addon-scripts',
        plugin_dir_url(__FILE__) . 'loyalty/assets/js/script.js',
        array('jquery'),
        '1.0.0',
        true
    );
    // Pass AJAX URL to the script
    wp_localize_script('loyalty-addon-scripts', 'ajax_object', array(
        'ajax_url' => admin_url('admin-ajax.php')
    ));
}
add_action('wp_enqueue_scripts', 'loyalty_enqueue_scripts');

function custom_modal_start_session()
{
    if (!session_id()) {
        session_start();
    }
}
add_action('init', 'custom_modal_start_session');

// Enqueue styles & scripts
function custom_modal_enqueue_scripts()
{
    wp_enqueue_style('custom-modal-style', plugin_dir_url(__FILE__) . 'assets/css/custom-modal.css');
    wp_enqueue_script('custom-modal-script', plugin_dir_url(__FILE__) . 'assets/js/custom-modal.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'custom_modal_enqueue_scripts');

// Add modal HTML to footer
function custom_modal_add_html()
{
?>
    <div id="custom-modal" class="custom-modal">
        <div class="custom-modal-content">
            <span id="modal-close" class="custom-modal-close">&times;</span>
            <div id="modal-icon" class="modal-icon"></div>
            <p id="modal-message" class="modal-message"></p>
        </div>
    </div>
<?php
}
add_action('wp_footer', 'custom_modal_add_html');
// // Enqueue styles and scripts for the admin panel (back-end)
function casino_enqueue_admin_styles()
{
    // Enqueue styles specifically for the admin panel
    wp_enqueue_style(
        'casino-dashboard-styles-admin',
        plugin_dir_url(__FILE__) . 'assets/admin-panel/css/style.css',
        array(),
        '1.0.0',
        'all'
    );

    // Enqueue JS if needed for the admin panel
    wp_enqueue_script(
        'casino-dashboard-scripts-admin',
        plugin_dir_url(__FILE__) . 'assets/admin-panel/js/script.js',
        array('jquery'),
        '1.0.0',
        true // Load JS in footer
    );

    wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css');

    // Bootstrap JS and Popper.js (for dropdowns, modals, etc.)
    wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js', array('jquery'), null, true);
}

add_action('admin_enqueue_scripts', 'casino_enqueue_admin_styles');


function casino_initialize_auth_controller()
{
    new Casino_Auth_Controller();
}
add_action('plugins_loaded', 'casino_initialize_auth_controller');

function casino_plugin_log($message)
{
    Logger::log($message);
}

function enqueue_custom_scripts()
{
    wp_enqueue_script('custom-popup-script', get_template_directory_uri() . '/assets/js/custom-popup.js', array('jquery'), null, true);

    $popup_api_response = get_option('popup_api_response', 'default_value');
    wp_localize_script('custom-popup-script', 'popupSettings', array(
        'apiResponse' => $popup_api_response
    ));
}
// Deactivate plugin
function casino_deactivate()
{

    update_option('casino_plugin_installed', '0');
    casino_plugin_log('Plugin deactivated, installation flag set to 0.');
    remove_filter('wp_nav_menu_items', 'add_dashboard_menu_item', 10);

    // Delete pages created by the plugin
    $pages_to_delete = ['Play Games', 'Game Lobby', 'Login', 'Register', 'Dashboard']; // Titles of the pages to be deleted
    foreach ($pages_to_delete as $page_title) {
        $page = get_page_by_title($page_title);
        if ($page) {
            wp_delete_post($page->ID, true); // true to force delete
        }
    }
    $handler = new casino_Dashboard_Handler();
    $handler->add_custom_dashboard_endpoints();
    flush_rewrite_rules();
}


// Calling templates

function load_combined_templates()
{
    ob_start();


    include get_theme_root() . '/template-transactionHistory.php'; // Update the template name if necessary


    return ob_get_clean();
}
add_shortcode('combined_templates', 'load_combined_templates');





add_action('woocommerce_thankyou', 'loyalty_capture_and_send_order', 20, 1);

function loyalty_capture_and_send_order($order_id) {
    if (!$order_id) return;

    $remote_url = 'http://localhost/bcasino/webhook/index.php';

    $payload = [
        'woo_order_id' => $order_id,
        'time' => current_time('mysql')
    ];

    // Send webhook
    $response = wp_remote_post($remote_url, [
        'timeout' => 10,
        'headers' => ['Content-Type' => 'application/json'],
        'body'    => json_encode($payload),
    ]);

    // Optional: Log result to plugin folder
    $log_path = __DIR__ . '/order.log';
    $log_entry = "[" . date('Y-m-d H:i:s') . "] Order ID: $order_id\n" . print_r($response, true) . "\n\n";
    file_put_contents($log_path, $log_entry, FILE_APPEND);
}




add_action('wp_footer', function () {
    if (!is_user_logged_in()) return;

    $user_id = get_current_user_id();
    ?>
    <script src="https://js.pusher.com/7.2/pusher.min.js"></script>
    <script>
    Pusher.logToConsole = true;

    const pusher = new Pusher('4994bb580820ff5f007d', {
        cluster: 'ap2',
    });

    const channel = pusher.subscribe('user-<?php echo $user_id; ?>');

    channel.bind('popup-7330', function(data) {
        const popup = document.querySelector('#awb-oc-7330');
        const offerIdField = document.querySelector('#offer_id');
        const contactid = document.querySelector('#contactid');
        const offerDescField = document.querySelector('.redeem-popup-message p');

        // ✅ 1. Update hidden offer_id field
        if (offerIdField && data.offer_id) {
            offerIdField.value = data.offer_id;
        }

        // ✅ 1. Update hidden offer_id field
        if (contactid && data.contactid) {
            contactid.value = data.contactid;
        }

        // ✅ 2. Update description text
        if (offerDescField && data.loyalty_offer_description) {
            offerDescField.textContent = data.loyalty_offer_description;
        }
        else
        {
            offerDescField.textContent = "NO RECORD";
        }

        // ✅ 3. Show popup
        if (popup) {
            popup.classList.add('awb-show');
            popup.style.visibility = 'visible';
            console.log("🎯 Popup updated with ID:", data.offer_id);
        } else {
            console.warn("❌ Modal #awb-oc-7330 not found.");
        }
    });
    </script>
    <?php
});





add_action('wp_head', function () {
    if (!is_user_logged_in()) {
        // Not logged in — hide all Smart Coupons UI
        echo '<style>.wt_sc_single_coupon, .wt_sc_coupon_grid_wrapper, .wt-sc-available-coupons-section { display: none !important; }</style>';
        return;
    }

    // 🔄 Dynamic: Get allowed coupon IDs for this user
    $current_user_id = get_current_user_id();
    $current_contact_id = get_user_meta($current_user_id, 'contact_id', true);

    // Get all coupons assigned to this user/contact
    $args = [
        'post_type' => 'shop_coupon',
        'posts_per_page' => -1,
        'post_status' => 'publish',
        'meta_query' => [
            'relation' => 'OR',
            [
                'key'     => '_loyalty_user_id',
                'value'   => $current_user_id,
                'compare' => '=',
            ],
            [
                'key'     => '_loyalty_contact_id',
                'value'   => $current_contact_id,
                'compare' => '=',
            ],
        ],
    ];

    $query = new WP_Query($args);   
    $allowed_ids = wp_list_pluck($query->posts, 'ID');

    ?>
    <style>
        .wt_sc_single_coupon {
            display: none !important;
        }
        <?php foreach ($allowed_ids as $id): ?>
        .wt_sc_single_coupon[data-id="<?php echo esc_attr($id); ?>"] {
            display: block !important;
        }
        <?php endforeach; ?>
    </style>
    <?php
});


add_action('woocommerce_checkout_create_order', function($order, $data) {
    $coupons = $order->get_coupon_codes();

    if (empty($coupons)) return;

    foreach ($coupons as $code) {
        $coupon = new WC_Coupon($code);
        $coupon_id = $coupon->get_id();

        if (!$coupon_id) continue;

        // Get loyalty metadata from the coupon
        $loyalty_user_id = get_post_meta($coupon_id, '_loyalty_user_id', true);
        $loyalty_contact_id = get_post_meta($coupon_id, '_loyalty_contact_id', true);
        $loyalty_offer_id = get_post_meta($coupon_id, '_loyalty_offer_id', true);

        // Save to order meta — include coupon code for clarity
        if ($loyalty_user_id) {
            $order->add_meta_data('_loyalty_coupon_user_id_' . $code, $loyalty_user_id);
        }

        if ($loyalty_contact_id) {
            $order->add_meta_data('_loyalty_coupon_contact_id_' . $code, $loyalty_contact_id);
        }

        if ($loyalty_offer_id) {
            $order->add_meta_data('_loyalty_coupon_offer_id_' . $code, $loyalty_offer_id);
        }
    }
}, 20, 2);













?>
document.addEventListener("DOMContentLoaded", function () {
    function openModal(message, isSuccess = true) {
        const modal = document.getElementById("custom-modal");
        const modalMessage = document.getElementById("modal-message");
        const modalIcon = document.getElementById("modal-icon");

        if (!modal) return;

        modalMessage.textContent = message;
        modalIcon.innerHTML = isSuccess ? "✅" : "❌"; // Success or Error Icon

        modal.style.display = "flex";
    }

    function closeModal() {
        const modal = document.getElementById("custom-modal");
        if (modal) modal.style.display = "none";
    }

    // Remove this part as it's causing unwanted test popups
    // document.querySelectorAll(".open-modal-btn").forEach(button => {
    //     button.addEventListener("click", function () {
    //         const message = this.getAttribute("data-message") || "Default Message";
    //         const isSuccess = this.getAttribute("data-success") === "true";
    //         openModal(message, isSuccess);
    //     });
    // });

    document.getElementById("modal-close").addEventListener("click", closeModal);

    document.getElementById("custom-modal").addEventListener("click", function (event) {
        if (event.target.id === "custom-modal") {
            closeModal();
        }
    });

    window.openModal = openModal;
});

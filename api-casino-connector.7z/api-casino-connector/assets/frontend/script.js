document.addEventListener("DOMContentLoaded", function () {
    // Select the common parent container of all grids (you can adjust the selector if needed)
    const parentContainer = document.querySelector(".shortcode_div");
    if (parentContainer) {
        // Attach click event listener to the parent container
        parentContainer.addEventListener("click", function (event) {
            // Check if the clicked element is an image
            if (event.target.tagName === "IMG") {
                const image = event.target;
                const imageUrl = image.src;

                // Apply the same styling as before
                image.style.opacity = "0.5";
                image.style.border = "2px solid #007bff";
                image.style.transition = "all 0.3s ease-in-out";
                image.style.transform = "scale(0.95)";

                // Parse the URL to extract query parameters
                const urlParams = new URL(imageUrl).searchParams;
                const apiGameId = urlParams.get("id");
                const localId = urlParams.get("local_id");
                const gameName = urlParams.get("game");

                console.log("API Game ID:", apiGameId);
                console.log("Local ID:", localId);
                console.log("Game Name:", gameName);

                // Call playGame only if all params are available
                if (apiGameId && localId && gameName) {
                    playGame(apiGameId, localId, gameName);
                }
            }
        });

    }

    function playGame(api_game_id, gameId, name) {
        const spinner = document.getElementById("spinner");
        if (spinner) {
            spinner.style.display = "block";
        }

        const formData = new URLSearchParams();
        formData.append("action", "play_game");
        formData.append("game_uuid", api_game_id);
        formData.append("game_id", gameId);
        formData.append("game_name", name);
        const baseUrl = `${window.location.protocol}//${window.location.host}/`;


        fetch(`${ajax_object.ajax_url}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: formData.toString(),
        })
            .then((response) => response.json())
            .then((data) => {
                if (spinner) {
                    spinner.style.display = "none";
                }

                if (data.success) {
                    if (data?.data?.game_url) {
                        window.open(data.data.game_url, '_blank');
                    }
                } else {
                    alert("Error: " + data?.data?.message);
                }
            })
            .catch((error) => {
                if (spinner) {
                    spinner.style.display = "none";
                }
                alert("Failed to start the game.");
            });
    }


    // Ale

});

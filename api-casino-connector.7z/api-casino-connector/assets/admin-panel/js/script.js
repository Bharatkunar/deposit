document.addEventListener('DOMContentLoaded', function () {

    const tabs = document.querySelectorAll('.nav-tab');
    const contents = document.querySelectorAll('.tab-content');


    tabs.forEach(tab => {
        tab.addEventListener('click', function (e) {
            e.preventDefault();
            // Remove active class from all tabs and hide all content
            tabs.forEach(t => t.classList.remove('nav-tab-active'));
            contents.forEach(content => content.style.display = 'none');
            // Add active class to clicked tab and show the corresponding content
            this.classList.add('nav-tab-active');
            // const target = document.querySelector(this.getAttribute('href'));
            // target.style.display = 'block';
        });
    });

    let totalRecords = document.getElementById('total_records');
    if (totalRecords) {
        // Play with Online and Offline

        let totalRecords = document.getElementById('total_records');
        let modeSelect = document.querySelector("select[name='active']");
        let sliderYes = document.getElementById('slider_yes');
        let sliderNo = document.getElementById('slider_no');
        let sliderTypeOptions = document.getElementById('slider_type_options');
        let warningText = document.getElementById('warning-text');
        let columnsInput = document.getElementById('columns');
        let submitButton = document.querySelector("input[type='submit']");

        if (modeSelect && totalRecords) {
            modeSelect.addEventListener("change", function () {
                totalRecords.value = this.value === "1" ? activeGames : inactiveGames;
            });
        }



        document.getElementById('total_records').addEventListener('input', adjustColumns);



        function checkSliderValidation() {
            let columns = parseInt(columnsInput.value) || 0;

            if (sliderYes.checked && columns < 7) {
                warningText.style.display = 'block';
                submitButton.disabled = true;  // Disable submit button
            } else {
                warningText.style.display = 'none';
                submitButton.disabled = false;  // Enable submit button
            }
        }

        sliderYes.addEventListener('change', checkSliderValidation);
        sliderNo.addEventListener('change', checkSliderValidation);

        // Listen for changes in column value
        columnsInput.addEventListener('input', checkSliderValidation);


        checkSliderValidation();



        // Show/Hide Slider Type Options
        sliderYes.addEventListener('change', function () {
            if (this.checked) {
                sliderTypeOptions.style.display = 'block';
                warningText.style.display = 'block';  // Show warning text
            }
        });

        sliderNo.addEventListener('change', function () {
            if (this.checked) {
                sliderTypeOptions.style.display = 'none';
                warningText.style.display = 'none';  // Hide warning text
            }
        });

    }



    let selectAll = document.getElementById('select-all');
    if (selectAll) {

        document.getElementById('select-all').addEventListener('click', function () {
            const checkboxes = document.querySelectorAll('.game-checkbox');
            const allChecked = Array.from(checkboxes).every(checkbox => checkbox.checked);

            checkboxes.forEach(checkbox => checkbox.checked = !allChecked);

            // Update button text and color
            if (allChecked) {
                this.textContent = "Select All";
                this.classList.remove('btn-success');
                this.classList.add('btn-secondary');
            } else {
                this.textContent = "Unselect All";
                this.classList.remove('btn-secondary');
                this.classList.add('btn-success');
            }
        });
    }




});


// Game Setup Short Page

// Function to dynamically update columns based on rows and total records
function adjustColumns() {
    const totalRecords = parseInt(document.getElementById('total_records').value) || 1;
    const rows = parseInt(document.getElementById('rows').value) || 1;

    // Calculate columns per row
    const columns = Math.ceil(totalRecords / rows);

    // Update columns input
    document.getElementById('columns').value = columns;
}

// Update columns dynamically if total records change

document.addEventListener('DOMContentLoaded', function () {

});



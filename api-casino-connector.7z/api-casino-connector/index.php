<?php
// Function to get the limit of free spins
function getLimitFreeSpin($baseurl, $endpoint, $merchantId, $merchantKey, $requestType = 'GET', $postData = [])
{
    // Generate the full URL
    $url = rtrim($baseurl, '/') . '/' . ltrim($endpoint, '/');

    // Extract query string for GET requests
    $queryString = parse_url($endpoint, PHP_URL_QUERY);

    // Handle parameters for POST or GET requests
    if ($requestType === 'POST') {
        $params = $postData; // POST data
    } else {
        $params = []; // GET request will not require post data
    }

    // Generate headers with the correct signature
    $headers = generateXSignHeaders($merchantId, $merchantKey, $params, $queryString);

    // Debugging: Output generated headers and request URL
    echo "<h3>Generated Headers:</h3>";
    echo "<pre>";
    print_r($headers);
    echo "</pre>";

    echo "<h3>Request URL:</h3>";
    echo $url;
    echo "<br><br>";

    // Initialize cURL session
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // If it's a POST request, set the POST data
    if ($requestType === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData)); // POST data as query string
    }

    // Set the headers for the cURL request
    curl_setopt($ch, CURLOPT_HTTPHEADER, formatHeaders($headers));

    // Execute the request
    $response = curl_exec($ch);

    // Check for errors
    if (curl_errno($ch)) {
        $error = curl_error($ch);
        curl_close($ch);
        return ['error' => $error];
    }

    // Get the HTTP response code
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    // Debugging: Output HTTP response code
    echo "<h3>HTTP Response Code:</h3>";
    echo $httpCode;
    echo "<br><br>";

    // Decode the JSON response
    $decodedResponse = json_decode($response, true);

    // Debugging: Output raw and decoded responses
    echo "<h3>Raw Response:</h3>";
    echo "<pre>";
    print_r($response);
    echo "</pre>";

    echo "<h3>Decoded Response:</h3>";
    echo "<pre>";
    print_r($decodedResponse);
    echo "</pre>";

    return $decodedResponse;
}

// Function to generate X-Sign headers
function generateXSignHeaders($merchantId, $merchantKey, $requestParams = [], $queryString = '')
{
    // Generate the required headers for the request
    $headers = [
        'X-Merchant-Id' => $merchantId,
        'X-Timestamp' => time(),
        'X-Nonce' => md5(uniqid(mt_rand(), true)),
    ];

    // Parse the query string into an array if it's provided
    parse_str($queryString, $queryParams);

    // Merge the request parameters with the header values
    $mergedParams = array_merge($requestParams, $headers, $queryParams);

    // Sort the merged parameters alphabetically by key
    ksort($mergedParams);

    // Build the string to sign
    $hashString = http_build_query($mergedParams);

    // Debugging: Output the hash string for signature
    echo "<h3>Hash String for Signature:</h3>";
    echo $hashString;
    echo "<br>";

    // Generate the X-Sign signature using HMAC SHA1
    $XSign = hash_hmac('sha1', $hashString, $merchantKey);

    // Add the signature to the headers
    $headers['X-Sign'] = $XSign;

    return $headers;
}

// Helper function to format headers for cURL
function formatHeaders($headers)
{
    $formatted = [];
    foreach ($headers as $key => $value) {
        $formatted[] = "{$key}: {$value}";
    }
    return $formatted;
}

// Example Usage
$baseurl = 'https://staging.slotegrator.com/api/index.php/v1/';
$endpoint = 'jackpots'; // Correct query string format
$merchantId = '76342e9f7d67337211b12d57084d57ef';      // Replace with your Merchant ID
$merchantKey = 'ebf1556b7d53292ef8122dc944f21b6051653d05';    // Replace with your Merchant Key

// Set your desired request type ('GET' or 'POST')
$requestType = 'GET'; // or 'POST'

// If POST request, specify POST data (optional)
$postData = [
    'balance' => '123',
    'session_id' => '32323232'
];

// Call the function and get the response
$response = getLimitFreeSpin($baseurl, $endpoint, $merchantId, $merchantKey, $requestType, $postData);
?>

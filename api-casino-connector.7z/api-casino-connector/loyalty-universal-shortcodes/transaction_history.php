<section class="history-section">
    <h3>Transaction History</h3>
    <table class="transaction-table">
        <thead>
            <tr>
                <th>Date</th>
                <th>Location</th>
                <th>Type</th>
                <th>Status</th>
                <th>Points</th>
                <th>Balance</th>
                <th>Source</th>
            </tr>
        </thead>
        <tbody id="transactionHistoryBody">
            <!-- Data will be inserted here dynamically -->
        </tbody>
    </table>
</section>

</body>
</html>

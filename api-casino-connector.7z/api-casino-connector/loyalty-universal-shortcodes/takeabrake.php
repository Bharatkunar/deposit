<style>
    /* Container styling */
    .WizCoolOff_container__PhU9w {
        background-color: #1d1f26;
        color: #fff;
        padding: 24px;
        border-radius: 10px;
        max-width: 600px;
        margin: auto;
    }

    /* Title */
    .WizCoolOff_container_title__0Yl7C {
        font-size: 22px;
        font-weight: 600;
        margin-bottom: 16px;
    }

    /* Subtitle and Paragraphs */
    .WizCoolOff_container__PhU9w p {
        font-size: 14px;
        line-height: 1.6;
        color: #bbb;
        margin-bottom: 14px;
    }

    .WizCoolOff_container_subTitle__Igh_f {
        font-weight: 500;
        color: #fff;
        margin-top: 12px;
    }

    /* Radio button wrapper */
    .WizToggleBox_base__YKIBS {
        display: flex;
        align-items: center;
        background-color: #12141b;
        border: 1px solid #2e3039;
        border-radius: 8px;
        padding: 10px 14px;
        margin-bottom: 12px;
        transition: border 0.3s;
        cursor: pointer;
    }

    .WizToggleBox_base__YKIBS:hover,
    .WizToggleBox_base__YKIBS input:checked+span {
        border-color: #b4ff00;
    }

    .WizToggleBox_base__YKIBS input {
        display: none;
    }

    /* Custom radio appearance */
    .WizToggleBox_base__YKIBS span {
        width: 16px;
        height: 16px;
        border: 2px solid #888;
        border-radius: 50%;
        margin-right: 12px;
        display: inline-block;
        position: relative;
    }

    .WizToggleBox_base__YKIBS input:checked+span::after {
        content: '';
        position: absolute;
        top: 3px;
        left: 3px;
        width: 6px;
        height: 6px;
        background: #b4ff00;
        border-radius: 50%;
    }

    /* Label styling */
    .WizToggleBox_base__YKIBS label {
        color: #eee;
        font-size: 15px;
        display: flex;
        align-items: center;
    }

    /* View More Button */
    .WizButtonContainer_container__r4v3N button,
    .WizButton_primary-outlined__gu335 {
        background-color: #1d1f26;
        color: #b4ff00;
        border: 1px solid #b4ff00;
        padding: 12px 20px;
        border-radius: 8px;
        font-size: 15px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        width: 100%;
        margin-top: 20px;
    }

    .WizButton_primary-outlined__gu335:hover {
        background-color: #b4ff00;
        color: #12141b;
    }

    .WizButton_text__oCBg0 {
        display: inline-block;
    }

    /* Optional ripple wrapper override (if needed) */
    .WizRipple-wrapper {
        display: none;
    }
</style>
<div class="WizCoolOff_container__PhU9w">
    <h3 class="WizCoolOff_container_title__0Yl7C">Cool Off</h3>
    <p>By clicking “cool off”, you will be unable to place bets or access certain features for a specified duration. This period cannot be reduced, but you can extend it if needed.</p>
    <div class="WizCoolOff_container_list__Jq93S">
        <p class="WizCoolOff_container_subTitle__Igh_f">Set a cool off period on your account at a time you prefer.</p>
        <p>Duration :</p>
        <div class="WizToggleBox_base__YKIBS WizToggleBox_primary-outlined__ayNtP WizToggleBox_XS__YsWr_ undefined WizToggleBox_radio__4OlG4"><label for="28800000" style="cursor: pointer;"><input type="radio" name="coolOff" id="28800000" value="28800000"><span></span>8 hours</label></div>
        <div class="WizToggleBox_base__YKIBS WizToggleBox_primary-outlined__ayNtP WizToggleBox_XS__YsWr_ undefined WizToggleBox_radio__4OlG4"><label for="86400000" style="cursor: pointer;"><input type="radio" name="coolOff" id="86400000" value="86400000"><span></span>1 day</label></div>
        <div class="WizToggleBox_base__YKIBS WizToggleBox_primary-outlined__ayNtP WizToggleBox_XS__YsWr_ undefined WizToggleBox_radio__4OlG4"><label for="259200000" style="cursor: pointer;"><input type="radio" name="coolOff" id="259200000" value="259200000"><span></span>3 days</label></div>
        <div class="WizToggleBox_base__YKIBS WizToggleBox_primary-outlined__ayNtP WizToggleBox_XS__YsWr_ undefined WizToggleBox_radio__4OlG4"><label for="604800000" style="cursor: pointer;"><input type="radio" name="coolOff" id="604800000" value="604800000"><span></span>7 days</label></div>
        <div class="WizToggleBox_base__YKIBS WizToggleBox_primary-outlined__ayNtP WizToggleBox_XS__YsWr_ undefined WizToggleBox_radio__4OlG4"><label for="1209600000" style="cursor: pointer;"><input type="radio" name="coolOff" id="1209600000" value="1209600000"><span></span>14 days</label></div>
        <div class="WizButtonContainer_container__r4v3N WizButtonContainer_start__CwrE5 WizButtonContainer_row__FVI8Q WizButtonContainer_fullWidth__d5Jzj" data-button-container="wrapper"><button class="WizButton_base__ojkNL WizButton_neutral-text__zJyxg WizButton_M__VKPt3" type="button"><span class="WizButton_text__oCBg0">View More</span><span class="WizRipple-wrapper"></span></button></div>
    </div>
    <div><button class="WizButton_base__ojkNL WizButton_primary-outlined__gu335 WizButton_XL__pOA7y" type="button"><span class="WizButton_text__oCBg0">Cool Off</span><span class="WizRipple-wrapper"></span></button></div>
</div>
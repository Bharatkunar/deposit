<style>
    #locations-wrapper.locations-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        justify-content: flex-start;
        margin-top: 20px;
        box-sizing: border-box; /* ensure padding/border is included */
    }

    .boxes-modals {
        flex: 1 1 calc(33.33% - 20px); /* allow growing and shrinking */
        background-color: #fff;
        border: 1px solid #ddd;
        padding: 15px;
        border-radius: 8px;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        box-sizing: border-box; /* include padding/border in width */
        min-width: 0; /* allow flexbox to shrink below previous min-width */
    }


    .modal-box-content {
        text-align: left;
    }

    .modal-box-anchor {
        display: block;
        margin: 5px 0;
        color: #333;
        font-size: 14px;
    }

    .social-icons {
        margin-top: 0 !important;
        padding: 0 !important;
        font-size: 18px;
    }

    .social-icons i {
        margin-right: 8px;
        color: #555;
    }

    dialog {
        border: none;
        border-radius: 6px;
        padding: 20px;
        max-width: 400px;
        position: relative;
        top: 60%;
        left: 40%;
    }

    .modal-content h2 {
        margin-bottom: 10px;
    }

    .modal-button {
        display: flex;
        justify-content: space-between;
        margin-top: 15px;
    }

    .google-map-location {
        margin-left: -20px;
        margin-right: -20px;
        margin-bottom: -20px;
    }

    .google-map-location iframe {
        width: 100%;
        max-height: 400px !important;
    }

    main#main:has(.google-map-location) {
        padding-top: 0px !important
    }

    .location-html-white-box {
        background-color: white;
        max-width: 1200px;
        margin: auto;
        padding: 20px;
        margin-top: 10px;
    }

    .location-html-white-box table {
        border: none
    }

    .location-html-white-box td {
        border: 0px !important
    }

    .location-html-white-box table td:nth-child(1) {
        width: 80%;
        padding: 5px;
        position: relative;
    }

    .location-html-white-box table td:nth-child(2) {
        width: 20%;
        padding: 5px;
    }

    .location-html-white-box table td:nth-child(2) select {
        width: 100%;
        background-color: white;
        height: 34px;
        padding: 6px 12px;
        font-size: 14px;
        color: #555;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .location-html-white-box table td:nth-child(1) input {
        background-color: white;
        height: 34px;
        padding: 6px 12px;
        font-size: 14px;
        color: #555;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .location-html-white-box table td:nth-child(1)::before {
        content: "\f002";
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        font-size: 14px;
        margin-right: 5px;
        position: absolute;
        right: 0px;
        background-color: rgba(238, 96, 89) !important;
        color: white;
        padding: 3px;
        padding-left: 10px;
        padding-right: 10px;
    }

    @media (max-width: 900px) {
        .boxes-modals {
            flex: 1 1 calc(50% - 20px);
        }
    }

    @media (max-width: 600px) {
        .boxes-modals {
            flex: 1 1 100%;
        }
    }

    .location-html-white-box .table-1.transaction-history-table-column {
        padding-bottom: 20px;
        border-bottom: 2px solid #ee6059;
    }

    .location-page-content {
        display: flex;
        margin-top: 20px;
        margin-bottom: 40px;
    }

    .location-page-content .boxes-modals {
        background: #ffffba !important;
        margin: 0 3px !important;
    }

    .location-page-content .boxes-modals button {
        border: 0px !important;
        background-color: transparent;
        text-align: left !important;
    }

    .location-page-content .boxes-modals .modal-box-content {
        display: flex;
        flex-direction: column;
    }

    .location-page-content .boxes-modals {
        display: flex;
        flex-direction: column !important;
        width: 33%;
        padding: 10px 30px;
        height: 290px !important;
        border: 0px !important;
        border-right: 1px solid;
    }

    .location-page-content .boxes-modals .modal-box-anchor {
        color: black;
        font-size: 14px;
        font-weight: 400;
        cursor: pointer;
    }

    .location-page-content .boxes-modals .modal-box-anchor:nth-child(1) {
        color: black;
        font-size: 15px;
        font-weight: 600;
        cursor: pointer;
    }

    .location-page-content dialog#myModal {
        align-self: center;
        justify-self: center;
        border: none;
        border-radius: 5px;
        padding: 40px 15px 40px 15px;

    }

    .location-page-content .modal-content {
        text-align: center;
        box-shadow: none;
        border: none;
        min-width: 350px;

    }

    .location-page-content .modal-content span {
        border-color: #facea8;
        color: #f8bb86;
        border-radius: 100%;
        border: 2px solid;
        width: max-content;
        height: max-content;
        padding: 0px 25px;
        font-weight: 600;
        align-self: center;
        font-size: 1.85em;
    }

    .location-page-content .modal-content h2 {
        color: #595959;
        font-size: 1.8rem !important;
        margin-bottom: 20px;
        margin-top: 20px;
        text-transform: uppercase !important
    }

    .location-page-content .modal-content p {
        color: #74788d !important;
        font-weight: 500 !important;
        font-size: 0.925em !important;
    }

    .location-page-content .modal-content .modal-button button:nth-child(1) {
        background-color: rgb(253, 57, 122);
        color: white !important;
        border: none;
        padding: 6px 25px;
        border-radius: 5px;
        margin-right: 15px;
    }

    .location-page-content .modal-content .modal-button button:nth-child(2) {
        background-color: rgb(29, 201, 183);
        color: white !important;
        border: none;
        padding: 6px 25px;
        border-radius: 5px;
    }

    .social-icons {
        padding-top: 20px;
    }

    .social-icons i.fa-facebook-f {
        font-size: 20px;
        background-color: #1877F2 !important;
        color: white !important;
        padding: 3px;
        border-radius: 5px;
    }

    .social-icons .fa-twitter {
        font-size: 20px;
        background-color: #000000 !important;
        color: white !important;
        padding: 3px;
        border-radius: 5px;
    }

    .social-icons .fa-linkedin-in {
        font-size: 20px;
        background-color: #0077B5 !important;
        color: white !important;
        padding: 3px;
        border-radius: 5px;
    }

    .social-icons .fa-youtube {
        font-size: 20px;
        background-color: #FF0000 !important;
        color: white !important;
        padding: 3px;
        border-radius: 5px;
    }

    .social-icons .fa-instagram {
        font-size: 20px;
        background: linear-gradient(45deg, #f9ce34, #ee2a7b, #6228d7);
        color: white !important;
        padding: 3px;
        border-radius: 5px;
    }

    .boxes-modals {
        opacity: 0;
        animation: fadeIn 0.3s ease forwards;
    }

    .boxes-modals .modal-box-content {
        background: #ffffba !important;
    }

    @keyframes fadeIn {
        to {
            opacity: 1;
        }
    }

    .boxes-modals .modal-box-content {
        height: 280px !important;
        padding: 0px !important;
    }

    .modal-box-anchor a {
        color: blue;
    }

    .load-button {
        text-align: center;
    }

    .load-button button {
        border: none;
        background: #EE6059;
        color: #fff;
        padding: 5px 10px;
        border-radius: 5px;
    }

    /* Spinner styles */
    #location_data.location-spinner {
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 30px 0;
    }
    #global-location-spinner {
        min-height: 50px;
        width: auto;
    }
    /* Simple spinner animation */
    #global-location-spinner::after {
        content: "";
        display: inline-block;
        width: 30px;
        height: 30px;
        border: 4px solid #EE6059;
        border-top-color: transparent;
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
</style>
<div class="location-page-html-new sidebar-hide-issue">
    <div class="heading-block-all">
        <div class="heading-block-text">
            <p class="paragraph-text">Location</p>
        </div>
    </div>
    <div class="location-html-white-box">
        <div class="table-1 transaction-history-table-column">
            <table width="100%">
                <thead>
                    <tr>
                        <td><input id="locationSearch" class="searchicon" type="text" placeholder="Enter City or Postal Code or Address">
                        </td>
                    </tr>
                </thead>
            </table>
        </div>
        <div class="location-page-content">
            <div id="locations-wrapper" class="locations-grid"></div>
        </div>
        <div id="location_data" class="location-spinner" style="display:none;">
            <div id="global-location-spinner"></div>
        </div>
        <div class="load-button">
            <button id="loadMoreBtn">Load More</button>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function ($) {
    // Show spinner on start
    $('#location_data').show();
    $('#leaderboardTable').hide();

    // Fetch locations
    $.ajax({
        url: ajax_object.ajax_url,
        method: 'GET',
        data: {
            action: "getLocation" // must match PHP action
        },
        dataType: 'json',
        success: function (location) {
            renderLocationHTML(location);
            setupLocationSearch(location);
            // Hide spinner after location data is loaded
            $('#location_data').hide();
            $('#leaderboardTable').show();
        },
        error: function (error) {
            console.error('Error fetching location:', error);
            $('#location_data').hide();
            $('#leaderboardTable').show();
        }
    });

});

function populateSurveysTable(data) {
    const availableContainer = $('#available-surveys-container');
    const completedContainer = $('#completed-surveys-container');

    availableContainer.empty();
    completedContainer.empty();

    // Available Surveys
    if (!data.available || data.available.length === 0) {
        availableContainer.append('<div class="text-center">No Available Surveys</div>');
    } else {
        data.available.forEach(survey => {
            const html = `
                <div class="survey-flex-box">
                    <div class="survey-title-font">
                        <ul><li>${survey.surveyTitle}</li></ul>
                    </div>
                    <div class="survey-title-font">
                        <div class="survey-format-flex">
                            <div>${survey.surveySendDataString}</div>
                            <div><a class="take-survey" href="${survey.buttonSurveyLink}" target="_blank">Take survey</a></div>
                        </div>
                    </div>
                </div>`;
            availableContainer.append(html);
        });
    }

    // Completed Surveys
    if (!data.completed || data.completed.length === 0) {
        completedContainer.append('<div class="text-center">No Completed Surveys</div>');
    } else {
        data.completed.forEach(survey => {
            const html = `
                <div class="survey-flex-box">
                    <div class="survey-title-font">
                        <ul><li>${survey.surveyTitle}</li></ul>
                    </div>
                    <div class="survey-title-font">
                        <div class="survey-format-flex">
                            <div>${survey.surveySendDataString}</div>
                            <div>${survey.respondDateString}</div>
                            <div>${survey.surveyPoints ?? '0'}</div>
                        </div>
                    </div>
                </div>`;
            completedContainer.append(html);
        });
    }
}

function renderLocationHTML(locations) {
    const container = $('#locations-wrapper');
    container.empty();

    const itemsPerPage = 3;
    let currentCount = 0;

    // Clear any previous event handlers for the Load More button
    $('#loadMoreBtn').off('click');

    function renderBatch() {
        // Show spinner while loading batch
        $('#location_data').show();

        // Simulate a slight delay to show spinner realistically (optional)
        setTimeout(() => {
            const slice = locations.slice(currentCount, currentCount + itemsPerPage);

            slice.forEach((location, index) => {
                const modalId = `modal-${currentCount + index}`;
                const boxId = `box-${currentCount + index}`;

                const modalHTML = `
                    <div class="boxes-modals" id="${boxId}">
                        <div class="modal-box-content">
                            <div class="modal-box-anchor"><strong>${location.locationName || 'No Name'}</strong></div>
                            <button class="open-modal-btn" onclick="document.getElementById('${modalId}').showModal();">
                                <div class="modal-box-anchor">${location.address || ''}</div>
                            </button>
                            <div class="modal-box-anchor">${location.city || ''}, ${location.zipCode || ''}</div>
                            <div class="modal-box-anchor">
                                <a href="${location.websiteURL || '#'}" target="_blank">
                                    ${location.websiteURL || 'Visit Website'}
                                </a>
                            </div>
                            <div class="social-icons">
                                ${location.facebookMailID ? '<i class="fab fa-facebook-f"></i>' : '<i class="fab fa-facebook-f"></i>'}
                                ${location.twitterMailID ? '<i class="fab fa-twitter"></i>' : '<i class="fab fa-twitter"></i>'}
                                ${location.linkedin ? '<i class="fab fa-linkedin-in"></i>' : '<i class="fab fa-linkedin-in"></i>'}
                                ${location.youtube ? '<i class="fab fa-youtube"></i>' : '<i class="fab fa-youtube"></i>'}
                                ${location.instagramMailId ? '<i class="fab fa-instagram"></i>' : '<i class="fab fa-instagram"></i>'}
                            </div>
                        </div>
                        <dialog id="${modalId}">
                            <div class="modal-content">
                                <h2>${location.locationName || 'Need Directions?'}</h2>
                                <p>${location.address || ''}, ${location.city || ''}, ${location.state || ''}, ${location.zipCode || ''}</p>
                                <div class="modal-button">
                                    <button onclick="document.getElementById('${modalId}').close();">Cancel</button>
                                    <button onclick="window.open('https://www.google.com/maps?q=${location.latitude},${location.longitude}', '_blank')">Yes</button>
                                </div>
                            </div>
                        </dialog>
                    </div>
                `;

                container.append(modalHTML);
            });

            currentCount += itemsPerPage;

            if (currentCount >= locations.length) {
                $('#loadMoreBtn').hide();
            } else {
                $('#loadMoreBtn').show();
            }

            // Hide spinner after batch loaded
            $('#location_data').hide();
        }, 200); // 200ms delay for spinner to appear nicely
    }

    $('#loadMoreBtn').on('click', renderBatch);

    // Initial batch render
    renderBatch();
}

// Global variable to hold all locations for search filtering
let originalLocations = [];

function setupLocationSearch(locations) {
    originalLocations = locations;

    $('#locationSearch').on('input', function () {
        const query = $(this).val().toLowerCase().trim();

        if (query === '') {
            renderLocationHTML(originalLocations);
            $('#loadMoreBtn').show();
            return;
        }

        const filtered = originalLocations.filter(loc => {
            return (
                (loc.city && loc.city.toLowerCase().includes(query)) ||
                (loc.zipCode && loc.zipCode.toString().includes(query)) ||
                (loc.address && loc.address.toLowerCase().includes(query))
            );
        });

        renderLocationHTML(filtered);

        if (filtered.length <= 3) {
            $('#loadMoreBtn').hide();
        } else {
            $('#loadMoreBtn').show();
        }
    });
}
</script>

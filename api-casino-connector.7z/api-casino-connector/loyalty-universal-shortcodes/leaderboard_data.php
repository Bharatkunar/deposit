<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leaderboard Data</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</head>

<body>

    <div class="leaderboard-section">
        <div class="filter-container d-flex justify-content-between align-items-center gap-3">
            <!-- Left Side: Year and Month Filters -->
            <div class="filter-left d-flex gap-2">
                <select id="yearFilter" class="form-select">
                    <option value="">Select Year</option>
                </select>
                <select id="monthFilter" class="form-select" style="display: none;">
                    <option value="">Select Month</option>
                </select>
            </div>

            <!-- Right Side: Additional Filters -->
            <div class="filter-right d-flex gap-3">
                <div id="divPotentialWinner">
                    <label class="col-form-label">Potential Winners: </label>
                    <input type="number" class="form-control" id="potentialWinners" style="width: 120px;">
                </div>
                <div id="divSearch">
                    <label class="col-form-label">Players Name: </label>
                    <input type="search" class="form-control" placeholder="Search" id="gridLeaderBoardSearch" style="width: 200px;">
                </div>
            </div>
        </div>

        <!-- Spinner (Shows while loading data) -->
        <div class="main-spinner" style="position: relative;">
            <div class="spinner-container" id="spinner">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
        </div>

        <!-- Table -->
        <table class="transaction-table table" id="leaderboardTable">
            <thead>
                <tr>
                    <th>Rank</th>
                    <th>Player</th>
                    <th>Score</th>
                    <th>Check-Ins</th>
                    <th>Transactions</th>
                    <th>Referals</th>
                </tr>
            </thead>
            <tbody id="leaderboard">
                <!-- Data will be inserted dynamically -->
            </tbody>
        </table>
        </>

        <script>

        </script>

</body>

</html>
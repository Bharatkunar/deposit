<style>
    .referal-another-page-html .clicker-referral {
        background-color: white;
        max-width: 1200px;
        margin: auto;
        padding: 20px;
        margin-top: 10px;
    }

    .referal-another-page-html .clicker-referral-flex {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
    }

    @media(max-width:767px) {
        .referal-another-page-html .clicker-referral-flex {
            display: grid;
            grid-template-columns: repeat(1, 1fr);
        }
    }

    .referal-another-page-html .click-container {
        background-color: #3b5998;
        color: white;
        border-radius: 5px;
        text-align: center;
        padding: 30px;
        margin: 10px;
        margin-bottom: 20px;
    }

    .referal-another-page-html .join-container {
        background-color: #dc4a38;
        color: white;
        border-radius: 5px;
        text-align: center;
        padding: 30px;
        margin: 10px;
        margin-bottom: 20px;
    }

    .referal-another-page-html .point-earn-container {
        background-color: #3f93bf;
        color: white;
        border-radius: 5px;
        text-align: center;
        padding: 30px;
        margin: 10px;
        margin-bottom: 20px;
    }

    .referal-another-page-html .clicker-referral-flex p {
        margin-bottom: 0px;
        font-size: 18px;
        font-weight: 500;
    }

    .transaction-history-white-block-html {
        background-color: white;
        max-width: 1200px;
        margin: auto;
        padding: 20px;
        margin-top: 10px;
    }

    .transaction-flex-block {
        display: flex !important;
        justify-content: space-between;
        margin-bottom: 20px;
    }

    .transaction-history-white-block-html .history-left-bar-content span.text-format {
        font-size: 14px !important;
        padding-left: 10px;
        color: #666;
        padding-right: 10px;
    }

    .transaction-history-white-block-html .history-left-bar-content .showing-filter select {
        height: 30px !important;
        background-color: #f8f8f8 !important;
        color: #666;
        border: 1px solid #ccc;
        border-radius: 5px;
        width: 100px;
    }


    .transaction-history-white-block-html .history-right-bar-content {
        display: flex;
    }

    .transaction-history-white-block-html .history-right-bar-content input {
        background-color: #f8f8f8 !important;
        border: 1px solid #d2d2d2;
        color: #747474;
        font-size: 13px;
        border-radius: 5px;
        padding: 8px 15px !important;
        height: 30px;
        box-sizing: border-box;
        margin: 0;
        outline: 0;
    }

    .transaction-history-white-block-html .transaction-flex-block .history-right-bar-content:before {
        content: "Search";
        font-size: 14px !important;
        color: #666;
        padding-right: 6px;
        padding-left: 10px;
    }

    .transaction-history-white-block-html .transaction-history-table-column span.icon-sorting {
        display: flex;
        justify-content: right;
        margin-top: -30px;
    }

    .transaction-history-white-block-html .transaction-history-table-column span.icon-sorting span {
        position: relative;
    }

    .transaction-history-white-block-html .transaction-history-table-column span.icon-sorting span.exchange-icon {
        color: white;
    }

    .transaction-history-white-block-html .transaction-history-table-column span.icon-sorting span.exchange-icon:before {
        color: rgb(102, 102, 102);
        content: "\f0ec";
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        font-size: 14px;
        right: 0px;
        position: absolute;
        transform: rotate(90deg);
    }

    .transaction-history-white-block-html .transaction-history-table-column span.icon-sorting span.down-sort-icon {
        color: white;
    }

    .transaction-history-white-block-html .transaction-history-table-column span.icon-sorting span.down-sort-icon:before {
        color: rgb(102, 102, 102);
        content: "\f161";
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        font-size: 14px;
        right: 0px;
        position: absolute;
        transform: rotate(180deg) scaleX(-1);
    }

    .transaction-history-white-block-html .transaction-history-table-column span.icon-sorting span.up-sort-icon {
        color: white;
    }

    .transaction-history-white-block-html .transaction-history-table-column span.icon-sorting span.up-sort-icon:before {
        color: rgb(102, 102, 102);
        content: "\f161";
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        font-size: 14px;
        right: 0px;
        position: absolute;
        transform: rotate(0deg);
    }

    .transaction-history-white-block-html .transaction-history-table-column tr td {
        border-color: white !important;
        border-bottom: 1px solid lightgrey !important;
        padding: 5px !important;
        padding-left: 8px !important;
        padding-right: 8px !important;
    }

    .transaction-history-white-block-html .transaction-history-table-column span.icon-sorting .exchange-icon {
        display: none
    }

    .transaction-history-white-block-html .transaction-history-table-column span.icon-sorting .down-sort-icon {
        display: none;
    }

    .transaction-history-white-block-html .transaction-history-table-column span.icon-sorting .up-sort-icon {
        display: none
    }

    .transaction-history-white-block-html .transaction-history-table-column span.icon-sorting .exchange-icon.active {
        display: block
    }

    .transaction-history-white-block-html .transaction-history-table-column span.icon-sorting .down-sort-icon.active {
        display: block;
    }

    .transaction-history-white-block-html .transaction-history-table-column span.icon-sorting .up-sort-icon.active {
        display: block
    }

    .transaction-history-white-block-html .transaction-history-table-column span.icon-sorting {
        height: 30px;
    }



    .transaction-history-white-block-html .transaction-history-table-column td.status-content {
        color: #337ab7 !important;
    }

    .transaction-history-white-block-html .transaction-history-table-column td.points-content {
        color: green !important;
    }

    .transaction-history-white-block-html .transaction-history-table-column td.plus-content {
        font-size: 20px !important;
        font-weight: 700;
        height: 14px !important;
        padding: 0px !important;
        cursor: pointer !important
    }

    @media (max-width: 767px) {
        .transaction-history-white-block-html .transaction-history-table-column .table-content {
            padding-right: 20px;
        }
    }

    @media(max-width:600px) {
        .transaction-flex-block {
            display: flex;
            flex-direction: column-reverse;
            gap: 20px;
        }
    }

    .transaction-history-white-pagination-block .pagination-flex-table {
        display: flex;
        flex-direction: row !important;
        justify-content: space-between;
    }

    .transaction-history-white-pagination-block .pagination-flex-table .showing-filter-padination input {
        color: rgba(238, 96, 89) !important;
        width: max-content !important;
        padding-left: 10px;
        padding-right: 10px;
        border-radius: 0px !important;
        font-size: 15px !important;
        padding-top: 0px !important;
        background-color: #f8f8f8 !important;
    }

    .transaction-history-white-pagination-block .pagination-flex-table .showing-filter-padination input.page-numbers {
        background-color: rgba(238, 96, 89) !important;
        color: white !important;
        width: max-content !important;
        padding-left: 10px !important;
        padding-right: 10px !important;
    }

    .transaction-history-white-pagination-block {
        margin-top: 10px;
        margin-bottom: 40px;
    }

    tr.transactions-details-all table {
        background-color: transparent;
        box-shadow: none !important;
        border: none !important;

    }

    tr.transactions-details-all table tr td:nth-child(1) {
        padding: 0px !important;
        padding-right: 15px !important;
        border-color: transparent !important;
    }

    tr.transactions-details-all table tr td:nth-child(2) {
        padding: 0px !important;
        padding-left: 78px !important;
        border-color: transparent !important;
    }

    .transaction-history-white-block-html tr.transactions-details-all {
        display: none
    }

    .transaction-history-white-block-html tr.transactions-details-all.showing-detail {
        display: table-row !important;
    }

    .transactions .show-content,
    .transactions .hide-content {
        display: none
    }

    .transactions .show-content.showing-details {
        display: block !important;
    }

    .transactions .hide-content.showing-details {
        display: block !important;
    }

    .invites-container-new {
        display: none
    }

    .joined-container-new {
        display: none
    }

    .purchases-container-new {
        display: none
    }

    .invites-container-new.activate-container {
        display: block !important;
    }

    .joined-container-new.activate-container {
        display: block !important;
    }

    .purchases-container-new.activate-container {
        display: block !important;
    }
</style>
<div class="referal-another-page-html sidebar-hide-issue">
    <div class="heading-block-all">
        <div class="heading-block-text">
            <p class="paragraph-text">Referral Stats</p>
        </div>
    </div>
    <div class="clicker-referral">
        <div class="clicker-referral-flex">
            <div class="click-container">
                <div class="inner-container-text">
                    <p><?php echo $total_clicked; ?></p>
                    <p>Total Clicks</p>
                </div>
            </div>
            <div class="join-container">
                <div class="inner-container-text">
                    <p><?php echo $total_joins; ?></p>
                    <p>Total Joins</p>
                </div>
            </div>
            <div class="point-earn-container">
                <div class="inner-container-text">
                    <p><?php echo $referal_earned; ?></p>
                    <p>Referral Points Earned</p>
                </div>
            </div>
        </div>
    </div>
    <div class="invites-container-new">
        <div class="heading-block-all">
            <div class="heading-block-text">
                <p class="paragraph-text">Invites Clicked</p>
            </div>
        </div>
        <div class="transaction-history-white-block-html">
            <div class="transaction-flex-block">
                <div class="history-left-bar-content">
                    <div class="showing-filter">
                        <span class="text-format">Show</span><select>
                            <option>10</option>
                            <option>25</option>
                            <option>50</option>
                            <option>100</option>
                        </select><span class="text-format">entries</span>
                    </div>
                </div>
                <div class="history-right-bar-content">
                    <input type="search" class="fusion-search-submit searchsubmit">
                </div>
            </div>
            <div class="table-1 transaction-history-table-column">
                <table width="100%">
                    <thead>
                        <tr class="heading-transaction-history">
                            <td class="date-icon"><span class="table-content">Date</span><br>
                                <span class="icon-sorting"><br>
                                    <span class="exchange-icon">e</span><br>
                                    <span class="down-sort-icon active">d</span><br>
                                    <span class="up-sort-icon">u</span><br>
                                </span>
                            </td>
                            <td class="type-icon"><span class="table-content">From Network</span><br>
                                <span class="icon-sorting"><br>
                                    <span class="exchange-icon active">e</span><br>
                                    <span class="down-sort-icon">d</span><br>
                                    <span class="up-sort-icon">u</span><br>
                                </span>
                            </td>
                            <td class="status-icon"><span class="table-content">Name</span><br>
                                <span class="icon-sorting"><br>
                                    <span class="exchange-icon active">e</span><br>
                                    <span class="down-sort-icon">d</span><br>
                                    <span class="up-sort-icon">u</span><br>
                                </span>
                            </td>
                            <td class="points-icon"><span class="table-content">Email</span><br>
                                <span class="icon-sorting"><br>
                                    <span class="exchange-icon active">e</span><br>
                                    <span class="down-sort-icon">d</span><br>
                                    <span class="up-sort-icon">u</span><br>
                                </span>
                            </td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="no-content-td" colspan="4">No data available in table</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="transaction-history-white-pagination-block">
                <div class="pagination-flex-table">
                    <div class="history-left-bar-content">
                        <div class="showing-filter"><span class="text-format">No Records Found</span></div>
                    </div>
                    <div class="history-right-bar-content">
                        <div class="showing-filter-padination"><input type="button" value="Previous"><input type="button" value="Next"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="joined-container-new">
        <div class="heading-block-all">
            <div class="heading-block-text">
                <p class="paragraph-text">Invites Joined</p>
            </div>
        </div>
        <div class="transaction-history-white-block-html">
            <div class="transaction-flex-block">
                <div class="history-left-bar-content">
                    <div class="showing-filter">
                        <span class="text-format">Show</span><select>
                            <option>10</option>
                            <option>25</option>
                            <option>50</option>
                            <option>100</option>
                        </select><span class="text-format">entries</span>
                    </div>
                </div>
                <div class="history-right-bar-content">
                    <input type="search" class="fusion-search-submit searchsubmit">
                </div>
            </div>
            <div class="table-1 transaction-history-table-column">
                <table width="100%">
                    <thead>
                        <tr class="heading-transaction-history">
                            <td class="date-icon"><span class="table-content">Date</span><br>
                                <span class="icon-sorting"><br>
                                    <span class="exchange-icon">e</span><br>
                                    <span class="down-sort-icon active">d</span><br>
                                    <span class="up-sort-icon">u</span><br>
                                </span>
                            </td>
                            <td class="type-icon"><span class="table-content">From Network</span><br>
                                <span class="icon-sorting"><br>
                                    <span class="exchange-icon active">e</span><br>
                                    <span class="down-sort-icon">d</span><br>
                                    <span class="up-sort-icon">u</span><br>
                                </span>
                            </td>
                            <td class="status-icon"><span class="table-content">Name</span><br>
                                <span class="icon-sorting"><br>
                                    <span class="exchange-icon active">e</span><br>
                                    <span class="down-sort-icon">d</span><br>
                                    <span class="up-sort-icon">u</span><br>
                                </span>
                            </td>
                            <td class="points-icon"><span class="table-content">Email</span><br>
                                <span class="icon-sorting"><br>
                                    <span class="exchange-icon active">e</span><br>
                                    <span class="down-sort-icon">d</span><br>
                                    <span class="up-sort-icon">u</span><br>
                                </span>
                            </td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="no-content-td" colspan="4">No data available in table</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="transaction-history-white-pagination-block">
                <div class="pagination-flex-table">
                    <div class="history-left-bar-content">
                        <div class="showing-filter"><span class="text-format">No Records Found</span></div>
                    </div>
                    <div class="history-right-bar-content">
                        <div class="showing-filter-padination"><input type="button" value="Previous"><input type="button" value="Next"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="purchases-container-new">
        <div class="heading-block-all">
            <div class="heading-block-text">
                <p class="paragraph-text">Purchases</p>
            </div>
        </div>
        <div class="transaction-history-white-block-html">
            <div class="transaction-flex-block">
                <div class="history-left-bar-content">
                    <div class="showing-filter">
                        <span class="text-format">Show</span><select>
                            <option>10</option>
                            <option>25</option>
                            <option>50</option>
                            <option>100</option>
                        </select><span class="text-format">entries</span>
                    </div>
                </div>
                <div class="history-right-bar-content">
                    <input type="search" class="fusion-search-submit searchsubmit">
                </div>
            </div>
            <div class="table-1 transaction-history-table-column">
                <table width="100%">
                    <thead>
                        <tr class="heading-transaction-history">
                            <td class="date-icon"><span class="table-content">Date</span><br>
                                <span class="icon-sorting"><br>
                                    <span class="exchange-icon">e</span><br>
                                    <span class="down-sort-icon active">d</span><br>
                                    <span class="up-sort-icon">u</span><br>
                                </span>
                            </td>
                            <td class="type-icon"><span class="table-content">From Network</span><br>
                                <span class="icon-sorting"><br>
                                    <span class="exchange-icon active">e</span><br>
                                    <span class="down-sort-icon">d</span><br>
                                    <span class="up-sort-icon">u</span><br>
                                </span>
                            </td>
                            <td class="status-icon"><span class="table-content">Name</span><br>
                                <span class="icon-sorting"><br>
                                    <span class="exchange-icon active">e</span><br>
                                    <span class="down-sort-icon">d</span><br>
                                    <span class="up-sort-icon">u</span><br>
                                </span>
                            </td>
                            <td class="points-icon"><span class="table-content">Email</span><br>
                                <span class="icon-sorting"><br>
                                    <span class="exchange-icon active">e</span><br>
                                    <span class="down-sort-icon">d</span><br>
                                    <span class="up-sort-icon">u</span><br>
                                </span>
                            </td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="no-content-td" colspan="4">No data available in table</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="transaction-history-white-pagination-block">
                <div class="pagination-flex-table">
                    <div class="history-left-bar-content">
                        <div class="showing-filter"><span class="text-format">No Records Found</span></div>
                    </div>
                    <div class="history-right-bar-content">
                        <div class="showing-filter-padination"><input type="button" value="Previous"><input type="button" value="Next"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style>
    .transfer-white-block {
        max-width: 1200px !important;
        padding-right: 20px;
        padding-left: 20px;
        margin: auto;
        background-color: white;
        margin-top: 20px;
        padding-bottom: 60px;
    }

    .transfer-how-many {
        padding-top: 20px;
        font-size: 30px;
        color: rgb(102, 102, 102);
        text-align: center;
    }

    .transfer-how-many p {
        margin-bottom: 56px;
    }

    .transfer-content h4.formatting_heading {
        font-size: 20px !important;
        color: #000 !important;
        font-weight: 600 !important;
    }

    .transfer-content {
        display: flex;
        flex-direction: row
    }

    .transfer-content .transfer-content-left-pts {
        width: 50%;
        padding-left: 20px;
        padding-right: 20px;
        border-right: solid 2px #eee;
    }

    .transfer-content .transfer-content-right-pts {
        width: 50%;
        padding-left: 20px;
        padding-right: 20px;
    }

    .transfer-content .code_inline {
        display: flex;
        gap: 10px;
        margin-bottom: 20px;
        background-color: #ee605929;
        padding: 20px 50px;
        border: solid 2px #ee605929;
        border-radius: 8px;
        justify-content: center;
        color: rgba(238, 96, 89) !important;
        padding-top: 40px !important;
    }

    .transfer-content .counter_inline {
        margin-top: -20px;
    }

    .transfer-content .counter_inline span {
        margin-right: 3px;
        padding: 10px;
        padding-left: 12px;
        padding-right: 12px;
        color: rgba(238, 96, 89) !important;
        background: linear-gradient(to bottom, rgb(255, 255, 255) 0%, rgba(246, 246, 246, 1) 47%, rgb(212, 212, 212) 100%);
        border-bottom: 2px solid rgba(238, 96, 89);
        border-radius: 5px;
        font-size: 45px;
        font-family: 'Yantramanav', sans-serif !important;
    }

    .transfer-content-right-pts .email-field input {
        border-color: rgba(238, 96, 89) !important;
        background-color: transparent !important;
        border-radius: 5px !important;
        padding-left: 45px !important;
        height: 50px !important;
    }

    .transfer-content-right-pts .transfer-field input {
        border-color: rgba(238, 96, 89) !important;
        background-color: transparent !important;
        border-radius: 5px !important;
        padding-left: 45px !important;
        height: 50px !important;
    }

    .input-fields {
        display: flex;
        flex-direction: column;
        gap: 30px;
    }

    .input-fields .email-field:before {
        content: "\f007";
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        font-size: 14px;
        margin-right: 5px;
        color: #ee6059 !important;
        position: absolute;
        background: #ee605929;
        height: 50px;
        width: 40px;
        align-content: center;
        text-align: center;
        left: 0;
    }

    .input-fields .transfer-field:before {
        content: "\f0ec";
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        font-size: 14px;
        margin-right: 5px;
        color: #ee6059 !important;
        position: absolute;
        background: #ee605929;
        height: 50px;
        width: 40px;
        align-content: center;
        text-align: center;
        left: 0;
    }

    .submit-button {
        justify-self: center;
        padding-top: 40px;
    }

    a.submit-button-anchor {
        padding: 10px 25px;
        background-color: #ee6059;
        border-radius: 5px;
    }

    a.submit-button-anchor:hover {
        text-decoration: none !important;
        color: white;
    }

    .email-field {
        color: #000;
        font-size: 16px;
        font-weight: 400 !important;
    }

    .transfer-field {
        color: #000;
    }

    @media(max-width:767px) {
        .transfer-content {
            display: flex;
            flex-direction: column !important
        }

        .transfer-content .transfer-content-left-pts {
            width: 100% !important;
            border-right: 0px !important;
        }

        .transfer-content .transfer-content-right-pts {
            width: 100% !important;
        }
    }

    @media(max-width:500px) {
        .transfer-content .code_inline {
            padding-left: 0px !important;
            padding-right: 0px !important
        }

        .transfer-content .counter_inline span {
            font-size: 20px !important;
        }

        .transfer-content .code_inline {
            font-size: 10px;

        }
    }

    @media(max-width:350px) {
        .transfer-content .counter_inline span {
            padding: 5px !important
        }
    }
</style>
<section class="profile">
    <div class="heading-block-all">
        <div class="heading-block-text">
            <p class="paragraph-text">Transfer Points</p>
        </div>
    </div>
    <div class="transfer-white-block">
        <div class="transfer-head-block">
            <div class="transfer-how-many">
                <p>How many points would you like to transfer?</p>
            </div>
        </div>
        <div class="transfer-content">
            <div class="transfer-content-left-pts">
                <h4 class="formatting_heading">
                    Point Balance
                </h4>
                <div class="code_inline">
                    <div class="counter_inline">
                        <span><?php echo $pointBalance; ?></span>
                    </div>PTS
                </div>
            </div>
            <div class="transfer-content-right-pts">
                <h4 class="formatting_heading">
                    Move My Points to   
                </h4>
                <form method="POST" class='transferPointForm'>
                    <input type="hidden" name="action" value="loyalty_transferpoints">
                    <input type="hidden" name="contactID" value="<?php echo get_option('contactId'); ?>">
                    <input type="hidden" name="rewardProgramID" value="<?php echo get_option('rpId'); ?>">
                    <input type="hidden" name="webFormId" value="<?php echo get_option('webFormId'); ?>">
                    <div class="input-fields">
                        <div class="email-field">
                            <input type="text" name="txtcontact" placeholder="<?php echo $txtIdPlaceholder; ?>">
                        </div>
                        <div class="transfer-field">
                            <input type="text" name="txtamount" placeholder="<?php echo $txtAmountPlaceholder; ?>">
                        </div>
                    </div>
                    
                    <button class="submit-button-anchor transferpoint" style="margin-top: 10px; background:rgb(255, 0, 0); padding: 10px 30px 10px 15px; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px;" type="submit">
                        <span class="btn-text"><?php echo $btnSubmitText; ?></span>
                        <span class="btn-spinner" style="display: none; margin-left: 10px;">
                            <i class="fas fa-spinner fa-spin"></i>
                        </span>
                    </button>
                </form>
            </div>
        </div>
    </div>
</section>

<script>
    $(document).ready(function () {
        const $form = $('.transferPointForm');
        const $spinner = $('#spinner');
        const $button = $form.find('.transferpoint');
        const $buttonText = $button.find('.btn-text');
        const $buttonSpinner = $button.find('.btn-spinner');

        $form.on("submit", function (event) {
            event.preventDefault(); // Stop form from submitting normally
            const formData = $form.serialize();

            $.ajax({
                url: ajax_object.ajax_url, // WordPress localized AJAX URL
                method: "POST",
                dataType: "json",
                data: formData,
                beforeSend: function () {
                    $spinner.show();
                    $button.attr("disabled", true);
                    $buttonSpinner.show();
                },
                success: function (response) {
                    if (response.success && response.data.statusCode === 1) {
                        openModal(response.data.message, true);
                    } else {
                        openModal("Error: " + response.data.message, false);
                    }
                },
                error: function (xhr, status, error) {
                    openModal("AJAX error: " + error, false);
                },
                complete: function () {
                    $spinner.hide();
                    $button.attr("disabled", false);
                    $buttonSpinner.hide();
                }
            });
        });
    });

    // Dummy modal handler if not provided
    function openModal(message, success = false) {
        alert((success ? "✅ " : "❌ ") + message);
    }
</script>
<style>
    /* Spinner loader for redeem button */
    .redeem-button-spinner {
        display: inline-block;
        width: 18px;
        height: 18px;
        border: 2px solid rgba(238, 96, 89, 0.3);
        border-top: 2px solid rgba(238, 96, 89, 1);
        border-radius: 50%;
        animation: spin 0.6s linear infinite;
        vertical-align: middle;
        margin-left: 8px; /* space between button text and spinner */
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

    /* Optional: Page-level loader (if needed) */
    .page-spinner-overlay {
        position: fixed;
        top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(255, 255, 255, 0.8);
        z-index: 9999;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .page-spinner-overlay .spinner {
        width: 40px;
        height: 40px;
        border: 4px solid rgba(238, 96, 89, 0.3);
        border-top: 4px solid rgba(238, 96, 89, 1);
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
    }

    .egift-offer-html .heading-bar-html {
        padding: 0px !important;
        background-color: #ee605929 !important;
    }

    .egift-offer-html .heading-bar-html .survey-head-flex {
        padding: 12px !important;
        max-width: max-content;
        background: transparent !important;
        padding-left: 0px !important;
        padding-right: 0px !important;
        border-bottom: 2px solid rgba(238, 96, 89);
        font-size: 14px !important;
        text-transform: capitalize;
        text-decoration: unset;
        cursor: pointer !important;
    }

    .egift-offer-html {
        width: 100%;
    }

    @media(max-width:767px) {
        .egift-offer-html .survey-head-width {
            padding-left: 20px !important;
            padding-right: 20px !important;
        }

        .egift-offer-html .survey-head-width .survey-head-flex {
            justify-self: center;
        }
    }

    .egift-content-block {
        max-width: 1200px;
        margin: auto !important;
        margin-top: 10px !important;
    }

    .egift-content-block .egift-content-block-flex-box {
        display: flex;
    }

    .egift-content-block .egift-content-block-flex-box-left {
        background-color: white;
        padding: 10px 15px 25px 15px;
        width: 24%;
        margin-right: 1%;
        border-radius: 5px;
    }

    .egift-content-block .egift-content-block-flex-box-right {
        width: 74%;
        margin-left: 1%;
        background-color: white;
        padding-top: 10px;
        padding-bottom: 25px;
        border-radius: 5px;
    }

    .egift-content-block .wallet-balance {
        color: black;
        font-weight: 600;
    }

    .egift-content-block .wallet-icon {
        display: flex;
        gap: 5px;
        font-weight: 400 !important;
        font-size: 18px;
        color: black;
        font-family: Poppins, Helvetica, sans-serif;
        align-items: center;
    }

    .egift-content-block .wallet-balance:before {
        content: "\f555";
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        color: rgba(238, 96, 89);
        margin-right: 5px;
    }

    .egift-content-block .wallet-icon p {
        font-size: 16px !important;
        margin-bottom: 0px !important;

    }

    .egift-content-block .sidebar-labels {
        padding: 5px 10px;
        border-bottom: 1px solid #ddd;
    }

    .egift-content-block .checkboxes {
        padding: 5px 10px;
        border-bottom: 1px solid #ddd;
    }

    .egift-content-block .no-border {
        border-bottom: none !important;
        margin-bottom: 20px;
    }

    .egift-content-block .checkboxes p {
        margin-bottom: 5px;
        font-size: 14px;
        font-weight: 400;
        color: black;
    }

    .egift-content-block .checkboxes input {
        margin-right: 10px;
        width: 24px;
        height: 24px;
        border-radius: 10px;
        box-shadow: inset 1px -2px 11px 1px rgba(1, 1, 1, .2);
        border: 5px solid white !important;
    }

    .egift-content-block .no-checkbox {
        font-size: 18px;
        color: black;
    }

    .egift-content-block-flex-box-right .search_box_egift input.search_input {
        max-width: 100% !important;
        width: 100% !important;
        margin-bottom: 0px !important;
        border-radius: 10px !important;
        border-color: rgb(153, 153, 153);
        padding: 5px;
        padding-left: 15px;
        padding-right: 15px;
    }

    .egift-content-block-flex-box-right .search_box_egift {
        padding-left: 15px;
        padding-right: 15px;
    }

    .egift-content-block-flex-box-right .search_box_egift_flex_box {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        padding-top: 30px;
        row-gap: 30px !important;
    }

    .egift-content-block-flex-box-right .product-without-image span.product-price {
        box-shadow: 0 0 1px 1px rgb(0 0 0 / 8%);
        padding: 10px 8px;
        border-radius: 4px;
        font-size: 11px;
        font-weight: 500;
        color: #5d7182;
        margin: 10px;
    }

    .egift-content-block-flex-box-right .product-without-image span.product-name {
        margin-top: 10px !important;
        margin-bottom: 10px !important;
        display: inline-block;
        color: rgba(0, 0, 0, .6) !important;
    }

    @media(max-width:1024px) {
        .egift-content-block-flex-box-right .search_box_egift_flex_box {
            grid-template-columns: repeat(3, 1fr);
        }
    }

    @media(max-width:991px) {
        .egift-content-block-flex-box-right .search_box_egift_flex_box {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    @media(max-width:450px) {
        .egift-content-block-flex-box-right .search_box_egift_flex_box {
            grid-template-columns: repeat(1, 1fr);
        }
    }

    .egift-content-block-flex-box-right .content-box-column {
        padding-left: 15px;
        padding-right: 15px;
    }

    .egift-content-block-flex-box-right .content-box-column .product-with-image {
        background-color: #fff;
        box-shadow: 0 3px 1px -2px rgb(0 0 0 / 20%), 0 2px 2px 0 rgb(0 0 0 / 14%), 0 1px 5px 0 rgb(0 0 0 / 12%);
        transition: box-shadow .3s;
        border: solid 1px #eee;
        border-radius: 10px;
        padding: 7.5px 7.5px 7.5px 7.5px !important;
        min-height: 260px !important;
    }
</style>
<div class="egift-offer-html sidebar-hide-issue">
    <div class="heading-block-all">
        <div class="heading-block-text">
            <p class="paragraph-text">E-Gift Cards</p>
        </div>
    </div>
    <div class="egift-content-block">
        <div class="egift-content-block-flex-box">
            <div class="egift-content-block-flex-box-left">
                <div class="sidebar-labels">
                    <div class="wallet-icon">
                        <div class="wallet-balance">
                            <span class="amount">$0.00</span>
                        </div>
                        <p>Available</p>
                    </div>
                </div>
                <div class="checkboxes">
                    <p>
                        <input type="checkbox" id="showAllCheckbox" class="show-all-checkbox" onclick="showAllClicked(this)"> Show All
                    </p>
                </div>
                <div class="checkboxes no-border">
                    <p><input type="checkbox"> Show what I can redeem</p>
                </div>
                <div class="sidebar-labels">
                    <div class="no-checkbox">– Category</div>
                </div>
                <div class="checkboxes category-checkboxes">
                    <!-- JS will populate this -->
                </div>
            </div>
            <div class="egift-content-block-flex-box-right">
                <div class="search_box_egift_flex_all_box">
                    <!-- Initial Spinner for Loading -->
                    <div id="egift_loader" style="display: none; text-align: center; padding: 20px;">
                        <div class="spinner-border text-primary" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>
                    </div>

                    <div class="search_box_egift_flex_box" id="egift_offer_data">
                        <input type="hidden" name="contactID" value="<?php echo get_option('contactId'); ?>">
                        <input type="hidden" name="rewardProgramID" value="<?php echo get_option('rpId'); ?>">
                        <input type="hidden" name="webFormId" value="<?php echo get_option('webFormId'); ?>">
                        <!-- Cards and offers populated by JS -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Javascript Code Template -->
<script>
  let allEgiftOfferData = [];

function loadEgiftOffers() {
    const loader = $('#egift_loader');
    const offerContainer = $('#egift_offer_data');

    loader.show();  // Show spinner
    offerContainer.hide();  // Hide content

    $.ajax({
        url: ajax_object.ajax_url,
        method: 'POST',
        data: { "action": "eGiftOffers" },
        dataType: 'json',
        success: function (response) {
            console.log("Response for eGift offers", response);
            populateEgiftOffersTable(response);
        },
        error: function (xhr, status, error) {
            console.error('Error fetching data:', error);
            offerContainer.html('<p class="text-center">Error loading offers.</p>');
        },
        complete: function () {
            loader.hide();  // Hide spinner
            offerContainer.show();  // Show content
        }
    });
}

function populateEgiftOffersTable(data) {
    const categoryContainer = $('.category-checkboxes');
    const offerContainer = $('#egift_offer_data');

    allEgiftOfferData = data;
    renderEgiftOffers(data);

    categoryContainer.empty();  // Clear old categories
    const categoryMap = new Map();

    data.forEach(transaction => {
        const offer = transaction.offerData;
        if (offer?.tangoCategoryName && offer?.tangoCategoryId) {
            categoryMap.set(offer.tangoCategoryId, offer.tangoCategoryName);
        }
    });

    categoryMap.forEach((name, id) => {
        const categoryHtml = `
            <div class="checkboxes category-generated">
                <p><input type="checkbox" class="category-filter" value="${id}" data-category="${name}" onclick="clickedCategory(this)"> ${name}</p>
            </div>
        `;
        categoryContainer.append(categoryHtml);
    });
}

function renderEgiftOffers(data) {
    const tableBody = $('#egift_offer_data');
    tableBody.empty();

    if (!data || data.length === 0) {
        tableBody.append('<p class="text-center">No Data Available</p>');
        return;
    }

    let htmlData = '';
    data.forEach(transaction => {
        const offer = transaction.offerData;
        htmlData += `
            <div class="content-box-column" data-offer-id="${offer.offerID}">
                <div class="product-with-image">
                    <p><img src="${offer.offerImageUrl}" alt="Offer Image"></p>
                    <div class="product-without-image">
                        <span class="product-name">${offer.offerTitle}</span><br>
                        <span>${offer.tangoCategoryName}</span><br>
                        <a href="javascript:void(0);" 
                           class="redeem-btn btn btn-primary btn-sm mt-2" 
                           onclick="redeemOffer(this, '${offer.offerID}')">
                            Redeem Now
                        </a>
                    </div>
                </div>
            </div>
        `;
    });

    tableBody.append(htmlData);
}

function redeemOffer(button, offerID) {
    $(button).prop('disabled', true).append(' <span class="spinner-border spinner-border-sm ms-1" role="status"></span>');

    // Simulate redemption request (replace with actual AJAX)
    setTimeout(() => {
        alert(`Offer ${offerID} redeemed!`);
        $(button).prop('disabled', false).find('.spinner-border').remove();
    }, 2000);
}

function clickedCategory(checkbox) {
    $('#showAllCheckbox').prop('checked', false);
    const selectedCategories = $('.category-filter:checked').map(function () { return $(this).val(); }).get();
    const filteredData = selectedCategories.length === 0
        ? allEgiftOfferData
        : allEgiftOfferData.filter(item => selectedCategories.includes(item.offerData?.tangoCategoryId));
    renderEgiftOffers(filteredData);
}

function showAllClicked(checkbox) {
    if (checkbox.checked) {
        $('.category-filter').prop('checked', false);
        renderEgiftOffers(allEgiftOfferData);
    }
}

$(document).ready(loadEgiftOffers);
</script>

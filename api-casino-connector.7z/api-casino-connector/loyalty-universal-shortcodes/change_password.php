<style>
    /* Title */
    .changePassword_title__7LHef {
        font-size: 20px;
        font-weight: 600;
        margin-bottom: 20px;
    }

    /* Form Container */
    .changePassword_container__d_7bi {
        display: flex;
        gap: 16px;
        flex-wrap: wrap;
    }

    /* Input Field Wrapper */
    .WizInput_base__2JTUy {
        flex: 1;
        position: relative;
        background-color: #1d1f26;
        border: 1px solid #2e3039;
        border-radius: 8px;
        padding: 10px 14px;
        display: flex;
        flex-direction: column;
        min-width: 250px;
    }

    .WizInput_base__2JTUy label {
        font-size: 13px;
        color: #bbb;
        margin-bottom: 6px;
    }

    .WizInput_base__2JTUy input {
        background: transparent;
        border: none;
        color: #fff;
        font-size: 16px;
        padding-right: 36px;
        outline: none;
    }

    /* Eye Button */
    .WizIconButton_base__JfGpY {
        position: absolute;
        top: 34px;
        right: 10px;
        background: transparent;
        border: none;
        padding: 0;
        cursor: pointer;
        z-index: 1;
    }

    .WizIconButton_children__Xqp6z svg {
        fill: #888;
        width: 20px;
        height: 20px;
    }

    /* Submit Button Container */
    .WizButtonContainer_container__r4v3N {
        margin-top: 20px;
    }

    /* Submit Button */
    .WizButton_base__ojkNL {
        background-color: #1d1f26;
        border: 1px solid #b4ff00;
        color: #b4ff00;
        padding: 12px 24px;
        font-size: 16px;
        font-weight: 600;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .WizButton_base__ojkNL:disabled {
        border-color: #444;
        color: #666;
        cursor: not-allowed;
    }

    .WizButton_base__ojkNL:not(:disabled):hover {
        background-color: #b4ff00;
        color: #12141b;
    }
</style>
<h2 class="changePassword_title__7LHef">Change Your Password</h2>
<form class="WizForm_base__gGggs undefined" autocomplete="off">
    <div class="changePassword_container__d_7bi">
        <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_end__A97st"><label for="oldPassword">Old password</label><input type="password" name="oldPassword" id="oldPassword" value=""><button type="button" class="WizIconButton_base__JfGpY" style="position: absolute; right: 4px; top: 4px; height: 36px; width: 36px;">
                <div class="WizIconButton_children__Xqp6z"><svg class="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-1jekisg" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="VisibilityOffIcon">
                        <path d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7M2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2m4.31-.78 3.15 3.15.02-.16c0-1.66-1.34-3-3-3z"></path>
                    </svg></div><span class="WizRipple-wrapper"></span>
            </button></div>
        <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_end__A97st"><label for="newPassword">New password</label><input type="password" name="newPassword" id="newPassword" value=""><button type="button" class="WizIconButton_base__JfGpY" style="position: absolute; right: 4px; top: 4px; height: 36px; width: 36px;">
                <div class="WizIconButton_children__Xqp6z"><svg class="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-1jekisg" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="VisibilityOffIcon">
                        <path d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7M2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2m4.31-.78 3.15 3.15.02-.16c0-1.66-1.34-3-3-3z"></path>
                    </svg></div><span class="WizRipple-wrapper"></span>
            </button></div>
    </div>
    <div class="WizButtonContainer_container__r4v3N WizButtonContainer_start__CwrE5 WizButtonContainer_row__FVI8Q WizButtonContainer_fullWidth__d5Jzj" data-button-container="wrapper"><button class="WizButton_base__ojkNL WizButton_primary-contained__xOImR WizButton_L__UZfj4" type="button" disabled=""><span class="WizButton_text__oCBg0">Change password</span><span class="WizRipple-wrapper"></span></button></div>
</form>
<style>
    .survey-content-block {
        background-color: white;
        /* max-width: 1200px; */
        margin: auto;
        padding: 20px;
        margin-top: 10px;
        width: 100%;
    }

    .survey-content-block-inner {
        background: #f9f9f9;
        padding: 20px 12px 20px 12px;
        margin-bottom: 0px;
    }

    .survey-content-buttons {
        border-bottom: 1px solid #ddd;
        margin-bottom: 20px;
        display: flex;
        gap: 30px;
    }

    .survey-content-buttons a {
        display: inline-block;
        padding: 0px !important;
        background-color: transparent;
        border: 0;
        padding-top: 35px !important;
        padding-bottom: 25px !important;
    }

    .survey-content-buttons a.onbutton {
        border-bottom: 1px solid rgba(238, 96, 89) !important;
    }

    .survey-content-buttons a:hover {
        text-decoration: none !important;
    }

    .survey-content-buttons a span {
        color: #555 !important;
        font-size: 14px;
        text-transform: capitalize;
        font-weight: 600;
    }

    .content-labels {
        display: flex;
    }

    .content-labels .survey-title-font {
        color: rgb(166, 166, 166);
        font-weight: 700;
        font-size: 14px;
        padding-left: 15px;
        padding-right: 15px;
    }

    .survey-tabs-panel-content .survey-title-font:nth-child(1) {
        width: 40%;
    }

    .survey-tabs-panel-content .survey-title-font:nth-child(2) {
        display: flex;
        gap: 100px;
        width: 60%;
    }

    .survey-tabs-panel-content a.take-survey {
        background-color: rgba(238, 96, 89);
        padding: 8px;
        border-radius: 5px;
    }

    .survey-tabs-panel-content a.take-survey:hover {
        text-decoration: none;
        color: white;
    }

    .content-data .survey-flex-box {
        display: flex !important;
        width: 100%;
    }

    .content-data {
        border: 1px solid #ddd;
        justify-items: center;
        padding-top: 18px;
        padding-bottom: 18px;
        background-color: white;
        font-size: 18px;
        font-family: Poppins, Helvetica, sans-serif;
        color: black;
    }

    .content-data .survey-title-font {
        display: inline-block !important;
        padding-left: 15px;
        padding-right: 15px;
        font-size: 16px;
    }

    .content-data .survey-title-font ul li {
        font-weight: 700;
    }

    .content-data .survey-title-font ul {
        margin-bottom: 10px !important
    }

    .content-data .survey-format-flex {
        display: flex !important;
        gap: 110px
    }

    .content-data .survey-format-flex div {
        font-size: 16px;
        color: #c5c5c5;
        font-weight: 700
    }

    .survey-flex-box .survey-title-font:nth-child(2) div {
        display: flex !important;
        justify-content: space-between !important;
    }

    @media(max-width:991px) {
        .survey-format-flex {
            gap: 50px !important
        }

        .survey-title-font {
            gap: 50px !important
        }
    }

    @media(max-width:767px) {
        .survey-format-flex {
            gap: 25px !important
        }

        .survey-title-font {
            gap: 25px !important
        }
    }

    .tab-panel-available {
        display: none;
    }

    .tab-panel-completed {
        display: none;
    }

    .showing-content {
        display: block !important
    }

    #survey-spinner {
    text-align: center;
        padding: 30px 0;
    }

    #survey-spinner .loader {
        border: 4px solid #f3f3f3;
        border-top: 4px solid rgba(238, 96, 89, 1); /* Matches your accent color */
        border-radius: 50%;
        width: 40px;
        height: 40px;
        animation: spin 1s linear infinite;
        margin: auto;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
</style>
<div class="heading-block-all">
    <div class="heading-block-text">
        <p class="paragraph-text">Survey List</p>
    </div>
</div>
<div class="survey-content-block">
    <div class="survey-content-block-inner">
        <div class="survey-content-buttons">
           
            <a class="available-button onbutton">
                <span>Available Surveys</span>
            </a>
            <a class="complete-button">
                <span>Completed Surveys</span>
            </a>

        </div>
        <div class="survey-tabs-panel-content">
            
            <div class="tab-panel-available showing-content">
                
                <div class="whole-content">
                    <div id="survey-spinner" style="text-align:center; padding: 30px 0;">
                        <div class="loader" style="border: 4px solid #f3f3f3; border-top: 4px solid rgba(238, 96, 89); border-radius: 50%; width: 40px; height: 40px; animation: spin 1s linear infinite; margin: auto;"></div>
                    </div>
                    <div class="content-labels">
                        <div class="survey-title-font">
                            <p>Survey Title</p>
                        </div>
                        <div class="survey-title-font">
                            <p>Date Sent</p>
                        </div>
                    </div>
                    <div class="content-data" id="available-surveys-container">
                    </div>
                </div>
            </div>
            <div class="tab-panel-completed">
                <div class="whole-content">
                    <div class="content-labels">
                        <div class="survey-title-font">
                            <p>Survey Title</p>
                        </div>
                        <div class="survey-title-font">
                            <p>Date Sent</p>
                        </div>
                    </div>
                    <div class="content-data" id="completed-surveys-container">
                        <div id="survey-spinner" style="text-align:center; padding: 30px 0;">
                            <div class="loader" style="border: 4px solid #f3f3f3; border-top: 4px solid rgba(238, 96, 89); border-radius: 50%; width: 40px; height: 40px; animation: spin 1s linear infinite; margin: auto;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script>

function populateSurveysTable(data) {
        const availableContainer = $('#available-surveys-container');
        const completedContainer = $('#completed-surveys-container');

        availableContainer.empty();
        completedContainer.empty();

        // Available Surveys
        if (!data.available || data.available.length === 0) {
            availableContainer.append('<div class="text-center">No Available Surveys</div>');
        } else {
            data.available.forEach(survey => {
                const html = `
                    <div class="survey-flex-box">
                        <div class="survey-title-font">
                            <ul>
                                <li>${survey.surveyTitle}</li>
                            </ul>
                        </div>
                        <div class="survey-title-font">
                            <div class="survey-format-flex">
                                <div>${survey.surveySendDataString}</div>
                                <div><a class="take-survey" href="${survey.buttonSurveyLink}" target="_blank">Take survey</a></div>
                            </div>
                        </div>
                    </div>`;
                availableContainer.append(html);
            });
        }

        // Completed Surveys
        if (!data.completed || data.completed.length === 0) {
            completedContainer.append('<div class="text-center">No Completed Surveys</div>');
        } else {
            data.completed.forEach(survey => {
                const html = `
                    <div class="survey-flex-box">
                        <div class="survey-title-font">
                            <ul>
                                <li>${survey.surveyTitle}</li>
                            </ul>
                        </div>
                        <div class="survey-title-font">
                            <div class="survey-format-flex">
                                <div>${survey.surveySendDataString}</div>
                                <div>${survey.respondDateString}</div>
                                <div>${survey.surveyPoints ?? '0'}</div>
                            </div>
                        </div>
                    </div>`;
                completedContainer.append(html);
            });
        }
    }

jQuery(document).ready(function(e) {
    $.ajax({
        url: ajax_object.ajax_url,
        method: 'GET',
        data: {
            action: "getSurveys"
        },
        dataType: 'json',
        success: function(response) {
            console.log("response for surveys", response);
            populateSurveysTable(response);
            // let filters = response.data?.responsedata?.filters;
            // populateFilters(filters);
        },
        error: function(xhr, status, error) {
            console.error('Error fetching Surveys data:', error);
        },
        complete: function() {
            // Hide spinner, show table
            $('#survey-spinner').hide();

            $('#leaderboardTable').show();
        }
    });
});
</script>

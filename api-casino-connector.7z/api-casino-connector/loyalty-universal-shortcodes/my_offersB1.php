<style>
  .egift-offer-html .heading-bar-html {
    padding: 0px !important;
    background-color: #ee605929 !important;
  }
  .egift-offer-html .heading-bar-html .survey-head-flex {
    padding: 12px !important;
    max-width: max-content;
    background: transparent !important;
    padding-left: 0px !important;
    padding-right: 0px !important;
    border-bottom: 2px solid rgba(238, 96, 89);
    font-size: 14px !important;
    text-transform: capitalize;
    text-decoration: unset;
    cursor: pointer !important;
  }
  .egift-offer-html {
    width: 100%;
  }
  @media(max-width:767px) {
    .egift-offer-html .survey-head-width {
      padding-left: 20px !important;
      padding-right: 20px !important;
    }
    .egift-offer-html .survey-head-width .survey-head-flex {
      justify-self: center;
    }
  }
  .egift-content-block {
    max-width: 1200px;
    margin: auto !important;
    margin-top: 10px !important;
  }
  .egift-content-block .egift-content-block-flex-box {
    display: flex;
  }
  .egift-content-block .egift-content-block-flex-box-right {
    width: 100%;
    background-color: white;
    padding-top: 10px;
    padding-bottom: 25px;
    border-radius: 5px;
  }
  .egift-content-block-flex-box-right .search_box_egift_flex_box {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    padding-top: 30px;
    row-gap: 30px !important;
  }
  @media(max-width:1024px) {
    .egift-content-block-flex-box-right .search_box_egift_flex_box {
      grid-template-columns: repeat(3, 1fr);
    }
  }
  @media(max-width:991px) {
    .egift-content-block-flex-box-right .search_box_egift_flex_box {
      grid-template-columns: repeat(2, 1fr);
    }
  }
  @media(max-width:450px) {
    .egift-content-block-flex-box-right .search_box_egift_flex_box {
      grid-template-columns: repeat(1, 1fr);
    }
  }
  .egift-content-block-flex-box-right .content-box-column {
    padding-left: 15px;
    padding-right: 15px;
  }
  .egift-content-block-flex-box-right .content-box-column .product-with-image {
    background-color: #fff;
    box-shadow: 0 3px 1px -2px rgb(0 0 0 / 20%), 0 2px 2px 0 rgb(0 0 0 / 14%), 0 1px 5px 0 rgb(0 0 0 / 12%);
    transition: box-shadow .3s;
    border: solid 1px #eee;
    border-radius: 10px;
    padding: 7.5px;
    min-height: 260px !important;
    text-align: center;
  }
  .egift-content-block-flex-box-right .product-with-image img {
    max-width: 100%;
    height: auto;
    margin-bottom: 10px;
  }
  .product-name {
    display: block;
    color: rgba(0, 0, 0, 0.6);
    margin-top: 5px;
    margin-bottom: 5px;
  }
  .product-price {
    display: inline-block;
    font-size: 16px;
    font-weight: 400;
    color: #000;
    margin-bottom: 10px;
  }
  .submit-button-anchor {
    background: #000;
    color: #fff;
    padding: 8px 12px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    margin-top: 5px;
    display: inline-flex;
    align-items: center;
  }
  .btn-spinner {
    display: none;
    margin-left: 5px;
  }
  #offer_data.loading-spinner {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 30px 0;
  }
  #global-spinner {
    min-height: 50px;
    width: auto;
  }
</style>

<div class="egift-offer-html sidebar-hide-issue">
  <div class="heading-block-all">
    <div class="heading-block-text">
      <p class="paragraph-text">My Offers</p>
    </div>
  </div>
  <div class="egift-content-block">
    <div class="egift-content-block-flex-box">
      <div class="egift-content-block-flex-box-right">
        <form action="" method="post" class="redeem-egiftoffer-form">
          <div id="offer_data" class="search_box_egift_flex_box loading-spinner">
            <div style="text-align: center;" id="global-spinner">
              <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
function loadOffers() {
  $('#global-spinner').show();
  $('#offer_data').hide();

  $.ajax({
    url: ajax_object.ajax_url,
    method: 'POST',
    data: { action: 'myOffers' },
    dataType: 'json',
    success: function(response) {
      const offers = response?.data?.responsedata?.offers || response || [];
      populateMyOffersTable(offers);
    },
    error: function(xhr, status, error) {
      console.error('Error fetching offers:', error);
      populateMyOffersTable([]);
    },
    complete: function() {
      $('#global-spinner').hide();
      $('#offer_data').show();
    }
  });
}

function populateMyOffersTable(data) {
  const container = $('#offer_data');
  container.removeClass('loading-spinner').empty();

  if (!data.length) {
    container.append('<div style="grid-column: 1/-1; text-align: center; padding: 20px;">No Data Available</div>');
    return;
  }

  const seenOfferIds = new Set();
  data.forEach(offer => {
    if (!offer?.offerID || seenOfferIds.has(offer.offerID)) return;
    seenOfferIds.add(offer.offerID);

    const offerHtml = `
      <div class="content-box-column" data-offer-id="${offer.offerID}">
        <div class="product-with-image">
          <img src="${offer.offerImageUrl}" alt="${offer.offerTitle}">
          <span class="product-name">${offer.offerTitle}</span>
          <span class="product-price">$${offer.offerPointValue}</span>
          <button type="button" class="submit-button-anchor redeem-my-offer-btn" data-offer-id="${offer.offerID}">
            <span class="btn-text">Redeem Now</span>
            <span class="btn-spinner">
              <div class="spinner-border spinner-border-sm" role="status" style="width:1rem; height:1rem;">
                <span class="visually-hidden">Loading...</span>
              </div>
            </span>
          </button>
        </div>
      </div>`;
    container.append(offerHtml);
  });
}

$(document).ready(function() {
  loadOffers();

  $(document).on('click', '.redeem-my-offer-btn', function() {
    const button = $(this);
    const offerId = button.data('offer-id');
    const btnText = button.find('.btn-text');
    const btnSpinner = button.find('.btn-spinner');

    button.prop('disabled', true);
    btnText.hide();
    btnSpinner.show();

    $.ajax({
      url: ajax_object.ajax_url,
      method: 'POST',
      dataType: 'json',
      data: { action: 'redeemOffer', offer_id: offerId },
      success: function(response) {
        if (response?.data?.statusCode) {
          openModal(response.data.statusMessage, true);

        } else {
		  openModal('Error: ' + (response.data?.statusMessage || 'Unknown error'), true);
        }
      },
      error: function(xhr, status, error) {
        console.error('AJAX error:', error);
        alert('AJAX error: ' + error);
      },
      complete: function() {
        button.prop('disabled', false);
        btnText.show();
        btnSpinner.hide();
      }
    });
  });
});
</script>

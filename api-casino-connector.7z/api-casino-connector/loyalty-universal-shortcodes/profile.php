<style>
    .profile-form-html {
        background-color: white;
        max-width: 1200px;
        margin: auto;
        padding: 40px 65px 20px 65px;
        margin-top: 10px;
    }

    .profile-form-html .membership-form-heading p {
        font-size: 24px !important;
        margin-bottom: 0px !important;
        color: #666;
    }

    .profile-form-html input {
        border-color: rgb(204, 204, 204) !important;
        background-color: transparent !important;
        border-radius: 5px !important;
        padding-left: 45px !important;
        height: 35px !important;
        color: rgb(102, 102, 102) !important;
    }

    .profile-form-html input::placeholder {
        color: rgb(102, 102, 102) !important;
    }

    .profile-form-html select {
        border-color: rgb(204, 204, 204) !important;
        background-color: transparent !important;
        border-radius: 5px !important;
        padding-left: 45px !important;
        height: 35px !important;
        color: rgb(102, 102, 102) !important;
        width: 100%;
    }

    .profile-form-html select::placeholder {
        color: rgb(102, 102, 102) !important;
    }

    .profile-form-html .all-fields-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        column-gap: 30px;
    }

    @media(max-width:767px) {
        .profile-form-html .all-fields-grid {
            grid-template-columns: repeat(1, 1fr);
        }
    }

    .profile-form-html .all-fields-grid div {
        padding-top: 7.5px;
        padding-bottom: 7.5px;
    }

    .profile-form-html .all-fields-grid div:has(input):before,
    .profile-form-html .all-fields-grid div:has(select):before {
        content: "";
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        font-size: 14px;
        margin-right: 5px;
        color: white !important;
        position: absolute;
        background: #ee6059;
        height: 35px;
        width: 34px;
        align-content: center;
        text-align: center;
    }

    .profile-form-html .all-fields-grid .first-name-block:before {
        content: "\f007";
    }

    .profile-form-html .all-fields-grid .last-name-block:before {
        content: "\f007";
    }

    .profile-form-html .all-fields-grid .Gender-block:before {
        content: "\f183";
    }

    .profile-form-html .all-fields-grid .mobile-number-block:before {
        content: "\f3cd";
    }

    .profile-form-html .all-fields-grid .email-form-block:before {
        content: "\f0e0";
    }

    .profile-form-html .all-fields-grid .password-block:before {
        content: "\f023";
    }

    .profile-form-html .all-fields-grid .describes-you-block:before {
        content: "\f0ca";
    }

    .profile-form-html .all-fields-grid .big-spender-block:before {
        content: "\f0ca";
    }

    .profile-form-html .all-fields-grid .appointment-block:before {
        content: "\f073";
    }

    .profile-form-html .all-fields-grid .fav-hockey-block:before {
        content: "\f0ca";
    }

    .profile-form-html .all-fields-grid .leaderboard-form-block:before {
        content: "\f091";
    }

    .all-fields-grid div:has(input:required) {
        position: relative !important;
    }

    .all-fields-grid div:has(input:required):after {
        content: "*";
        font-family: "Font Awesome";
        font-weight: 900;
        font-size: 15px !important;
        position: absolute;
        right: -10px;
        top: 5px;
        font-size: 7px;
        color: red !important;
    }

    .all-fields-grid div:has(select:required) {
        position: relative !important;
    }

    .all-fields-grid div:has(select:required):after {
        content: "*";
        font-family: "Font Awesome";
        font-weight: 900;
        font-size: 15px !important;
        position: absolute;
        right: -10px;
        top: 5px;
        font-size: 7px;
        color: red !important;
    }

    .images-with-button {
        padding-top: 0px !important;
        display: flex !important;
        flex-direction: row;
        gap: 10px;
    }

    .images-with-button .form-nested-image img {
        max-width: 60px;
    }

    .images-with-button .form-nested-buttongreen a.button_changes {
        border-radius: 10px !important;
        background-color: #1dc9b7 !important;
        padding: 6px !important;
        padding-left: 15px !important;
        padding-right: 15px !important;
        font-size: 14px !important;
    }

    .images-with-button .form-nested-buttonorange a.button_changes {
        border-radius: 10px !important;
        background-color: rgb(238, 96, 89) !important;
        padding: 6px !important;
        padding-left: 15px !important;
        padding-right: 15px !important;
        font-size: 14px !important;
    }

    .profile-form-html .all-fields-grid .address-form-block:before {
        content: "\f57d";
    }

    .profile-form-html .all-fields-grid .birthday-block:before {
        content: "\f1fd";
    }

    .profile-form-html .all-fields-grid .anniversary-block:before {
        content: "\f1fd";
    }

    .profile-form-html .all-fields-grid .email-select-block:before {
        content: "\f1fd";
    }

    .profile-form-html .all-fields-grid .sms-select-block:before {
        content: "\f3cd";
    }

    .profile-form-html .all-fields-grid .push-select-block:before {
        content: "\f0f3";
    }

    .profile-form-html .all-fields-grid .media-select-block:before {
        content: "\f013";
    }

    .profile-form-html a.addbirthday {
        padding: 9px 20px;
        line-height: 14px;
        font-size: 12px;
        background-color: #1dc9b7;
        border-radius: 5px;
        text-transform: uppercase
    }

    .birthday-add-button {
        margin-bottom: 10px;
    }

    .submit-button-form .form-submit {
        padding: 8px 20px !important;
        padding-top: 8px !important;
        padding-right: 20px !important;
        padding-bottom: 8px !important;
        padding-left: 20px !important;
        border-radius: 5px;
        font-size: 16px !important;
        text-transform: capitalize;
        background-color: #ee6059;
        cursor: pointer !important;
        color: #fff;
    }

    .submit-button-form .form-submit:hover {
        color: white !important;
        text-decoration: none
    }

    .submit-button-form {
        margin-top: 30px;
        justify-self: center;
    }

    .images-with-button {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .form-nested-image img {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        object-fit: cover;
        border: 2px solid green;
    }

    .button_changes {
        padding: 8px 16px;
        border-radius: 20px;
        color: white;
        font-weight: bold;
        text-decoration: none;
        cursor: pointer;
        display: inline-block;
    }

    .form-nested-buttongreen .button_changes {
        background-color: #1cc5b7;
    }

    .form-nested-buttonorange .button_changes {
        background-color: #f15f5f;
    }

    #imageInput {
        display: none;
    }

    #birthday-list {
        margin-top: 15px;
    }

    .birthday-entry {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 10px;
        flex-wrap: wrap;
    }

    .birthday-entry input[type="text"],
    .birthday-entry input[type="date"] {
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        flex: 1 1 200px;
        font-size: 14px;
        background-color: #fff;
    }

    .birthday-entry button.remove-birthday {
        background-color: #e74c3c;
        border: none;
        color: #fff;
        font-size: 16px;
        border-radius: 5px;
        padding: 8px 12px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .birthday-entry button.remove-birthday:hover {
        background-color: #c0392b;
    }

    #addBirthdayBtn {
        background-color: #1abc9c;
        color: white;
        border: none;
        padding: 10px 15px;
        font-size: 14px;
        border-radius: 5px;
        cursor: pointer;
        margin-top: 10px;
        transition: background-color 0.3s ease;
    }

    #addBirthdayBtn:hover {
        background-color: #16a085;
    }
</style>
<div class="heading-block-all">
    <div class="heading-block-text">
        <p class="paragraph-text">Update Profile</p>
    </div>
</div>
<form id="profile-update-form" method="POST" action="<?php echo admin_url('admin-ajax.php'); ?>">
    <div class="profile-form-html">
        <div class="membership-form-heading">
            <p>Member Details</p>
        </div>
        <div class="membership-form-profile">
            <div class="all-fields-grid">
                <div class="first-name-block">
                    <input type="text" name="first_name" placeholder="First Name" required>
                </div>
                <div class="last-name-block">
                    <input type="text" name="last_name" placeholder="Last Name" required>
                </div>
                <div class="Gender-block">
                    <select name="gender" required>
                        <option value="" disabled selected>-- Please Select Gender --</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </div>
                <div class="mobile-number-block">
                    <input type="text" name="phone_number" placeholder="(777) 777-7777" required>
                </div>
                <div class="email-form-block">
                    <input type="email" name="email" placeholder="Email" required>
                </div>
                <div class="password-block">
                    <input type="password" name="password" placeholder="Password">
                </div>
                <div class="describes-you-block">
                    <select name="describe_yourself" required>
                        <option value="" disabled selected>What best describes you?</option>
                        <option value="Trucker Traveler">Trucker Traveler</option>
                        <option value="Local Enthusiast">Local Enthusiast</option>
                    </select>
                </div>
                <div class="big-spender-block">
                    <select name="spender" required>
                        <option value="" disabled selected>Big Spender?</option>
                        <option value="Yes, Big Spender">Yes, Big Spender</option>
                    </select>
                </div>
                <div class="appointment-block">
                    <input type="date" name="appointment_date" required>
                </div>
                <div class="fav-hockey-block">
                    <select name="fvrt_hockey_team" required>
                        <option value="" disabled selected>Favorite Hockey Team?</option>
                        <option value="Anaheim Ducks">Anaheim Ducks</option>
                        <option value="Arizona Coyotes">Arizona Coyotes</option>
                        <option value="Boston Bruins">Boston Bruins</option>
                        <option value="Buffalo Sabres">Buffalo Sabres</option>
                        <option value="Calgary Flames">Calgary Flames</option>
                        <option value="Carolina Hurricanes">Carolina Hurricanes</option>
                        <option value="Chicago Blackhawks">Chicago Blackhawks</option>
                    </select>
                </div>
                <div class="leaderboard-form-block">
                    <input type="text" name="display_name" placeholder="Leaderboard Display Name Text" required>
                </div>
                <div class="images-with-button">
                    <div class="form-nested-image">
                        <img id="profileImage" src="https://casino3.myrwds.net/wp-content/uploads/255702286.jpg" alt="Profile Picture">
                    </div>
                    <div class="form-nested-buttongreen">
                        <div>
                            <a class="button_changes" onclick="triggerUpload()">Change</a>
                        </div>
                    </div>
                    <div class="form-nested-buttonorange">
                        <div>
                            <a class="button_changes" onclick="resetImage()">Reset</a>
                        </div>
                    </div>
                </div>
                <!-- Hidden file input -->
                <input type="file" id="imageInput" accept="image/*" onchange="previewImage(event)">
            </div>

            <div class="membership-form-heading">
                <p>Member Address</p>
            </div>
            <div class="membership-form-profile-address">
                <div class="all-fields-grid">
                    <div class="address-form-block">
                        <input type="text" name="address" placeholder="Address1">
                    </div>
                    <div class="address-form-block">
                        <input type="text" name="city" placeholder="City">
                    </div>
                    <div class="address-form-block">
                        <input type="text" name="state" placeholder="State">
                    </div>
                    <div class="address-form-block">
                        <input type="text" name="zip" placeholder="Zip">
                    </div>
                </div>
            </div>

            <div class="membership-form-heading">
                <p>Important Dates</p>
            </div>
            <div class="membership-form-profile-address">
                <div class="all-fields-grid">
                    <div class="birthday-block">
                        <input type="text" name="birthday" placeholder="26-Feb" disabled>
                    </div>
                    <div class="anniversary-block">
                        <input type="date" name="anniversary">
                    </div>
                </div>
            </div>

            <div class="membership-form-heading">
                <p>Enter Friends &amp; Family Birthdays for More Offers!</p>
            </div>
            <!-- <div class="birthday-add-button">
                <a class="addbirthday">
                    <span class="button-text">Add Birthday</span>
                </a>
            </div> -->
            <div id="birthday-list">
                <div class="birthday-entry">
                    <input type="text" name="additional_name[]" placeholder="Friend's Name" required />
                    <input type="date" name="additional_birthdate[]" required />
                    <button type="button" class="remove-birthday" onclick="removeBirthday(this)">✖</button>
                </div>
            </div>
            <button type="button" id="addBirthdayBtn">Add Birthday</button>

            <div class="membership-form-heading">
                <p>Member Permissions &amp; Preferences</p>
            </div>
            <div class="membership-form-profile-address">
                <div class="all-fields-grid">
                    <div class="email-select-block">
                        <select name="allow_email">
                            <option value="" disabled selected>Allow Email?</option>
                            <option value="Yes, allow email">Yes, allow email</option>
                            <option value="No, don't allow email">No, don't allow email</option>
                        </select>
                    </div>
                    <div class="sms-select-block">
                        <select name="allow_sms">
                            <option value="" disabled selected>Allow SMS?</option>
                            <option value="Yes, allow SMS">Yes, allow SMS</option>
                            <option value="No, don't allow SMS">No, don't allow SMS</option>
                        </select>
                    </div>
                    <div class="push-select-block">
                        <select name="allow_push">
                            <option value="" disabled selected>Allow PUSH?</option>
                            <option value="Yes, allow PUSH">Yes, allow PUSH</option>
                            <option value="No, don't allow PUSH">No, don't allow PUSH</option>
                        </select>
                    </div>
                    <div class="media-select-block">
                        <select name="preferred_media">
                            <option value="" disabled selected>Preferred Media?</option>
                            <option value="Email is my preferred communication">Email is my preferred communication</option>
                            <option value="SMS is my preferred communication">SMS is my preferred communication</option>
                            <option value="PUSH is my preferred communication">PUSH is my preferred communication</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <div class="submit-button-form">
            <div class="main-spinner" style="position: relative;">
                <div id="spinner-profile" class="spinner-container-new" style="display: none; text-align: center; margin-bottom: 10px;">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
            <button type="submit" class="form-submit">
                <span class="text-submit-form">Save Changes</span>
            </button>
        </div>
    </div>
</form>


<script>

function triggerUpload() {
    document.getElementById("imageInput").click();
}


function resetImage() {
    document.getElementById("profileImage").src = "https://casino3.myrwds.net/wp-content/uploads/255702286.jpg";
}

function previewImage(event) {
    const file = event.target.files[0];
    if (file && file.type.startsWith("image/")) {
        const reader = new FileReader();
        reader.onload = function (e) {
            console.log(e.target.result);
            
            document.getElementById("profileImage").src = e.target.result;
        };
        reader.readAsDataURL(file);
    } else {
        alert("Please select a valid image file.");
    }
}

 jQuery(document).ready(function ($) {

  



        var btn = $(this);
        btn.addClass('loading');

        // Simulate a delay — remove this in your actual AJAX call
        setTimeout(function () {
            btn.removeClass('loading'); // Remove spinner after 3 seconds
        }, 3000);

        $('.form-submit').on('click', function (e) {
            e.preventDefault();

            const spinner = $("#spinner-profile");
            // spinner.removeClass("d-none");
            spinner.show();

            var formElement = document.getElementById('profile-update-form'); // Your actual form ID
            var formData = new FormData(formElement);
            formData.append('action', 'handle_update_user_profile'); // Append action manually if not in the form

            $.ajax({
                url: ajax_object.ajax_url,
                type: "POST",
                dataType: "json",
                processData: false,
                contentType: false,
                data: formData,
                success: function (response) {
                    console.log(response);
                    openModal(response.data.message, true);
                },
                error: function (error) {
                    openModal("Error submitting the form. Please try again.", true);
                },
                complete: function () {
                    // spinner.addClass("d-none");
                    spinner.hide();
                }
            });
        });

    });


</script>
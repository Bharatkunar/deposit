<style>
    .refer-friend-whitebox {
        background-color: white;
        max-width: 1200px;
        margin: auto;
        padding: 20px;
        margin-top: 10px;
        padding-bottom: 40px;
    }

    .refer-friend-whitebox .refer-friend-flex-content {
        text-align: center
    }

    .refer-friend-whitebox .refer-content {
        font-size: 24px !important;
        font-weight: 500 !important;
        color: #666;
        margin-bottom: 20px
    }

    .refer-friend-whitebox .refer-content_below {
        font-size: 18px !important;
        margin-bottom: 20px;
    }

    .refer-friend-whitebox .refer-content-link {
        width: max-content;
        background-color: #F9F9F9;
        border: 1px solid #DDDDDD;
        align-self: center;
        padding: 0px 15px;
        font-size: 18px;
        font-weight: 700;
        color: black;
        margin-bottom: 20px;
        justify-self: center;
    }

    .refer-friend-whitebox a.email_my_friends_button {
        display: block;
        width: max-content !important;
        line-height: 20px !important;
        /* padding: 10px 20px !important; */
        border-radius: 5px;
        font-size: 16px !important;
        text-transform: capitalize;
        background-color: #ee6059;
        justify-self: center;
    }

    .heading-block-all {
        margin: initial !important;
        margin-bottom: 10px !important;
    }

    .refer-friend-whitebox {
        margin: initial !important;
    }
</style>

<div class="heading-block-all">
    <div class="heading-block-text">
        <p class="paragraph-text">Refer Friends</p>
    </div>
</div>
<div class="refer-friend-whitebox">
    <div class="refer-friend-flex-content">
        <div class="refer-content">
            <p><?php echo $shareLinkTitle; ?></p>
        </div>
        <div class="refer-content_below">
            <?php echo $shareLinkText; ?>
        </div>
        <div class="refer-content-link">
            <input name="txtpersonallink" type="text" id="txtpersonallink" onclick="this.select();" value="<?php echo $link; ?>" title="Click and copy this link" readonly
                style="text-align: center; font-weight: bold; cursor: pointer; flex: 1; background-color: #F9F9F9; border: 1px solid #DDDDDD; height: 40px; border-radius: 5px; padding: 10px; font-size: 16px;">
        </div>
        <div>
            <a class="email_my_friends_button" href="#">
                <button type="button" onclick="copyLink(event)" style="background:rgb(255, 0, 0); padding: 10px 15px; color: white; border: none;  border-radius: 5px; cursor: pointer; font-size: 16px;">Copy</button>
            </a>
        </div>
        <!-- <div id="toast" style="display:none;position:fixed;bottom:20px;right:20px;background:#28a745;color:white;padding:10px 15px;border-radius:5px;">
            Link copied!
        </div> -->
    </div>
</div>
</div>

<script>
// // // Copy Referal Link
function copyLink(event) {
    event.preventDefault(); // Prevent default behavior like form submit or anchor jump

    var copyText = document.getElementById("txtpersonallink");
    copyText.select();
    copyText.setSelectionRange(0, 99999); // For mobile devices
    navigator.clipboard.writeText(copyText.value)
        .then(() => {
            alert("Copied: " + copyText.value);
        })
        .catch(err => {
            console.error('Failed to copy: ', err);
        });
}
</script>
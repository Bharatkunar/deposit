<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cashback Redemption</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .modal {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 400px;
            background: #fff;
            padding: 20px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            text-align: center;
            display: none;
            z-index: 1000;
        }
        .modal-footer {
            display: flex;
            justify-content: space-around;
        }
        .modal-btn {
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            border-radius: 5px;
        }
        .cancel-btn {
            background: #ccc;
        }
        .confirm-btn {
            background: #28a745;
            color: white;
        }
    </style>
</head>
<body>
    <form class="TrasferPointBlock">
        <label for="txtTransferamount">Enter Cashback Amount:</label>
        <input type="number" id="txtTransferamount" min="1" required>
        <button type="submit" class="btnRedeemCash">Redeem Cashback</button>
    </form>

    <!-- Modal Structure -->
    <div id="cashbackModal" class="modal">
        <div class="modal-content">
            <h4 id="modalTitle"></h4>
            <p id="modalMessage"></p>
        </div>
        <div class="modal-footer">
            <button class="modal-btn cancel-btn" id="cancelRedemption">Cancel</button>
            <button class="modal-btn confirm-btn" id="confirmRedemption">Okay</button>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            const transferForm = $(".TrasferPointBlock");
            const btnRedeemCash = $(".btnRedeemCash");
            const modal = $("#cashbackModal");
            const modalTitle = $("#modalTitle");
            const modalMessage = $("#modalMessage");
            const spinnerHTML = `<span class="spinner-border spinner-border-sm me-2" role="status"></span> Processing...`;
            
            const popupData = {
                title: "LAST STEP....",
                message: "Are you sure you want to redeem cashback?",
                successMessage: "Your transaction was successful! We are processing your order."
            };

            // Show Modal before processing AJAX
            transferForm.submit(function (event) {
                event.preventDefault();
                let amount = parseFloat($("#txtTransferamount").val());
                if (isNaN(amount) || amount <= 0) {
                    alert("Please enter a valid cashback amount.");
                    return;
                }
                modalTitle.text(popupData.title);
                modalMessage.text(popupData.message);
                modal.show();
            });
            
            // Cancel Modal
            $("#cancelRedemption").click(function () {
                modal.hide();
            });
            
            // Confirm & Trigger AJAX
            $("#confirmRedemption").click(function () {
                modal.hide();
                btnRedeemCash.prop("disabled", true).html(spinnerHTML);
                
                $.ajax({
                    url: "your_backend_ajax_url", // Replace with your actual AJAX endpoint
                    method: "POST",
                    dataType: "json",
                    data: {
                        action: "redeemOffer",
                        cashback_amount: $("#txtTransferamount").val()
                    },
                    success: function (response) {
                        if (response.statusCode === 1) {
                            alert(popupData.successMessage);
                        } else {
                            alert("Error: " + response.statusMessage);
                        }
                    },
                    error: function () {
                        alert("Failed to redeem cashback.");
                    },
                    complete: function () {
                        btnRedeemCash.prop("disabled", false).html("Redeem Cashback");
                    }
                });
            });
        });
    </script>
</body>
</html>

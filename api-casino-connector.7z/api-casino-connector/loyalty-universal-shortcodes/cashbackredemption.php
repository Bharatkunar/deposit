<style>
    .transfer-white-block {
        max-width: 1200px !important;
        padding-right: 20px;
        padding-left: 20px;
        margin: auto;
        background-color: white;
        margin-top: 20px;
        padding-bottom: 60px;
    }

    .transfer-how-many {
        padding-top: 20px;
        font-size: 30px;
        color: rgb(102, 102, 102);
        text-align: center;
    }

    .transfer-how-many p {
        margin-bottom: 56px;
    }

    .transfer-content h4.formatting_heading {
        font-size: 18px !important;
        color: rgb(102, 102, 102) !important;
        font-weight: 400 !important;
    }

    .transfer-content {
        display: flex;
        flex-direction: row
    }

    .transfer-content .transfer-content-left-pts {
        width: 50%;
        padding-left: 20px;
        padding-right: 20px;
        border-right: solid 2px #eee;
    }

    .transfer-content .transfer-content-right-pts {
        width: 50%;
        padding-left: 20px;
        padding-right: 20px;
    }

    .transfer-content .code_inline {
        display: flex;
        gap: 10px;
        margin-bottom: 20px;
        background-color: #ee605929;
        padding: 20px 50px;
        border: solid 2px #ee605929;
        border-radius: 8px;
        justify-content: center;
        color: rgba(238, 96, 89) !important;
        padding-top: 40px !important;
    }

    .transfer-content .counter_inline {
        margin-top: -20px;
    }

    .transfer-content .counter_inline span {
        margin-right: 3px;
        padding: 10px;
        padding-left: 12px;
        padding-right: 12px;
        color: rgba(238, 96, 89) !important;
        background: linear-gradient(to bottom, rgb(255, 255, 255) 0%, rgba(246, 246, 246, 1) 47%, rgb(212, 212, 212) 100%);
        border-bottom: 2px solid rgba(238, 96, 89);
        border-radius: 5px;
        font-size: 45px;
        font-family: 'Yantramanav', sans-serif !important;
    }

    .transfer-content-right-pts .email-field input {
        border-color: rgba(238, 96, 89) !important;
        background-color: transparent !important;
        border-radius: 5px !important;
        padding-left: 45px !important;
        height: 50px !important;
    }

    .transfer-content-right-pts .transfer-field input {
        border-color: rgba(238, 96, 89) !important;
        background-color: transparent !important;
        border-radius: 5px !important;
        padding-left: 45px !important;
        height: 50px !important;
    }

    .input-fields {
        display: flex;
        flex-direction: column;
        gap: 30px;
    }

    .input-fields .email-field:before {
        content: "\f007";
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        font-size: 14px;
        margin-right: 5px;
        color: #ee6059 !important;
        position: absolute;
        background: #ee605929;
        height: 50px;
        width: 40px;
        align-content: center;
        text-align: center;
        right: 90px;
    }

    .input-fields .transfer-field:before {
        content: "\f0ec";
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        font-size: 14px;
        margin-right: 5px;
        color: #ee6059 !important;
        position: absolute;
        background: #ee605929;
        height: 50px;
        width: 40px;
        align-content: center;
        text-align: center;
        right: 90px;
    }

    .submit-button {
        justify-self: center;
        padding-top: 40px;
    }

    a.submit-button-anchor {
        padding: 10px 25px;
        background-color: #ee6059;
        border-radius: 5px;
    }

    a.submit-button-anchor:hover {
        text-decoration: none !important;
        color: white;
    }

    .cashback-options {
        display: flex;
        justify-content: center;
        gap: 40px;
        margin-top: 30px;
    }

    .cashback-box {
        text-align: left;
        background-color: #1e1e1e;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    }

    .input-group {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .input-group p {
        margin: 0;
        font-weight: bold;
        color: #fff;
    }

    .number-display {
        font-size: 26px;
        font-weight: bold;
        color: #00bfff;
        background-color: #003b5c;
        padding: 10px 20px;
        border-radius: 8px;
    }

    #txtTransferamount {
        padding: 12px 16px;
        border: 1px solid #888;
        border-radius: 8px;
        width: 100%;
        background-color: #0d0d0d;
        color: #fff;
    }


    @media(max-width:767px) {
        .transfer-content {
            display: flex;
            flex-direction: column !important
        }

        .transfer-content .transfer-content-left-pts {
            width: 100% !important;
            border-right: 0px !important;
        }

        .transfer-content .transfer-content-right-pts {
            width: 100% !important;
        }
    }

    @media(max-width:500px) {
        .transfer-content .code_inline {
            padding-left: 0px !important;
            padding-right: 0px !important
        }

        .transfer-content .counter_inline span {
            font-size: 20px !important;
        }

        .transfer-content .code_inline {
            font-size: 10px;

        }
    }

    @media(max-width:350px) {
        .transfer-content .counter_inline span {
            padding: 5px !important
        }
    }

    #main-spinner
    {
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 30px 0;
    }

</style>
<section class="profile">
    <div class="heading-block-all">
        <div class="heading-block-text">
            <p class="paragraph-text">Cashback Redemption</p>
        </div>
    </div>
    <div class="transfer-white-block">
        <div class="transfer-head-block">
            <div class="transfer-how-many">
                <p>How much cashback would you like?</p>
            </div>
        </div>

        <div class="transfer-content">
            <div class="transfer-content-left-pts">
                <h4 class="formatting_heading">
                    Tap for Quick Redemption
                </h4>
                <div class="code_inline">
                    <button type="button" class="mc-btn primarybutton clsquickRedemption" data-value="25" style="background: #ff0000; color: #fff; padding: 8px 16px; border: none; border-radius: 5px; margin: 0 5px;">$25</button>
                    <button type="button" class="mc-btn primarybutton clsquickRedemption" data-value="50" style="background: #ff0000; color: #fff; padding: 8px 16px; border: none; border-radius: 5px; margin: 0 5px;">$50</button>
                    <button type="button" class="mc-btn primarybutton clsquickRedemption" data-value="100" style="background: #ff0000; color: #fff; padding: 8px 16px; border: none; border-radius: 5px; margin: 0 5px;">$100</button>
                </div>
            </div>

            <div class="transfer-content-right-pts">
                <h4 class="formatting_heading">
                    Select Amount to Redeem
                </h4>
                <form method="POST" class="transferPointForm btnRedeemCash">
                    <input type="hidden" name="action" value="submitCashBackRedemption">
                    <input type="hidden" name="contactID" value="<?php echo get_option('contactId'); ?>">
                    <input type="hidden" name="rewardProgramID" value="<?php echo get_option('rpId'); ?>">
                    <input type="hidden" name="webFormId" value="<?php echo get_option('webFormId'); ?>">

                    <div class="input-fields">
                        <div class="email-field">
                            <label style="display: flex; align-items: center; gap: 10px;">
                                <input type="radio" name="rdbCashback" value="Maximum" checked style="accent-color: red;">
                                <span style="margin: 0; font-weight: bold;">Maximum Cashback Amount</span>
                            </label>
                            <div class="pointsblock form-group maxamount" style="margin-top: 10px;">
                                <div class="number-display" style="font-size: 26px; font-weight: bold; color: #00bfff; background-color: #003b5c; padding: 10px 20px; border-radius: 8px;">$<span id="maxCashback">0.00</span></div>
                            </div>
                        </div>

                        <div class="transfer-field">
                            <label style="display: flex; align-items: center; gap: 10px;">
                                <input type="radio" name="rdbCashback" id="rdOther" value="Other" style="accent-color: red;">
                                <span style="margin: 0; font-weight: bold;">Other Cashback Amount</span>
                            </label>
                            <input type="text" name="cashbackAmount" class="form-control" id="txtTransferamount" placeholder="Enter amount" style="padding: 12px 16px; border: 1px solid #888; border-radius: 8px; width: 100%; background-color: #0d0d0d; color: #000;">
                        </div>
                    </div>
                    <div class="main-spinner" style="position: relative;">
                        <div id="spinner" class="spinner-container" style="display: none; text-align: center; margin: 15px 0;">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </div>
                    </div>

                    <div class="submit-button">
                        <button class="submit-button-anchor transferpoint" type="submit" style="background: rgb(255, 0, 0); padding: 10px 15px; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px;">
                            <span>Redeem Cashback</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
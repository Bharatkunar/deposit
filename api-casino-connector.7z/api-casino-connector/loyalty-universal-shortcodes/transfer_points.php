<section class="profile">
    <h3>Transfer Points</h3>
    <div class="transfer-container">
        <!-- Left: Points Widget -->
        <div class="left-section">
            <p class="text-center"><strong>Point Balance</strong></p>
            <div class="pointsblock">
                <span id="pointsBalance"><?php echo $pointBalance; ?></span> Points
            </div>
        </div>
        <!-- Right: Form Section -->
        <div class="right-section">
            <p class="text-center"><strong>Move My Points to</strong></p>
            <form method="POST" class='transferPointForm'>
                <input type="hidden" name="action" value="loyalty_transferpoints">
                <input type="hidden" name="contactID" value="<?php echo get_option('contactId'); ?>">
                <input type="hidden" name="rewardProgramID" value="<?php echo get_option('rpId'); ?>">
                <input type="hidden" name="webFormId" value="<?php echo get_option('webFormId'); ?>">

                <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-user"></i></span>
                        <input type="text" class="form-control" name="txtcontact" placeholder="<?php echo $txtIdPlaceholder; ?>" required>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-exchange"></i></span>
                        <input type="text" class="form-control" name="txtamount" placeholder="<?php echo $txtAmountPlaceholder; ?>" required>
                    </div>
                </div>
                <div id="spinner" class="spinner-container" style="display: none; text-align: center; margin-bottom: 10px;">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
                <button   type="submit" class="btn-transfer transferpoint"><?php echo $btnSubmitText; ?></button>
            </form>
        </div>
    </div>
</section>

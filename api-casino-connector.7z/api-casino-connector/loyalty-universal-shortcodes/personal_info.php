<style>
    /* Global font and background */
    body {
        font-family: 'Segoe UI', sans-serif;
        background-color: #0f1115;
        color: #fff;
        margin: 0;
        padding: 20px;
    }

    /* Form container */
    .WizForm-base.BasicInfo {
        background-color: #1a1d23;
        border-radius: 12px;
        padding: 30px;
        max-width: 960px;
        margin: auto;
        box-shadow: 0 0 12px rgba(0, 0, 0, 0.3);
    }

    /* Header section */
    .Balance_accountInfo__container_plate_header__Tq_7_ {
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid #2a2d36;
        padding-bottom: 20px;
        margin-bottom: 30px;
    }

    .Balance_header__containerLong__VaiOX {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .Balance_header__container_letter__i396R {
        background-color: #2a2d36;
        width: 40px;
        height: 40px;
        font-size: 20px;
        font-weight: bold;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .Balance_header__container_nameBlock__ULFG_ {
        display: flex;
        flex-direction: column;
    }

    .Balance_header__container_nameBlock_email__xc2JN {
        font-size: 14px;
        color: #ccc;
    }

    .Balance_header__container_nameBlock_username__2T5bP {
        font-size: 13px;
        color: #777;
    }

    /* Edit button */
    .WizIconButton_base__JfGpY {
        background-color: transparent;
        border: 1px solid #8cc63f;
        border-radius: 6px;
        padding: 6px;
        cursor: pointer;
        transition: background 0.3s;
    }

    .WizIconButton_base__JfGpY:hover {
        background-color: #8cc63f22;
    }

    /* Section titles */
    .Balance_accountInfo__container_plate_section_title__3Fpii {
        font-size: 16px;
        font-weight: 600;
        margin-bottom: 16px;
        color: #fff;
    }

    /* Grid layout variations */
    .Balance_tripleGrid__WltWq {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
    }

    .Balance_doubleGrid__q9P_C {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
    }

    .Balance_singleGrid__YcOlp {
        display: grid;
        grid-template-columns: 1fr;
        gap: 20px;
    }

    /* Input wrappers */
    .WizInput_base__2JTUy {
        display: flex;
        flex-direction: column;
        min-width: 100px !important;
    }

    .WizInput_base__2JTUy label {
        font-size: 13px;
        color: #aaa;
        margin-bottom: 6px;
    }

    .WizInput_base__2JTUy input {
        padding: 10px 12px;
        border-radius: 6px;
        background-color: #2a2d36;
        border: 1px solid #444;
        color: #ccc;
        font-size: 14px;
    }

    .WizInput_base__2JTUy input[disabled],
    .WizInput_base__2JTUy input:disabled {
        background-color: #23262f;
        color: #777;
        cursor: not-allowed;
    }

    /* Select input styling */
    .WizSelect_base__imfD7 {
        position: relative;
    }

    .WizSelect-input input {
        background-color: #23262f;
        color: #777;
        border: 1px solid #444;
        cursor: not-allowed;
    }

    .WizSelect_arrowIcon__ULWa9 {
        position: absolute;
        right: 12px;
        top: 36px;
        pointer-events: none;
    }

    /* Date picker wrapper */
    .WizDatePickerInputs_container__2VQpR {
        display: flex;
        gap: 20px;
    }

    .WizDatePickerInputs_container__2VQpR>div {
        flex: 1;
    }

    /* Responsive */
    @media (max-width: 1024px) {
        .Balance_tripleGrid__WltWq {
            grid-template-columns: 1fr 1fr;
        }
    }

    @media (max-width: 768px) {

        .Balance_tripleGrid__WltWq,
        .Balance_doubleGrid__q9P_C {
            grid-template-columns: 1fr;
        }

        .Balance_accountInfo__container_plate_header__Tq_7_ {
            flex-direction: column;
            align-items: flex-start;
            gap: 12px;
        }
    }
</style>
<form class="WizForm-base BasicInfo">
    <div class="Balance_accountInfo__container_plate__ouP8V">
        <div class="Balance_accountInfo__container_plate_header__Tq_7_">
            <div class="Balance_header__containerLong__VaiOX">
                <p class="Balance_header__container_letter__i396R">i</p>
                <div class="Balance_header__container_nameBlock__ULFG_">
                    <p class="Balance_header__container_nameBlock_email__xc2JN">abdulmaroof59@gmail.com</p>
                    <p class="Balance_header__container_nameBlock_username__2T5bP">@abdul</p>
                </div>
            </div>
            <div class="Balance_header__container__3hFuv Balance_buttonSection__i2hgq"><button type="button" class="WizIconButton_base__JfGpY WizIconButton_primary-outlined___S2ib">
                    <div class="WizIconButton_children__Xqp6z"><svg width="17" height="16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="m2.1 14.107 3.752-.883 8.203-8.203a.883.883 0 0 0 0-1.249l-1.62-1.62a.883.883 0 0 0-1.249 0l-8.203 8.203-.883 3.752Z" fill="#fff" stroke="#fff" stroke-width="1.5" stroke-linecap="round"></path>
                            <path d="M14.9 14.107h-4.855" stroke="#fff" stroke-width="1.5" stroke-linecap="square" stroke-linejoin="round"></path>
                        </svg></div><span class="WizRipple-wrapper"></span>
                </button></div>
        </div>
        <div class="Balance_accountInfo__container_plate_section__EWaJg">
            <div class="Balance_accountInfo__container_plate_section_title__3Fpii">Personal Details</div>
            <div class="Balance_accountInfo__container_plate_section_inner__DHAHa Balance_tripleGrid__WltWq">
                <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_WizDisabled__qNV_I"><label for="firstName">First Name</label><input type="text" name="firstName" id="firstName" disabled=""></div>
                <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_WizDisabled__qNV_I"><label for="lastName">Last Name</label><input type="text" name="lastName" id="lastName" disabled=""></div>
                <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_WizDisabled__qNV_I WizInput_WizHasValue__B66EX"><label for="nickName">Username</label><input type="text" name="nickName" id="nickName" disabled=""></div>
                <div class="WizDatePickerInputs_wrapper__pOusD">
                    <div class="WizDatePickerInputs_title__rHElD"></div>
                    <div class="WizDatePickerInputs_container__2VQpR WizDatePickerInputs_US__i9zkq">
                        <div class="WizSelect_base__imfD7 WizSelect_base__imfD7">
                            <div>
                                <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_end__A97st WizInput_WizDisabled__qNV_I WizSelect-input"><label for="month">Month</label><input type="text" name="month" id="month" readonly="" disabled="" value=""></div>
                                <div class="WizSelect_arrowIcon__ULWa9"><svg viewBox="0 0 22 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M21 12 11 2 1 12" stroke="#fff" stroke-width="2" stroke-linecap="round"></path>
                                    </svg></div>
                            </div>
                        </div>
                        <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_WizDisabled__qNV_I"><label for="day">Day</label><input type="text" name="day" id="day" max="4" min="1" maxlength="2" disabled=""></div>
                        <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_WizDisabled__qNV_I"><label for="year">Year</label><input type="text" name="year" id="year" maxlength="4" minlength="4" disabled=""></div>
                    </div>
                    <div class="WizDatePickerInputs_errorText__TfaS3"></div>
                </div>
                <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_WizDisabled__qNV_I WizInput_WizHasValue__B66EX"><label for="phone">Phone</label><input type="text" name="phone" id="phone" disabled=""></div>
            </div>
        </div>
        <div class="Balance_accountInfo__container_plate_section__EWaJg">
            <div class="Balance_accountInfo__container_plate_section_title__3Fpii">Email</div>
            <div class="Balance_accountInfo__container_plate_section_inner__DHAHa Balance_singleGrid__YcOlp">
                <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_WizDisabled__qNV_I WizInput_WizHasValue__B66EX"><label for="email">Email</label><input type="email" name="email" id="email" disabled=""></div>
            </div>
        </div>
        <div class="Balance_accountInfo__container_plate_section__EWaJg">
            <div class="Balance_accountInfo__container_plate_section_title__3Fpii">Address</div>
            <div class="Balance_accountInfo__container_plate_section_inner__DHAHa Balance_doubleGrid__q9P_C">
                <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_WizDisabled__qNV_I"><label for="street">Full Address</label><input type="text" name="street" id="street" disabled=""></div>
                <div class="WizSelect_base__imfD7 WizSelect_base__imfD7">
                    <div>
                        <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_end__A97st WizInput_WizDisabled__qNV_I WizSelect-input"><label for="addressCountryAlfa2">Country</label><input type="text" name="addressCountryAlfa2" id="addressCountryAlfa2" readonly="" disabled="" value=""></div>
                    </div>
                </div>
                <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_WizDisabled__qNV_I"><label for="city">City/State</label><input type="text" name="city" id="city" disabled=""></div>
                <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_WizDisabled__qNV_I"><label for="zipCode">Zip Code</label><input type="text" name="zipCode" id="zipCode" disabled="" value=""></div>
            </div>
        </div>
    </div>
</form>
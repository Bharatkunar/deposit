<style>
    .WizContentBlockWithTabs_container__WqdWL {
        max-width: 960px;
        margin: 0 auto;
    }

    .DashboardHeader_container__O3XdE h2 {
        font-size: 24px;
        margin-bottom: 20px;
        color: white;
    }

    .WizTabs_Tabs_container__71yxF button {
        background-color: #1a1f24;
        color: white;
        border: none;
        padding: 12px 24px;
        font-size: 16px;
        border-radius: 10px;
        cursor: pointer;
        margin-bottom: 24px;
    }

    .WizTabs_Tabs_container__71yxF button.active {
        background-color: #009b4d;
    }

    form.WizForm-base {
        display: flex;
        flex-direction: column;
        gap: 40px;
    }

    .Balance_accountInfo__container_plate_section__EWaJg {
        background-color: #1a1f24;
        border-radius: 12px;
        padding: 24px;
    }

    .Balance_accountInfo__container_plate_section_title__3Fpii {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 20px;
        color: white;
    }

    .Balance_tripleGrid__WltWq,
    .Balance_singleGrid__YcOlp,
    .Balance_doubleGrid__q9P_C {
        display: grid;
        gap: 16px;
    }

    .Balance_tripleGrid__WltWq {
        grid-template-columns: repeat(3, 1fr);
    }

    .Balance_doubleGrid__q9P_C {
        grid-template-columns: repeat(2, 1fr);
    }

    .Balance_singleGrid__YcOlp {
        grid-template-columns: 1fr;
    }

    .WizInput_base__2JTUy {
        display: flex;
        flex-direction: column;
    }

    .WizInput_base__2JTUy label {
        color: #999;
        margin-bottom: 4px;
        font-size: 14px;
    }

    .WizInput_base__2JTUy input {
        padding: 10px 12px;
        background-color: #111418;
        border: 1px solid #333;
        border-radius: 8px;
        color: white;
        font-size: 14px;
    }

    .WizInput_base__2JTUy input:disabled {
        background-color: #222;
        cursor: not-allowed;
    }

    .WizSelect-input {
        position: relative;
    }

    .WizSelect_arrowIcon__ULWa9 {
        position: absolute;
        right: 12px;
        top: 50%;
        transform: translateY(-50%);
        pointer-events: none;
    }

    .WizButton_base__ojkNL {
        border: none;
        font-size: 16px;
        font-weight: 600;
        border-radius: 10px;
        padding: 14px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .WizButton_primary-contained__xOImR {
        background-color: #009b4d;
        color: white;
        width: 100%;
    }

    .Balance_accountInfo__container_support__4PhBs {
        margin-top: 24px;
        display: flex;
        justify-content: center;
    }

    .WizButton_transparent-outlined__61Zg2 {
        background: transparent;
        border: 1px solid #009b4d;
        color: #009b4d;
    }

    .WizButton_icon-start__2W9lI svg {
        margin-right: 8px;
    }
</style>
<div class="WizContentBlockWithTabs_container__WqdWL WizContentBlockWithTabs_wrapper__Rhs0S">
    <div class="DashboardHeader_container__O3XdE">
        <div class="DashboardHeader_container__info__KJGjL">
            <div class="DashboardHeader_container__title__Znps1">
                <h2>Verification </h2>
            </div>
        </div>
    </div>
    <div class="WizContentBlockWithTabs_container_tabs__wg6PU">
        <div class="WizTabs_Tabs_container__71yxF" data-wrap-type="default">
            <div class="WizTabs_Tabs_container__inner__p3Mlp"><button class="WizButton_base__ojkNL WizButton_light-text__F8_ve WizButton_M__VKPt3 WizButton_WizActive__Ta0Pt active" type="button"><span class="WizButton_text__oCBg0">Personal Details</span><span class="WizRipple-wrapper"></span></button></div>
        </div>
    </div>
    <form class="WizForm-base BasicInfo">
        <div class="Balance_accountInfo__container_plate__ouP8V">
            <div class="Balance_accountInfo__container_plate_section__EWaJg">
                <div class="Balance_accountInfo__container_plate_section_title__3Fpii">Personal Details</div>
                <div class="Balance_accountInfo__container_plate_section_inner__DHAHa Balance_tripleGrid__WltWq">
                    <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc"><label for="firstName">First Name</label><input type="text" name="firstName" id="firstName"></div>
                    <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc"><label for="lastName">Last Name</label><input type="text" name="lastName" id="lastName"></div>
                    <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_WizHasValue__B66EX"><label for="nickName">Username</label><input type="text" name="nickName" id="nickName"></div>
                    <div class="WizDatePickerInputs_wrapper__pOusD">
                        <div class="WizDatePickerInputs_title__rHElD"></div>
                        <div class="WizDatePickerInputs_container__2VQpR WizDatePickerInputs_US__i9zkq">
                            <div class="WizSelect_base__imfD7 WizSelect_base__imfD7">
                                <div>
                                    <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_end__A97st WizSelect-input"><label for="month">Month</label><input type="text" name="month" id="month" readonly="" value=""></div>
                                    <div class="WizSelect_arrowIcon__ULWa9"><svg viewBox="0 0 22 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M21 12 11 2 1 12" stroke="#fff" stroke-width="2" stroke-linecap="round"></path>
                                        </svg></div>
                                </div>
                            </div>
                            <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc"><label for="day">Day</label><input type="text" name="day" id="day" max="4" min="1" maxlength="2"></div>
                            <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc"><label for="year">Year</label><input type="text" name="year" id="year" maxlength="4" minlength="4"></div>
                        </div>
                        <div class="WizDatePickerInputs_errorText__TfaS3"></div>
                    </div>
                    <div style="display: grid; grid-template-columns: 105px 1fr; gap: 8px;">
                        <div class="WizSelect_base__imfD7 WizSelect_phone__3MgwN">
                            <div>
                                <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_start__nx_ve WizInput_WizHasValue__B66EX WizSelect-input"><label for="phoneCode">Code</label><input type="text" name="phoneCode" id="phoneCode" readonly="" selectcomponentprops="[object Object]" value="+92"><img src="https://wgaming-cdn.com/icons/country/square/PK.svg" alt=""></div>
                            </div>
                        </div>
                        <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_WizHasValue__B66EX"><label for="phoneNumber">Phone number</label><input type="text" name="phoneNumber" id="phoneNumber" inputmode="numeric" pattern="[0-9]*"></div>
                    </div>
                </div>
            </div>
            <div class="Balance_accountInfo__container_plate_section__EWaJg">
                <div class="Balance_accountInfo__container_plate_section_title__3Fpii">Email</div>
                <div class="Balance_accountInfo__container_plate_section_inner__DHAHa Balance_singleGrid__YcOlp">
                    <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_WizDisabled__qNV_I WizInput_WizHasValue__B66EX"><label for="email">Email</label><input type="email" name="email" id="email" disabled=""></div>
                </div>
            </div>
            <div class="Balance_accountInfo__container_plate_section__EWaJg">
                <div class="Balance_accountInfo__container_plate_section_title__3Fpii">Address</div>
                <div class="Balance_accountInfo__container_plate_section_inner__DHAHa Balance_doubleGrid__q9P_C">
                    <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc"><label for="street">Full Address</label><input type="text" name="street" id="street"></div>
                    <div class="WizSelect_base__imfD7 WizSelect_base__imfD7">
                        <div>
                            <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc WizInput_end__A97st WizSelect-input"><label for="addressCountryAlfa2">Country</label><input type="text" name="addressCountryAlfa2" id="addressCountryAlfa2" readonly="" value=""></div>
                        </div>
                    </div>
                    <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc"><label for="city">City/State</label><input type="text" name="city" id="city"></div>
                    <div class="WizInput_base__2JTUy WizInput_primary__y5z9_ WizInput_L__igAxc"><label for="zipCode">Zip Code</label><input type="text" name="zipCode" id="zipCode" value=""></div>
                </div>
            </div>
        </div><button class="WizButton_base__ojkNL WizButton_primary-contained__xOImR WizButton_L__UZfj4 WizButton_WizFullWidth__DvHSM Balance_btn__next__gckAS" type="submit"><span class="WizButton_text__oCBg0">Next</span><span class="WizRipple-wrapper"></span></button>
    </form>
    <div class="Balance_accountInfo__container_support__4PhBs"><button class="WizButton_base__ojkNL WizButton_transparent-outlined__61Zg2 WizButton_L__UZfj4 WizButton_icon-start__2W9lI" type="button"><svg width="18" height="18" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M7.819 1.06a2.497 2.497 0 0 1 2.27-.072l.142.072 5.081 2.997.072.047.069.058.08.056a2.416 2.416 0 0 1 .95 1.641l.013.151.004.153v5.463c0 .83-.427 1.597-1.09 2.02l-.128.075-5.102 3.227a2.458 2.458 0 0 1-2.253.05l-.147-.074-5.022-3.178a2.422 2.422 0 0 1-1.253-1.964l-.005-.155V6.162c0-.83.427-1.596 1.107-2.029L7.819 1.06ZM9 11.25a.75.75 0 0 0-.745.662L8.25 12l.005.095a.75.75 0 0 0 1.49 0l.005-.088-.005-.095A.75.75 0 0 0 9 11.25Zm1.027-5.908a2.235 2.235 0 0 0-2.723.546.75.75 0 0 0 1.08 1.037l.128-.135a.735.735 0 0 1 .832-.112.75.75 0 0 1 .333.335c.072.144.096.792.066 1.37a.75.75 0 0 1-.655.612l-.173.01a.75.75 0 0 0 .083 1.495 2.25 2.25 0 0 0 2.194-1.721c.12-.911.069-1.913-.143-2.373a2.25 2.25 0 0 0-1.022-1.064Z" fill="currentColor"></path>
            </svg><span class="WizButton_text__oCBg0">Support</span><span class="WizRipple-wrapper"></span></button></div>
</div>
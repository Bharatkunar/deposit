<style>
    .leaderboard-white-block-html {
        background-color: white;
        max-width: 1200px;
        margin: auto;
        padding: 20px;
        margin-top: 10px;
    }

    .leaderboard-white-block-html .leaderboard-main-div {
        margin-bottom: 20px
    }

    .leaderboard-white-block-html .leaderboard-main-div tr th {
        font-weight: 600 !important;
        color: #333 !important;
        font-size: 14px;
        padding-top: 30px !important;
        padding-bottom: 10px !important;
    }

    .leaderboard-white-block-html .leaderboard-main-div tr td {
        padding-right: 10px;
    }

    .leaderboard-white-block-html .leaderboard-main-div select {
        background-color: white;
        height: 34px;
        padding: 6px 12px;
        font-size: 14px;
        width: 100%;
        color: #555;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .leaderboard-white-block-html .leaderboard-main-div input {
        background-color: white;
        height: 34px;
        padding: 6px 12px;
        font-size: 14px;
        color: #555;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .leaderboard-white-block-html .leaderboard-main-div .potential-content {
        display: block;
        width: 100% !important;
        text-align: center;
        border: 1px solid #1dc9b8;
        color: #1dc9b8;
        font-weight: bold;
        font-size: 18px;
        height: 34px;
        border-radius: 5px !important;
    }

    .leaderboard-white-block-html .leaderboard-main-div .checkin-content {
        display: block;
        width: 100% !important;
        text-align: center;
        border: 1px solid rgb(253, 57, 122);
        color: rgb(253, 57, 122);
        font-weight: bold;
        font-size: 18px;
        height: 34px;
        border-radius: 5px !important;
    }

    .leaderboard-white-block-html .leaderboard-main-div .refferal-content {
        display: block;
        width: 100% !important;
        text-align: center;
        border: 1px solid rgb(253, 57, 122);
        color: rgb(253, 57, 122);
        font-weight: bold;
        font-size: 18px;
        height: 34px;
        border-radius: 5px !important;
    }

    .leaderboard-white-block-html tr.heading-transaction-history {
        background-color: rgba(238, 96, 89) !important;
    }

    .leaderboard-white-block-html .transaction-history-table-column tr td {
        border-color: white !important;
        border-bottom: 1px solid lightgrey !important;
        padding: 5px !important;
        padding-left: 8px !important;
        padding-right: 8px !important;
    }

    .leaderboard-white-block-html tr.heading-transaction-history span {
        color: white;
    }

    .leaderboard-white-block-html .transaction-history-table-column span.icon-sorting {
        height: 30px !important;
    }

    .leaderboard-white-block-html .transaction-history-table-column span.icon-sorting {
        display: flex;
        justify-content: right;
        margin-top: -30px;
    }

    .leaderboard-white-block-html span.player-content img {
        width: 40px;
        height: 40px;
        object-fit: cover;
        border-radius: 10px;
    }

    .leaderboard-white-block-html .transaction-history-table-column tbody tr:nth-child(odd) {
        background-color: #f9f9f9;
    }

    .leaderboard-white-block-html td.rank-content {
        color: black;
    }

    .leaderboard-white-block-html td {
        border-color: white !important;
        border-bottom: 1px solid lightgrey !important;
        padding: 5px !important;
        padding-left: 8px !important;
        padding-right: 8px !important;
    }

    .leaderboard-white-block-html span.player-content {
        display: flex;
    }

    .leaderboard-white-block-html .playername a {
        color: #666;
        font-size: 14px;
        padding-left: 10px;
        font-weight: 600;
    }

    .leaderboard-white-block-html span.leaderboard-score {
        padding: 4px 20px;
        border-radius: 8px;
        width: 51px;
        font-weight: bold;
        text-align: center;
        color: white;
        background-color: rgba(238, 96, 89) !important;
    }

    .leaderboard-white-block-html td.checkin-content {
        color: black;
    }

    .leaderboard-white-block-html td.referral-content {
        color: black;
    }

    .leaderboard-white-block-html tr.heading-transaction-history td span:nth-child(1) {
        padding-right: 20px !important
    }

    .leaderboard-white-block-html .leaderboard-main-div tr td {
        border-bottom: 0px !important
    }

    .leaderboard-pagination-block {
        display: flex;
        justify-content: space-between;
        padding-top: 10px;
    }

    .leaderboard-pagination-block .showing-filter span.text-format {
        font-size: 14px !important;
        padding-left: 10px;
        color: #666;
        padding-right: 10px;
    }

    .leaderboard-pagination-block select {
        height: 30px !important;
        background-color: #f8f8f8 !important;
        color: #666;
        border: 1px solid #ccc;
        border-radius: 5px;
        width: 100px;
    }

    .leaderboard-pagination-block div {
        align-self: center;
    }

    .leaderboard-pagination-block .history-right-bar-content input {
        color: rgba(238, 96, 89) !important;
        width: max-content !important;
        padding-left: 10px;
        padding-right: 10px;
        border: 1px solid #ccc !important;
    }

    tr.heading-transaction-history td {
        background: rgba(238, 96, 89) !important;
        color: #fff;
    }
</style>
<div class="leaderboard-section ">
    <!-- Spinner (Shows while loading data) -->
    <div class="spinner-container" id="spinner">
        <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>

    <!-- Table -->
    <div class="table-1 transaction-history-table-column">
        <table class="transaction-table table" id="freePlayVisit">
            <thead class=" leaderboard-white-block-html">
                <tr class="heading-transaction-history">
                    <td class="date-icon">Location</td>
                    <td class="date-icon">Visit Counts</td>
                </tr>
            </thead>
            <tbody id="freePlayVisitTable">
                <!-- Data will be inserted dynamically -->
            </tbody>
        </table>
    </div>
</div>
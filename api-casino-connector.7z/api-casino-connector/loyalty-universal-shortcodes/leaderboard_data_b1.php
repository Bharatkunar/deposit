<style>
    .leaderboard-white-block-html {
        background-color: white;
        /* max-width: 1200px; */
        margin: auto;
        padding: 20px;
        margin-top: 10px;
        width: 100%;
    }

    .leaderboard-white-block-html .leaderboard-main-div {
        margin-bottom: 20px
    }

    .leaderboard-white-block-html .leaderboard-main-div tr th {
        font-weight: 600 !important;
        color: #333 !important;
        font-size: 14px;
        padding-top: 30px !important;
        padding-bottom: 10px !important;
    }

    .leaderboard-white-block-html .leaderboard-main-div tr td {
        padding-right: 10px;
    }

    .leaderboard-white-block-html .leaderboard-main-div select {
        background-color: white;
        height: 34px;
        padding: 6px 12px;
        font-size: 14px;
        width: 100%;
        color: #555;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .leaderboard-white-block-html .leaderboard-main-div input {
        background-color: white;
        height: 34px;
        padding: 6px 12px;
        font-size: 14px;
        color: #555;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .leaderboard-white-block-html .leaderboard-main-div .potential-content {
        display: block;
        width: 100% !important;
        text-align: center;
        border: 1px solid #1dc9b8;
        color: #1dc9b8;
        font-weight: bold;
        font-size: 18px;
        height: 34px;
        border-radius: 5px !important;
    }

    .leaderboard-white-block-html .leaderboard-main-div .checkin-content {
        display: block;
        width: 100% !important;
        text-align: center;
        border: 1px solid rgb(253, 57, 122);
        color: rgb(253, 57, 122);
        font-weight: bold;
        font-size: 18px;
        height: 34px;
        border-radius: 5px !important;
    }

    .leaderboard-white-block-html .leaderboard-main-div .refferal-content {
        display: block;
        width: 100% !important;
        text-align: center;
        border: 1px solid rgb(253, 57, 122);
        color: rgb(253, 57, 122);
        font-weight: bold;
        font-size: 18px;
        height: 34px;
        border-radius: 5px !important;
    }

    .leaderboard-white-block-html tr.heading-transaction-history {
        background-color: rgba(238, 96, 89) !important;
    }

    .leaderboard-white-block-html .transaction-history-table-column tr td {
        border-color: white !important;
        border-bottom: 1px solid lightgrey !important;
        padding: 5px !important;
        padding-left: 8px !important;
        padding-right: 8px !important;
    }

    .leaderboard-white-block-html tr.heading-transaction-history span {
        color: white;
    }

    .leaderboard-white-block-html .transaction-history-table-column span.icon-sorting {
        height: 30px !important;
    }

    .leaderboard-white-block-html .transaction-history-table-column span.icon-sorting {
        display: flex;
        justify-content: right;
        margin-top: -30px;
    }

    .leaderboard-white-block-html span.player-content img {
        width: 40px;
        height: 40px;
        object-fit: cover;
        border-radius: 10px;
    }

    .leaderboard-white-block-html .transaction-history-table-column tbody tr:nth-child(odd) {
        background-color: #f9f9f9;
    }

    .leaderboard-white-block-html td.rank-content {
        color: black;
    }

    .leaderboard-white-block-html td {
        border-color: white !important;
        border-bottom: 1px solid lightgrey !important;
        padding: 5px !important;
        padding-left: 8px !important;
        padding-right: 8px !important;
    }

    .leaderboard-white-block-html span.player-content {
        display: flex;
    }

    .leaderboard-white-block-html .playername a {
        color: #666;
        font-size: 14px;
        padding-left: 10px;
        font-weight: 600;
    }

    .leaderboard-white-block-html span.leaderboard-score {
        padding: 4px 20px;
        border-radius: 8px;
        width: 51px;
        font-weight: bold;
        text-align: center;
        color: white;
        background-color: rgba(238, 96, 89) !important;
    }

    .leaderboard-white-block-html td.checkin-content {
        color: black;
    }

    .leaderboard-white-block-html td.referral-content {
        color: black;
    }

    .leaderboard-white-block-html tr.heading-transaction-history td span:nth-child(1) {
        padding-right: 20px !important
    }

    .leaderboard-white-block-html .leaderboard-main-div tr td {
        border-bottom: 0px !important
    }

    .leaderboard-pagination-block {
        display: flex;
        justify-content: space-between;
        padding-top: 10px;
    }

    .leaderboard-pagination-block .showing-filter span.text-format {
        font-size: 14px !important;
        padding-left: 10px;
        color: #666;
        padding-right: 10px;
    }

    .leaderboard-pagination-block select {
        height: 30px !important;
        background-color: #f8f8f8 !important;
        color: #666;
        border: 1px solid #ccc;
        border-radius: 5px;
        width: 100px;
    }

    .leaderboard-pagination-block div {
        align-self: center;
    }

    .leaderboard-pagination-block .history-right-bar-content input {
        color: rgba(238, 96, 89) !important;
        width: max-content !important;
        padding-left: 10px;
        padding-right: 10px;
        border: 1px solid #ccc !important;
    }

    .spinner-container-new {
        text-align: center;
        color: red !important;
        position: relative;
        top: 30%;
        left: 0%;
    }

    .main-content-spinner {
        position: fixed;
        top: 0;
        left: 0;
        z-index: 9999;
        width: 100vw;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: rgba(255, 255, 255, 0.7); /* semi-transparent overlay */
    }

    .spinner-overlay {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100%;
    }

</style>
<div class="heading-block-all">
    <div class="heading-block-text">
        <p class="paragraph-text">Leaderboard Competition</p>
    </div>
</div>
<div class="leaderboard-white-block-html">
    <div class="leaderboard-main-div">
        <table width="100%">
            <tbody>
                <tr>
                    <th>Past Winners:</th>
                    <th>Players Name:</th>
                    <th>Potential Winners:</th>
                    <th>Check-Ins To Qualify:</th>
                    <th>Referrals To Qualify:</th>
                </tr>
                <tr>
                    <td><select id="yearFilter" class="form-select">
                            <option value="">Select Year</option>
                        </select>
                        <select id="monthFilter" class="form-select" style="display: none;">
                            <option value="">Select Month</option>
                        </select>
                    </td>
                    <td><input type="text" id="leaderboardSearch" placeholder="Search player name..." class="leaderboard-search-input" />
                    </td>
                    <td><span class="potential-content">5</span></td>
                    <td><span class="checkin-content">5</span></td>
                    <td><span class="refferal-content">1</span></td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="table-1 transaction-history-table-column">
        <table width="100%">
            <thead>
                <tr class="heading-transaction-history">
                    <td class="date-icon"><span class="table-content">Rank</span><br>
                        <span class="icon-sorting"><br>
                            <span class="exchange-icon">e</span><br>
                            <span class="down-sort-icon active">d</span><br>
                            <span class="up-sort-icon">u</span><br>
                        </span>
                    </td>
                    <td class="type-icon"><span class="table-content">Player</span><br>
                        <span class="icon-sorting"><br>
                            <span class="exchange-icon active">e</span><br>
                            <span class="down-sort-icon">d</span><br>
                            <span class="up-sort-icon">u</span><br>
                        </span>
                    </td>
                    <td class="status-icon"><span class="table-content">Score</span><br>
                        <span class="icon-sorting"><br>
                            <span class="exchange-icon active">e</span><br>
                            <span class="down-sort-icon">d</span><br>
                            <span class="up-sort-icon">u</span><br>
                        </span>
                    </td>
                    <td class="points-icon"><span class="table-content">Check-Ins</span><br>
                        <span class="icon-sorting"><br>
                            <span class="exchange-icon active">e</span><br>
                            <span class="down-sort-icon">d</span><br>
                            <span class="up-sort-icon">u</span><br>
                        </span>
                    </td>
                    <td class="balance-icon"><span class="table-content">Referrals</span><br>
                        <span class="icon-sorting"><br>
                            <span class="exchange-icon active">e</span><br>
                            <span class="down-sort-icon">d</span><br>
                            <span class="up-sort-icon">u</span><br>
                        </span>
                    </td>
                </tr>
            </thead>
            <tbody id="leaderboard">
                <div class="main-spinner" style="position: relative;">
                    <div id="spinner" class="spinner-container-new" style="display: none; text-align: center; margin-bottom: 10px;">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                </div>
            </tbody>
        </table>
    </div>
    <div class="leaderboard-pagination-block">
        <div class="history-left-bar-content">
            <div class="showing-filter">
                <span class="text-format">Show</span>
                <select id="entriesPerPage">
                    <option value="10">10</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                </select>
                <span class="text-format">entries</span>
            </div>

        </div>
        <div class="history-middle-bar-content">
            <div class="showing-filter"><span class="text-format">Showing 1 to 1 of 1 entries</span></div>
        </div>
        <div class="history-right-bar-content">
            <div class="showing-filter-padination"><input type="button" value="Previous" id="prevPage"><input type="button" value="Next" id="nextPage"></div>
        </div>
    </div>
</div>

<script>
let currentPage = 1;

function fetchLeaderboardData() {
    const year = $('#yearFilter').val();
    const month = $('#monthFilter').val();
    const search = $('#leaderboardSearch').val();
    const entriesPerPage = $('#entriesPerPage').val();

    $('#spinner').show();
    $('#leaderboard').html('');

    $.ajax({
        url: ajax_object.ajax_url,
        method: 'POST',
        dataType: 'json',
        data: {
            "action": "getLeaderBoard",
            "year": year,
            "month": month
        },
        success: function (response) {
            console.log('leaderboard data');
            $('#spinner').hide();
            $('#leaderboard').empty();
            if (response.leaderBoardReport?.leaderBoardlst && response.leaderBoardReport.leaderBoardlst.length > 0) {
                response.leaderBoardReport.leaderBoardlst.forEach(item => {
                    $('#leaderboard').append(`
                        <tr>
                            <td>${item?.rank}</td>
                            <td class="playerdetail-content">
                                <span class="player-content"><br>
							    <span class="profilepic"><img class=" lazyloaded" decoding="async" src="${item?.profilePitcure}" data-orig-src="${item?.profilePitcure}"></span><br>
							    <span class="playername"><a class="primary-link1" contenteditable="false" style="cursor: pointer;">${item?.fullName}</a></span><br>
							    </span>
                            </td>
                            <td>${item?.totalPoints}</td>
                            <td>${item?.totalCheckins}</td>
                            <td>${item?.totalReferals}</td>
                        </tr>
                    `);
                });

                $('#paginationInfo').text(`Showing ${(currentPage - 1) * entriesPerPage + 1} to ${Math.min(currentPage * entriesPerPage, response.total)} of ${response.total} entries`);
            } else {
                $('#leaderboard').append('<tr><td colspan="5">No data found.</td></tr>');
                $('#paginationInfo').text('Showing 0 to 0 of 0 entries');
            }
        },
        error: function () {
            $('#spinner').hide();
            $('#leaderboard').html('<tr><td colspan="5">Error loading data</td></tr>');
        }
    });
}

function populateFilters() {
    $.ajax({
        url: ajax_object.ajax_url,
        method: 'POST',
        dataType: 'json',
        data: {
            "action": "getLeaderBoard"
        },
        success: function (filters) {
          $('#spinner').hide();
          

          allFilters = filters.filters || [];

          const yearFilter = $('#yearFilter');
          const monthFilter = $('#monthFilter');
          yearFilter.empty().append('<option value="">Select Year</option>');
          monthFilter.empty().append('<option value="">Select Month</option>').hide();

          let years = [...new Set(allFilters.map(f => f.year))];
          years.forEach(year => {
            yearFilter.append(`<option value="${year}">${year}</option>`);
          });

          yearFilter.off('change').on('change', function () {
            const selectedYear = $(this).val();
            monthFilter.empty().append('<option value="">Select Month</option>').hide();

            const months = allFilters.filter(f => f.year == selectedYear);
            if (months.length > 0) {
              monthFilter.show();
              months.forEach(month => {
                monthFilter.append(`<option value="${month.month}">${month.display}</option>`);
              });
            }

            currentPage = 1;
            $('#leaderboard').html('<tr><td colspan="5">Please select a month.</td></tr>');
            $('#paginationInfo').text('');
          });

          monthFilter.off('change').on('change', function () {
            currentPage = 1;
            fetchLeaderboardData();
          });
        }
    });
}

// Event Listeners
$('#leaderboardSearch').on('input', function () {
    currentPage = 1;
    fetchLeaderboardData();
});
$('#entriesPerPage').on('change', function () {
    currentPage = 1;
    fetchLeaderboardData();
});
$('#prevPage').on('click', function () {
    if (currentPage > 1) {
        currentPage--;
        fetchLeaderboardData();
    }
});
$('#nextPage').on('click', function () {
    currentPage++;
    fetchLeaderboardData();
});

// Init
$(document).ready(function () {
    populateFilters();
    fetchLeaderboardData();
});
</script>

// // let allEgiftOfferData = [];
// // let currentPage = 1;
// // let leaderboardEntriesToShow = 10;
// // let allTransactionData = []; // To store full transaction history
// // let transactionData = [];
// // let transactionEntriesToShow = 10;
// // let transactionCurrentPage = 1;

// // document.addEventListener('DOMContentLoaded', function () {
// //     document.addEventListener('click', function (e) {
// //         if (e.target.classList.contains('showing-details')) {
// //             const row = e.target.closest('tr');
// //             const detailRow = row.nextElementSibling;

// //             // Show detail row
// //             detailRow.style.display = 'table-row';

// //             // Toggle icons
// //             e.target.style.display = 'none';
// //             row.querySelector('.hide-content').style.display = 'inline';
// //         }

// //         if (e.target.classList.contains('hide-content')) {
// //             const row = e.target.closest('tr');
// //             const detailRow = row.nextElementSibling;

// //             // Hide detail row
// //             detailRow.style.display = 'none';

// //             // Toggle icons
// //             e.target.style.display = 'none';
// //             row.querySelector('.showing-details').style.display = 'inline';
// //         }
// //     });
// // });

// // function showAllClicked(checkbox) {
// //     if (checkbox.checked) {
// //         // Uncheck all category filters
// //         $('.category-filter').prop('checked', false);

// //         // Show all data
// //         renderEgiftOffers(allEgiftOfferData);
// //     }
// // }


// // function clickedCategory(checkbox) {
// //     $('#showAllCheckbox').prop('checked', false); // Uncheck "Show All"

// //     const selectedCategories = $('.category-filter:checked').map(function () {
// //         return $(this).val();
// //     }).get();

// //     const filteredData = selectedCategories.length === 0
// //         ? allEgiftOfferData
// //         : allEgiftOfferData.filter(item =>
// //             selectedCategories.includes(item.offerData?.tangoCategoryId)
// //         );

// //     renderEgiftOffers(filteredData);
// // }


// // function renderEgiftOffers(data) {


// //     let tableBody = $('#egift_offer_data');
// //     tableBody.empty();

// //     // if (data.contactDetails && typeof data.contactDetails.pointBalance !== 'undefined') {
// //     //     $('.wallet-balance .amount').text(`$${parseFloat(data.contactDetails.pointBalance).toFixed(2)}`);
// //     // }

// //     if (!data || data.length === 0) {
// //         tableBody.append('<tr><td colspan="5" class="text-center">No Data Available</td></tr>');
// //         return;
// //     }

// //     let htmlData = '';

// //     data.forEach((transaction) => {
// //         const offer = transaction.offerData;


// //         htmlData += `
// //             <div class="content-box-column" data-offer-id="${offer.offerID}">
// //                 <div class="product-with-image">
// //                     <p><img src="${offer.offerImageUrl}" alt="Offer Image"></p>
// //                     <div class="product-without-image">
// //                         <span class="product-name">${offer.offerTitle}</span><br>
// //                         <span class="">${offer.tangoCategoryName}</span>
// //                         </div>
// //                         </div>
// //                         </div>
// //                         `;
// //     });
// //     // <button type="submit" class="submit-button-anchor transferpoint redeem-btn" href="#" type="submit"><span>Redeem Now</span></button>

// //     tableBody.append(htmlData);
// // }



// // jQuery(document).ready(function ($) {
// //     const transferForm = $(".profile .transferPointForm");
// //     const btnRedeemCash = $(".profile .btnRedeemCash");
// //     const spinner = $("#spinner");
// //     freePlayVisits();

// //     //   // AJAX Request Handling

// //     jQuery(document).ready(function ($) {
// //         var btn = $(this);
// //         btn.addClass('loading');

// //         // Simulate a delay — remove this in your actual AJAX call
// //         setTimeout(function () {
// //             btn.removeClass('loading'); // Remove spinner after 3 seconds
// //         }, 3000);

// //         $('.form-submit').on('click', function (e) {
// //             e.preventDefault();

// //             const spinner = $("#spinner");
// //             // spinner.removeClass("d-none");
// //             spinner.show();

// //             var formElement = document.getElementById('profile-update-form'); // Your actual form ID
// //             var formData = new FormData(formElement);
// //             formData.append('action', 'handle_update_user_profile'); // Append action manually if not in the form

// //             $.ajax({
// //                 url: ajax_object.ajax_url,
// //                 type: "POST",
// //                 dataType: "json",
// //                 processData: false,
// //                 contentType: false,
// //                 data: formData,
// //                 success: function (response) {
// //                     console.log(response);
// //                     openModal(response.data.message, true);
// //                 },
// //                 error: function (error) {
// //                     openModal("Error submitting the form. Please try again.", true);
// //                 },
// //                 complete: function () {
// //                     // spinner.addClass("d-none");
// //                     spinner.hide();
// //                 }
// //             });
// //         });

// //     });

// //     $(document).on("submit", ".redeem-egiftoffer-form", function (e) {
// //         e.preventDefault(); // Prevent form refresh

// //         var form = $(this);
// //         console.log(form);

// //         var offerId = form.data("offer-id");
// //         alert(offerId);
// //         var button = form.find(".redeem-btn");
// //         // var spinner = form.find(".spinner");

// //         // const button = $(this);
// //         // const spinner = button.closest('.product-with-image').find('.spinner-container');

// //         // Show spinner
// //         // spinner.removeClass("d-none");
// //         // spinner.show();
// //         // spinner.removeClass("d-none");
// //         // button.prop("disabled", true);
// //         // spinner.css("display", "flex");
// //         const spinner = $("#spinner-" + offerId);
// //         console.log("spinner", spinner);
// //         debugger;

// //         // const spinnerMain = form.find(".spinner-container");
// //         spinner.show();



// //         $.ajax({
// //             url: ajax_object.ajax_url, // WordPress AJAX URL via localized script
// //             type: "POST",
// //             data: {
// //                 offerID: offerId,
// //                 isAllowFBBonusPoints: false,
// //                 fbBonusPoints: null,
// //                 action: "redeemEgiftOffer" // must match your PHP function hook
// //             },

// //             success: function (response) {
// //                 // Example: show success modal
// //                 openModal(response, true);
// //             },

// //             error: function () {
// //                 openModal("Error redeeming the offer here. Please try again.", true);
// //             },
// //             complete: function () {
// //                 // spinner.addClass("d-none"); // Hide spinner after request completes
// //                 spinner.hide();
// //                 // button.prop("disabled", false);
// //             }
// //         });
// //     });

// //     $(document).on('click', '.transfer-points-button', function (e) {
// //         e.preventDefault();

// //         var form = $('.fusion-form-6159');
// //         var formData = form.serialize();

// //         $.ajax({
// //             url: ajax_object.ajax_url,
// //             type: 'POST',
// //             data: formData,
// //             success: function (response) {
// //                 // Example: show success modal
// //                 openModal(response.data.message, true);
// //             },
// //             error: function () {
// //                 openModal("Error transferring points. Please try again.", true);
// //             },
// //             complete: function () {
// //                 spinner.addClass("d-none"); // Hide spinner after request completes
// //             }
// //         });
// //     });


// //     $(document).on("submit", ".redeem-offer-form", function (event) {
// //         event.preventDefault();

// //         const form = $(this);
// //         const button = form.find(".redeem-btn");
// //         const spinner = button.find(".spinner");
// //         const offerId = form.data("offer-id");

// //         // Disable button and show spinner
// //         button.prop("disabled", true).addClass("loading");
// //         spinner.show();

// //         $.ajax({
// //             url: ajax_object.ajax_url, // WP AJAX URL
// //             method: "POST",
// //             dataType: "json",
// //             data: {
// //                 action: "redeemOffer",
// //                 offer_id: offerId,
// //             },
// //             success: function (response) {
// //                 if (response.data && response.data.statusCode) {
// //                     openModal(response.data.statusMessage, true); // ✅ Success modal
// //                 } else {
// //                     openModal("Error: " + (response.data?.statusMessage || "Unknown error"), false); // ❌ Error modal
// //                 }
// //             },
// //             error: function (xhr, status, error) {
// //                 console.error("AJAX error:", error);
// //                 openModal(`AJAX error: ${error}`, false); // ❌ Error modal
// //             },
// //             complete: function () {
// //                 // Enable button and hide spinner after request completes
// //                 button.prop("disabled", false).removeClass("loading");
// //                 spinner.hide();
// //             },
// //         });
// //     });



// //     function sendAjaxRequest(formData) {
// //         $.ajax({
// //             url: ajax_object.ajax_url, // Use the localized AJAX URL
// //             method: "POST",
// //             dataType: "json",
// //             data: formData,
// //             beforeSend: function () {
// //                 spinner.show(); // Show the spinner
// //             },
// //             success: function (response) {
// //                 if (response.success && response.data.statusCode === 1) {
// //                     openModal(response.data.message, true); // Show success modal with ✅
// //                 } else {
// //                     openModal("Error: " + response.data.message, false); // Show error modal with ❌
// //                 }
// //             },
// //             error: function (xhr, status, error) {
// //                 openModal(`AJAX error: ${error} `, true); // Show success modal with ✅
// //             },
// //             complete: function () {
// //                 spinner.hide(); // Always hide the spinner
// //             },
// //         });
// //     }

// //     // Handle form submission
// //     if (transferForm.length) {
// //         transferForm.on("submit", function (event) {
// //             event.preventDefault(); // Prevent default form submission
// //             sendAjaxRequest(transferForm.serialize()); // Send AJAX request
// //         });
// //     }

// //     // Handle Redeem Cash button click
// //     if (btnRedeemCash.length) {
// //         btnRedeemCash.on("submit", function (event) {
// //             event.preventDefault();
// //             sendAjaxRequest(btnRedeemCash.serialize()); // Send AJAX request
// //         });
// //     }
// //     // Fetch Transaction History
// //     function transactionHistory() {
// //         $.ajax({
// //             url: ajax_object.ajax_url,
// //             method: 'GET',
// //             data: {
// //                 "action": "getTransactionHistory"
// //             },
// //             dataType: 'json',
// //             success: function (response) {
// //                 console.log("response for transaction history", response);
// //                 allTransactionData = response.responsedata;
// //                 transactionData = allTransactionData;
// //                 transactionCurrentPage = 1;

// //                 renderPaginatedTransactionHistory();


// //             },
// //             error: function (xhr, status, error) {
// //                 console.error('Error fetching leaderboard data:', error);
// //             },
// //             complete: function () {
// //                 // Hide spinner, show table
// //                 $('#spinner').hide();
// //                 $('#leaderboardTable').show();
// //             }
// //         });
// //     }

// //     transactionHistory()

// //     let allLeaderboardData = [];

// //     // Leaderboard Scripts
// //     function fetchLeaderboardData() {
// //         // Show spinner, hide table
// //         $('#spinner').show();
// //         $('#leaderboardTable').hide();

// //         // Get Month and Year Data

// //         let selectedYear = $('#yearFilter').val();
// //         let selectedMonth = $('#monthFilter').val();


// //         $.ajax({
// //             url: ajax_object.ajax_url,
// //             method: 'POST',
// //             data: {
// //                 "action": "getLeaderBoard",
// //                 "year": selectedYear,
// //                 "month": selectedMonth
// //             },
// //             dataType: 'json',
// //             success: function (response) {
// //                 console.log("new leaderboard response", response);


// //                 let leaderboardData = response?.leaderBoardReport?.leaderBoardlst || [];

// //                 allLeaderboardData = leaderboardData; // store data for filtering
// //                 let filters = response?.filters;

// //                 populateLeaderboardTable(leaderboardData);
// //                 renderPaginatedLeaderboard(); // show limited entries
// //                 populateFilters(filters);
// //             },
// //             error: function (xhr, status, error) {
// //                 console.error('Error fetching leaderboard data:', error);
// //             },
// //             complete: function () {
// //                 // Hide spinner, show table
// //                 $('#spinner').hide();
// //                 $('#leaderboardTable').show();
// //             }
// //         });
// //     }

// //     // 🔍 Live search functionality
// //     $('#leaderboardSearch').on('input', function () {
// //         const searchTerm = $(this).val().toLowerCase();
// //         console.log("leaderboardSearch", allLeaderboardData);


// //         const filteredData = allLeaderboardData.filter(player =>
// //             player?.fullName?.toLowerCase().includes(searchTerm)
// //         );

// //         populateLeaderboardTable(filteredData);
// //     });

// //     function populateLeaderboardTable(data) {
// //         const spinner = $('#spinner');
// //         let tableBody = $('#leaderboard');
// //         spinner.show();
// //         tableBody.empty(); // Clear existing rows

// //         if (!data || data.length === 0) {
// //             tableBody.append('<tr><td colspan="5" class="text-center">No Data Available</td></tr>');
// //             return;
// //         }

// //         data.forEach((player, index) => {
// //             let row = `<tr>
// //                     <td class="rank-content">${player?.rank}</td>
// //                     <td class="playerdetail-content"><span class="player-content"><br>
// //                             <span class="profilepic"><img class=" lazyloaded" decoding="async" src="${player?.profilePitcure || 'default-image.jpg'}"></span><br>
// //                             <span class="playername"><a class="primary-link1">${player?.fullName || 'N/A'}</a></span><br>
// //                         </span></td>
// //                     <td class="leaderboard-score-content"><span class="leaderboard-score">${player?.totalPoints || 0}</span></td>
// //                     <td class="checkin-content">${player?.totalCheckins || 0}</td>
// //                     <td class="referral-content">${player?.totalTx || 0}</td>
// //                 </tr>`;
// //             tableBody.append(row);
// //         });
// //     }

// //     // Update table when dropdown changes
// //     $('#entriesPerPage').on('change', function () {
// //         leaderboardEntriesToShow = parseInt($(this).val());
// //         renderPaginatedLeaderboard(); // re-render table with new entry count
// //     });


// //     // Call this to show limited leaderboard entries
// //     function renderPaginatedLeaderboard() {
// //         const startIndex = (currentPage - 1) * leaderboardEntriesToShow;
// //         const endIndex = startIndex + leaderboardEntriesToShow;
// //         const limitedData = allLeaderboardData.slice(startIndex, endIndex);
// //         populateLeaderboardTable(limitedData);
// //     }



// //     $('#nextPage').on('click', function () {
// //         if ((currentPage * leaderboardEntriesToShow) < allLeaderboardData.length) {
// //             currentPage++;
// //             renderPaginatedLeaderboard();
// //         }
// //     });

// //     $('#prevPage').on('click', function () {
// //         if (currentPage > 1) {
// //             currentPage--;
// //             renderPaginatedLeaderboard();
// //         }
// //     });




// function populateMyOffersTable(data) {

//     let tableBody = $('#offer_data');
//     tableBody.empty(); // Clear existing rows

//     if (!data || data.length === 0) {
//         tableBody.append('<tr><td colspan="5" class="text-center">No Data Available</td></tr>');
//         return;
//     }


//     let htmlData = '';
//     data.forEach((player, index) => {

//         htmlData += `<div class="content-box-column" data-offer-id="${player?.offerID}">
//                 <div class="product-with-image">
//                     <p><img src="${player.offerImageUrl}"></p>
//                     <div class="product-without-image"><span class="product-name">${player.offerTitle}</span><br>
//                         <span class="product-price">$${player.offerPointValue}</span>
//                     </div>
//                     <div class="main-spinner" style="position: relative; top: 20px; right: 0px;">
//                         <div id="spinner-${player?.offerID}" class="spinner-container" style="display: none; text-align: center; margin-bottom: 10px;">
//                             <div class="spinner-border text-primary" role="status">
//                                 <span class="visually-hidden">Loading...</span>
//                             </div>
//                         </div>
//                     </div>
//                     <button type="submit" class="submit-button-anchor transferpoint redeem-btn" href="#" type="submit" data-offer-id="${player?.offerID}"><span>Redeem Now</span></button>
//                 </div>
//             </div>`
//             ;

//         tableBody.append(htmlData);
//     });
// }
// //     function populateEgiftOffersTable(data) {

// //         let categoryContainer = $('.egift-content-block-flex-box-left'); // Sidebar
// //         allEgiftOfferData = data; // Save all for filtering
// //         renderEgiftOffers(data);

// //         // Clear old checkboxes
// //         categoryContainer.find('.category-generated').remove();

// //         // Generate new categories
// //         let categoryMap = new Map();

// //         data.forEach((transaction) => {

// //             const offer = transaction.offerData;
// //             console.log("transaction", offer);
// //             if (offer?.tangoCategoryName && offer?.tangoCategoryId) {
// //                 categoryMap.set(offer.tangoCategoryId, offer.tangoCategoryName);
// //             }
// //         });

// //         categoryMap.forEach((name, id) => {
// //             const categoryHtml = `
// //                 <div class="checkboxes category-generated">
// //                     <p><input type="checkbox" class="category-filter" value="${id}" data-category="${name}" onclick="clickedCategory(this)"> ${name}</p>
// //                 </div>
// //             `;
// //             categoryContainer.append(categoryHtml);
// //         });
// //     }

// //     function populateTransactionHistoryTable(data) {
// //         const spinner = $('#spinner');

// //         let tableBody = $('#transactionHistoryBody');
// //         spinner.show();
// //         tableBody.empty();

// //         if (!data || data.length === 0) {
// //             tableBody.html('<tr><td colspan="6" class="text-center">No Data Available</td></tr>');
// //             return;
// //         }

// //         data.forEach((player) => {
// //             let row = `
// //                 <tr class="transactions">
// //                     <td class="date-content">${new Date(player.transactionDate).toLocaleString()}</td>
// //                     <td class="type-content">${player.type}</td>
// //                     <td class="status-content">${player.transactionStatus}</td>
// //                     <td class="points-content">${player.points}</td>
// //                     <td class="balance-content">${player.balance}</td>
// //                     <td class="plus-content">
// //                         <span class="show-content showing-details">+</span>
// //                         <span class="hide-content">-</span>
// //                     </td>
// //                 </tr>
// //                 <tr class="transactions-details-all">
// //                     <td colspan="6">
// //                         <table class="detailrow">
// //                             <tbody>
// //                                 <tr>
// //                                     <td>Location: </td>
// //                                     <td style="padding-left:78px;" title="Home Ridge">${player.locationName}</td>
// //                                 </tr>
// //                             </tbody>
// //                         </table>
// //                     </td>
// //                 </tr>
// //             `;
// //             tableBody.append(row);
// //         });
// //     }


// //     function renderPaginatedTransactionHistory() {
// //         const startIndex = (transactionCurrentPage - 1) * transactionEntriesToShow;
// //         const endIndex = startIndex + transactionEntriesToShow;
// //         const paginatedData = allTransactionData.slice(startIndex, endIndex);
// //         populateTransactionHistoryTable(paginatedData);
// //     }


// //     $('#transactionEntriesPerPage').on('change', function () {
// //         transactionEntriesToShow = parseInt($(this).val());
// //         transactionCurrentPage = 1; // reset to first page
// //         renderPaginatedTransactionHistory();
// //     });

// //     $('#nextTransactionPage').on('click', function () {
// //         if ((transactionCurrentPage * transactionEntriesToShow) < allTransactionData.length) {
// //             transactionCurrentPage++;
// //             renderPaginatedTransactionHistory();
// //         }
// //     });

// //     $('#prevTransactionPage').on('click', function () {
// //         if (transactionCurrentPage > 1) {
// //             transactionCurrentPage--;
// //             renderPaginatedTransactionHistory();
// //         }
// //     });


// //     $('#balanceSearch , #fusion-live-search-input-0').on('input', function () {
// //         const searchValue = $(this).val().toLowerCase().trim();

// //         // Check if searchValue is empty
// //         if (searchValue === '') {
// //             // If search bar is cleared, go back to paginated default
// //             transactionCurrentPage = 1;
// //             renderPaginatedTransactionHistory();
// //             return;
// //         }

// //         // Filter the transaction data based on balance
// //         const filtered = transactionData.filter(item => {
// //             // Convert balance to string
// //             const balanceStr = item.balance !== undefined && item.balance !== null
// //                 ? item.balance.toString().toLowerCase()
// //                 : '';

// //             console.log('Search Value:', searchValue); // Debugging line
// //             console.log('Balance:', balanceStr); // Debugging line

// //             return balanceStr.includes(searchValue);
// //         });

// //         // Log filtered data to verify
// //         console.log('Filtered Data:', filtered);

// //         // Populate table with filtered data
// //         populateTransactionHistoryTable(filtered);
// //     });




// //     function populateFilters(filters) {
// //         if (!filters) return;

// //         let yearFilter = $('#yearFilter');
// //         let monthFilter = $('#monthFilter');

// //         yearFilter.empty().append('<option value="">Select Year</option>');
// //         monthFilter.empty().append('<option value="">Select Month</option>').hide();

// //         let years = [...new Set(filters.map(filter => filter.year))];
// //         years.forEach(year => {
// //             yearFilter.append(`<option value="${year}">${year}</option>`);
// //         });

// //         yearFilter.off('change').on('change', function () {
// //             let selectedYear = $(this).val();

// //             monthFilter.empty().append('<option value="">Select Month</option>').hide();

// //             let months = filters.filter(filter => filter.year == selectedYear);
// //             if (months.length > 0) {
// //                 monthFilter.show();
// //                 months.forEach(month => {
// //                     monthFilter.append(`<option value="${month.month}">${month.display}</option>`);
// //                 });
// //             }
// //         });
// //     }

// //     $('#monthFilter').on('change', function () {
// //         fetchLeaderboardData();
// //     });


// //     fetchLeaderboardData();


// //     // Leaderboard Scripts

// //     // Egift Offers

// //     function loadEgiftOffers() {
// //         $.ajax({
// //             url: ajax_object.ajax_url,
// //             method: 'POST',
// //             data: {
// //                 "action": "eGiftOffers"
// //             },
// //             dataType: 'json',
// //             success: function (response) {
// //                 console.log("response for egift offers", response);

// //                 // let filters = response.data?.responsedata?.filters;

// //                 populateEgiftOffersTable(response);
// //                 // populateFilters(filters);
// //             },
// //             error: function (xhr, status, error) {
// //                 console.error('Error fetching leaderboard data:', error);
// //             },
// //             complete: function () {
// //                 // Hide spinner, show table
// //                 $('#spinner').hide();
// //                 $('#leaderboardTable').show();
// //             }
// //         });
// //     }

// //     loadEgiftOffers();


// function loadOffers() {
//     // const offer_id = form.data("offer-id");


//     $.ajax({
//         url: ajax_object.ajax_url,
//         method: 'POST',
//         data: {
//             "action": "myOffers"
//         },
//         dataType: 'json',
//         success: function (response) {

//             // let filters = response.data?.responsedata?.filters;

//             populateMyOffersTable(response);
//             // populateFilters(filters);
//         },
//         error: function (xhr, status, error) {
//             console.error('Error fetching leaderboard data:', error);
//         },
//         complete: function () {
//             // Hide spinner, show table
//             $('#spinner').hide();
//             $('#leaderboardTable').show();
//         }
//     });
// }

// loadOffers();

// //     // Ending Egift Offers


// //     // Free Play Visits
// //     function populateFreeVisitsTable(data) {
// //         console.log(data);

// //         let tableBody = $('#freePlayVisitTable');
// //         tableBody.empty(); // Clear existing rows
// //         if (!data || data.length === 0) {
// //             tableBody.append('<tr><td colspan="5" class="text-center">No Data Available</td></tr>');
// //             return;
// //         }

// //         data.forEach((visit, index) => {
// //             let row = `<tr>
// //                 <td>${visit?.locationName}</td>
// //                 <td>${visit?.visitCount || 0}</td>
// //             </tr>`;
// //             tableBody.append(row);
// //         });
// //     }


// //     function freePlayVisits() {
// //         $.ajax({
// //             url: ajax_object.ajax_url,
// //             method: 'POST',
// //             data: {
// //                 "action": "freePlayVisits"
// //             },
// //             dataType: 'json',
// //             success: function (response) {
// //                 populateFreeVisitsTable(response);

// //             },
// //             error: function (xhr, status, error) {
// //                 console.error('Error fetching leaderboard data:', error);
// //             },
// //             complete: function () {
// //                 // Hide spinner, show table
// //                 $('#spinner').hide();
// //                 $('#leaderboardTable').show();
// //             }
// //         });
// //     }

// //     // Ending Free Play Visits

// //     jQuery(document).ready(function ($) {
// //         $.ajax({
// //             url: ajax_object.ajax_url,
// //             method: 'GET',
// //             data: {
// //                 "action": "getLocation" // must match PHP action
// //             },
// //             dataType: 'json',
// //             success: function (location) {
// //                 renderLocationHTML(location);
// //                 setupLocationSearch(location);
// //             },
// //             error: function (error) {
// //                 console.error('Error fetching location:', error);
// //             },
// //         });

// //         $.ajax({
// //             url: ajax_object.ajax_url,
// //             method: 'GET',
// //             data: {
// //                 "action": "getSurveys"
// //             },
// //             dataType: 'json',
// //             success: function (response) {
// //                 console.log("response for surveys", response);
// //                 // let filters = response.data?.responsedata?.filters;

// //                 populateSurveysTable(response);
// //                 // populateFilters(filters);
// //             },
// //             error: function (xhr, status, error) {
// //                 console.error('Error fetching Surveys data:', error);
// //             },
// //             complete: function () {
// //                 // Hide spinner, show table
// //                 $('#spinner').hide();
// //                 $('#leaderboardTable').show();
// //             }
// //         });
// //     });

// //     function populateSurveysTable(data) {
// //         const availableContainer = $('#available-surveys-container');
// //         const completedContainer = $('#completed-surveys-container');

// //         availableContainer.empty();
// //         completedContainer.empty();

// //         // Available Surveys
// //         if (!data.available || data.available.length === 0) {
// //             availableContainer.append('<div class="text-center">No Available Surveys</div>');
// //         } else {
// //             data.available.forEach(survey => {
// //                 const html = `
// //                     <div class="survey-flex-box">
// //                         <div class="survey-title-font">
// //                             <ul>
// //                                 <li>${survey.surveyTitle}</li>
// //                             </ul>
// //                         </div>
// //                         <div class="survey-title-font">
// //                             <div class="survey-format-flex">
// //                                 <div>${survey.surveySendDataString}</div>
// //                                 <div><a class="take-survey" href="${survey.buttonSurveyLink}" target="_blank">Take survey</a></div>
// //                             </div>
// //                         </div>
// //                     </div>`;
// //                 availableContainer.append(html);
// //             });
// //         }

// //         // Completed Surveys
// //         if (!data.completed || data.completed.length === 0) {
// //             completedContainer.append('<div class="text-center">No Completed Surveys</div>');
// //         } else {
// //             data.completed.forEach(survey => {
// //                 const html = `
// //                     <div class="survey-flex-box">
// //                         <div class="survey-title-font">
// //                             <ul>
// //                                 <li>${survey.surveyTitle}</li>
// //                             </ul>
// //                         </div>
// //                         <div class="survey-title-font">
// //                             <div class="survey-format-flex">
// //                                 <div>${survey.surveySendDataString}</div>
// //                                 <div>${survey.respondDateString}</div>
// //                                 <div>${survey.surveyPoints ?? '0'}</div>
// //                             </div>
// //                         </div>
// //                     </div>`;
// //                 completedContainer.append(html);
// //             });
// //         }
// //     }

// //     function renderLocationHTML(locations) {

// //         const container = $('#locations-wrapper');
// //         container.empty();
// //         const itemsPerPage = 3;
// //         let currentCount = 0;

// //         function renderBatch() {
// //             const slice = locations.slice(currentCount, currentCount + itemsPerPage);
// //             slice.forEach((location, index) => {
// //                 console.log("Location here?", index);

// //                 const modalId = `modal-${currentCount + index}`;
// //                 const boxId = `box-${currentCount + index}`;
// //                 const modalHTML = `
// //                   <div class="boxes-modals" id="${boxId}">
// //                   <div class="modal-box-content">
// //                   <div class="modal-box-anchor"><strong>${location.locationName || 'No Name'}</strong></div>
// //                   <button class="open-modal-btn" onclick="document.getElementById('${modalId}').showModal();">
// //                         <div class="modal-box-anchor">${location.address || ''}</div>
// //                         </button>
// //                         <div class="modal-box-anchor">${location.city || ''}, ${location.zipCode || ''}</div>
// //                         <div class="modal-box-anchor">
// //                           <a href="${location.websiteURL || '#'}" target="_blank">
// //                             ${location.websiteURL || 'Visit Website'}
// //                           </a>
// //                         </div>
// //                         <div class="social-icons">
// //                           ${location.facebookMailID ? '<i class="fab fa-facebook-f"></i>' : '<i class="fab fa-facebook-f"></i>'}
// //                           ${location.twitterMailID ? '<i class="fab fa-twitter"></i>' : '<i class="fab fa-twitter"></i>'}
// //                           ${location.linkedin ? '<i class="fab fa-linkedin-in"></i>' : '<i class="fab fa-linkedin-in"></i>'}
// //                           ${location.youtube ? '<i class="fab fa-youtube"></i>' : '<i class="fab fa-youtube"></i>'}
// //                           ${location.instagramMailId ? '<i class="fab fa-instagram"></i>' : '<i class="fab fa-instagram"></i>'}
// //                         </div>
// //                       </div>
// //                     <dialog id="${modalId}">
// //                       <div class="modal-content">
// //                         <h2>${location.locationName || 'Need Directions?'}</h2>
// //                         <p>${location.address || ''}, ${location.city || ''}, ${location.state || ''}, ${location.zipCode || ''}</p>
// //                         <div class="modal-button">
// //                           <button onclick="document.getElementById('${modalId}').close();">Cancel</button>
// //                           <button onclick="window.open('https://www.google.com/maps?q=${location.latitude},${location.longitude}', '_blank')">Yes</button>
// //                         </div>
// //                       </div>
// //                     </dialog>
// //                   </div>
// //                 `;
// //                 container.append(modalHTML);
// //             });

// //             currentCount += itemsPerPage;

// //             if (currentCount >= locations.length) {
// //                 $('#loadMoreBtn').hide();
// //             }
// //         }

// //         $('#loadMoreBtn').off('click').on('click', renderBatch);
// //         renderBatch();
// //     }

// //     let originalLocations = []; // Store the full list globally

// //     function setupLocationSearch(location) {
// //         originalLocations = location; // Save original

// //         $('#locationSearch').on('input', function () {
// //             const query = $(this).val().toLowerCase().trim();

// //             if (query === '') {
// //                 renderLocationHTML(originalLocations);
// //                 $('#loadMoreBtn').show();
// //                 return;
// //             }

// //             const filtered = originalLocations.filter(loc => {
// //                 return (
// //                     (loc.city && loc.city.toLowerCase().includes(query)) ||
// //                     (loc.zipCode && loc.zipCode.toString().includes(query)) ||
// //                     (loc.address && loc.address.toLowerCase().includes(query))
// //                 );
// //             });

// //             renderLocationHTML(filtered);
// //             if (filtered.length <= 3) {
// //                 $('#loadMoreBtn').hide(); // Hide if fewer than one page
// //             } else {
// //                 $('#loadMoreBtn').show(); // Show if needed
// //             }
// //         });
// //     }

// //     // Cashback Code

// //     const CashbacktransferForm = document.querySelector(".TrasferPointBlock");
// //     // const btnRedeemCash = document.querySelector(".btnRedeemCash");
// //     const spinnerHTML = `<span class="spinner-border spinner-border-sm me-2" role="status"></span> Processing...`;

// //     // Handle quick redemption button clicks
// //     document.querySelectorAll(".clsquickRedemption").forEach(button => {
// //         button.addEventListener("click", () => {
// //             document.getElementById("txtTransferamount").value = button.dataset.value;
// //             document.getElementById("rdOther").checked = true;
// //         });
// //     });


// // });

// // // Copy Referal Link
// // // function copyLink(event) {
// // //     event.preventDefault(); // Prevent default behavior like form submit or anchor jump

// // //     var copyText = document.getElementById("txtpersonallink");
// // //     copyText.select();
// // //     copyText.setSelectionRange(0, 99999); // For mobile devices
// // //     navigator.clipboard.writeText(copyText.value)
// // //         .then(() => {
// // //             alert("Copied: " + copyText.value);
// // //         })
// // //         .catch(err => {
// // //             console.error('Failed to copy: ', err);
// // //         });
// // // }

// // function copyLink(event) {
// //     event.preventDefault(); // Prevent default behavior like form submit or anchor jump

// //     var copyText = document.getElementById("txtpersonallink");
// //     copyText.select();
// //     copyText.setSelectionRange(0, 99999); // For mobile devices
// //     navigator.clipboard.writeText(copyText.value)
// //         .then(() => {
// //             alert("Copied: " + copyText.value);
// //         })
// //         .catch(err => {
// //             console.error('Failed to copy: ', err);
// //         });
// // }

// // function triggerUpload() {
// //     document.getElementById("imageInput").click();
// // }

// // function previewImage(event) {
// //     const file = event.target.files[0];
// //     if (file && file.type.startsWith("image/")) {
// //         const reader = new FileReader();
// //         reader.onload = function (e) {
// //             document.getElementById("profileImage").src = e.target.result;
// //         };
// //         reader.readAsDataURL(file);
// //     } else {
// //         alert("Please select a valid image file.");
// //     }
// // }

// // function resetImage() {
// //     document.getElementById("profileImage").src = "https://casino3.myrwds.net/wp-content/uploads/255702286.jpg";
// // }

// // document.getElementById("addBirthdayBtn").addEventListener("click", function () {
// //     const container = document.getElementById("birthday-list");
// //     const newEntry = document.createElement("div");
// //     newEntry.classList.add("birthday-entry");
// //     newEntry.innerHTML = `
// //     <input type="text" name="friend_name[]" placeholder="Friend's Name" required />
// //     <input type="date" name="friend_birthday[]" required />
// //     <button type="button" class="remove-birthday" onclick="removeBirthday(this)">✖</button>
// //   `;
// //     container.appendChild(newEntry);
// // });

// // function removeBirthday(btn) {
// //     btn.parentElement.remove();
// // }



// When "Create Account" is clicked (toggle-auth for signup)
// "Create Account" → Show Signup modal
document.querySelector('.toggle-auth[data-view="signup"]')?.addEventListener('click', function () {
    jQuery('button[data-dismiss="modal"]').click(); // Close login
    setTimeout(() => {
        document.querySelector('a[data-target=".fusion-modal.signup"]')?.click(); // Open signup
    }, 300); // Wait for modal close animation
});

// "Sign in" → Show Login modal
$(document).on('click', '.Signup_alreadyHaveAccountContainer__button__9gbcD', function () {
    jQuery('button[data-dismiss="modal"]').click(); // Close signup
    setTimeout(() => {
        document.querySelector('a[data-target=".fusion-modal.login"]')?.click(); // Open login
    }, 300); // Wait for modal close animation
});


jQuery(document).ready(function ($) {
    // Add hidden file input if it doesn't exist
    if (!$('#tempImageInput').length) {
        $('body').append('<input type="file" id="tempImageInput" name="profile_image" accept="image/*" style="display:none;">');
    }

    // Add hidden field to track removal
    if (!$('#removeProfileFlag').length) {
        $('body').append('<input type="hidden" id="removeProfileFlag" name="remove_profile_image" value="0">');
    }

    // Click to trigger image upload
    $('#change-profile-image').off('click').on('click', function () {
        $('#tempImageInput').click();
    });

    // Image preview on file selection
    $('#tempImageInput').off('change').on('change', function (e) {
        const file = e.target.files[0];

        if (file && file.type.startsWith('image/')) {
            const reader = new FileReader();

            reader.onload = function (event) {
                const imageUrl = event.target.result;
                const $img = $('#preview-image img');

                $img.attr('src', imageUrl);
                $img.attr('data-orig-src', imageUrl);
                $img.removeAttr('srcset data-srcset data-sizes data-orig-sizes');
                $img.removeClass('lazyload lazyautosizes lazyloaded');

                // Reset removal flag
                $('#removeProfileFlag').val('0');
            };

            reader.readAsDataURL(file);
        }
    });

    // Remove image on button click
    $('#remove-profile-image').off('click').on('click', function () {
        const $img = $('#preview-image img');

        // Replace with placeholder or hide the image
        $img.attr('src', 'https://via.placeholder.com/300x200.png?text=No+Image');
        $img.removeAttr('data-orig-src srcset data-srcset data-sizes data-orig-sizes');
        $img.removeClass('lazyload lazyautosizes lazyloaded');

        // Clear file input
        $('#tempImageInput').val('');

        // Set removal flag
        $('#removeProfileFlag').val('1');
    });




    // Submit Profile

    $(document).on('click', '.save_changes_button', function (e) {
        e.preventDefault();
        e.stopPropagation();

        var $btn = $(this);

        // Prevent multiple clicks
        if ($btn.prop('disabled')) return;

        // Show spinner and disable button
        $btn.prop('disabled', true);
        $btn.data('original-text', $btn.html());
        $btn.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...');

        var formData = {
            action: 'handle_update_user_profile'
        };

        $('.fusion-form input, .fusion-form select, .fusion-form textarea').each(function () {
            var name = $(this).attr('name') || $(this).attr('id');
            var value = $(this).val();

            if (name) {
                formData[name] = value;
            }
        });

        console.log('Sending Form Data:', formData);

        $.ajax({
            url: ajax_object.ajax_url,
            method: "POST",
            dataType: "json",
            data: formData,
            success: function (response) {
                if (response.statusCode === 1) {
                    alert(response.message || 'Profile updated successfully.');
                } else {
                    alert("Error: " + (response.statusMessage || 'Update failed.'));
                }
            },
            error: function () {
                alert("Failed to update profile.");
            },
            complete: function () {
                // Restore button state
                $btn.prop('disabled', false);
                $btn.html($btn.data('original-text'));
            }
        });
    });


});

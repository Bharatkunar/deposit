<div class="wrap">
    <div class="header-with-logo">
        <div class="logo-container">
            <img src="<?php echo get_site_url() . '/wp-content/plugins/api-casino-connector/assets/admin/images/roborewards.png'; ?>" alt="Casino Logo" class="logo">
        </div>
        <div class="ribbon-container">
            <span class="ribbon-text"><?php echo $menu_name; ?></span>
        </div>
    </div>
</div>

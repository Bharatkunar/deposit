<div class="pagination">
    <?php 
        // Get current query parameters
        $query_params = $_GET;

        // Ensure 'currentPage' is an integer
        $current_page = isset($query_params['currentPage']) ? (int)$query_params['currentPage'] : 1;

        // Total pages (Ensure this is defined in your script)
        $total_pages = isset($total_pages) ? (int)$total_pages : 1;

        // Remove 'currentPage' from existing query parameters
        unset($query_params['currentPage']);

        // Build the base URL with existing query parameters
        $base_url = '?' . http_build_query($query_params);
    ?>

    <?php if ($current_page > 1) : ?>
        <a href="<?php echo $base_url . '&currentPage=' . ($current_page - 1); ?>" class="button">Prev</a>
    <?php endif; ?>

    <span>Page <?php echo $current_page; ?> of <?php echo $total_pages; ?></span>

    <?php if ($current_page < $total_pages) : ?>
        <a href="<?php echo $base_url . '&currentPage=' . ($current_page + 1); ?>" class="button">Next</a>
    <?php endif; ?>
</div>


<?php include(plugin_dir_path(__FILE__) . '../commons/header.php'); ?>
  <div class="container-fluid py-4">
    <!-- Top Info Boxes -->
    <div class="row mb-4">

      <div class="col-md-3">
        <div class="info-box text-center">
          <h5>Total Active Games</h5>
          <p class="display-6"><?php echo $data['totalActiveGames']; ?></p>
        </div>
      </div>

      <div class="col-md-3">
        <div class="info-box text-center">
          <h5>Total Inactive Games</h5>
          <p class="display-6"><?php echo $data['totalInactiveGames']; ?></p>
        </div>
      </div>

      <div class="col-md-3">
        <div class="info-box text-center">
          <h5>Total User Registrations</h5>
          <p class="display-6"><?php echo $data['totalUserRegistered']; ?></p>
        </div>
      </div>
      
      <div class="col-md-3">
        <div class="info-box text-center">
          <h5>Total Merchant Limit</h5>
          <p class="display-6"><?php echo $data['totalMerchantLimit']; ?></p>
        </div>
      </div>
    </div>

    <!-- Third Row: Transactions and Current Games -->
    <div class="row">
      <!-- Transactions List -->
      <div class="col-md-12 mb-4">
        <div class="card shadow-sm">
          <div class="card-header">
            <h5>Recent Wins</h5>
          </div>
          <div class="card-body">
            <table class="table table-striped table-bordered">
              <thead class="thead-dark">
                <tr>
                    <th>Player Name</th>
                    <th>Transaction ID</th>
                    <th>Amount</th>
                    <th>Date</th>
                  </tr>
              </thead>
              <tbody>
                <?php foreach($data['totalTransactionsRecent'] as $recentWin  ): ?>
                <tr>
                  <td><?php echo $recentWin->user_nicename; ?></td>
                  <td><?php echo $recentWin->transaction_id; ?></td>
                  <td><?php echo $recentWin->amount; ?></td>
                  <td><?php echo $recentWin->created_at; ?></td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>


      <div class="col-md-12 mb-4">
        <div class="card shadow-sm">
          <div class="card-header">
            <h5>Recent Customers</h5>
          </div>
          <div class="card-body">
            <table class="table table-striped table-bordered">
              <thead class="thead-dark">
                <tr>
                  <th>Player Name</th>
                  <th>Email</th>
                  <th>balance</th>
                  <th>Registration Date</th>
                </tr>
              </thead>
              <tbody>
                <?php
                  foreach($data['latestCustomersRegistered'] as $customer):?>
                <tr>
                  <td><?php echo $customer->display_name; ?></td>
                  <td><?php echo $customer->user_email; ?></td>
                  <td><?php echo $customer->customer_balance; ?></td>
                  <td><?php echo $customer->user_registered; ?></td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Games Currently Being Played -->
    
    </div>

  </div>

    <!-- Keep the existing form untouched -->
    <?php include(plugin_dir_path(__FILE__) . '../commons/header.php'); ?>

    <div class="main-content">
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="casino_register_settings">

            <table class="form-table">
                <tr>
                    <th scope="row"><label for="casino_callback_url">Callback URL</label></th>
                    <td><input style='width:100%' type="text" id="casino_callback_url" name="casino_callback_url" value="<?php echo esc_attr(get_option('casino_callback_url')); ?>" /></td>
                </tr>
                <tr>
                    <th scope="row"><label for="casino_callback_url">RoboRewards Token</label></th>
                    <td><input style='width:100%' type="text" id="casino_roboreward_token" placeholder="token" name="casino_roboreward_token" value="<?php echo esc_attr(get_option('casino_roboreward_token')); ?>" /></td>
                </tr>
                <tr>
                    <th scope="row"><label for="casino_callback_url">RoboRewards ID</label></th>
                    <td><input style='width:100%' type="text" id="casino_rpID" placeholder="casino_rpID" name="casino_rpID" value="<?php echo esc_attr(get_option('casino_rpID')); ?>" /></td>
                </tr>
                <tr>
                    <th scope="row"><label for="casino_callback_url">WEBFROM ID</label></th>
                    <td><input style='width:100%' type="text" id="casinoWEBFROMID_rpID" placeholder="WEBFROMID" name="WEBFROMID" value="<?php echo esc_attr(get_option('WEBFROMID')); ?>" /></td>
                </tr>
                <tr>
                    <th scope="row"><label for="casino_callback_url">Contact List ID</label></th>
                    <td><input style='width:100%' type="text" id="casino_contactListID" placeholder="casino_contactListID" name="casino_contactListID" value="<?php echo esc_attr(get_option('casino_contactListID')); ?>" /></td>
                </tr>
                <tr>
                    <th scope="row"><label for="casino_callback_url">Username</label></th>
                    <td><input style='width:100%' type="text" id="casino_username" placeholder="username" name="casino_username" value="<?php echo esc_attr(get_option('casino_username')); ?>" /></td>
                </tr>
                <tr>
                    <th scope="row"><label for="casino_callback_url">Password</label></th>
                    <td><input style='width:100%' type="text" id="casino_password" placeholder="password" name="casino_password" value="<?php echo esc_attr(get_option('casino_password')); ?>" /></td>
                </tr>
                <tr>
                    <th scope="row"><label for="casino_callback_url">Jwt Token</label></th>
                    <td><input style='width:100%' type="text" id="jwtToken" placeholder="jwtToken" name="jwtToken" value="<?php echo esc_attr(get_option('jwtToken')); ?>" /></td>
                </tr>
                <tr>
                    <th scope="row"><label for="loyalty_callback_url">Loyalty CallBack</label></th>
                    <td><input style='width:100%' type="text" readonly  name="loyalty_callback" value="<?php echo get_option('loyalty_callback') ?>" /></td>
                </tr>
                <tr>
                    <th scope="row"><label for="casino_product_sync">Product Sync</label></th>
                    <td>
                        <input type="radio" value='true' id="casino_product_sync" name="casino_product_sync" <?php checked('true', get_option('casino_product_sync')); ?> />  Yes
                        <input type="radio" value='false' id="casino_product_sync" name="casino_product_sync" <?php checked('false', get_option('casino_product_sync')); ?> /> No
                    </td>
                </tr>
            </table>

            <?php submit_button(); ?>
        </form>
    </div>

    <!-- New Section: API Sync -->
    <div class="main-content">
        <h2>API Data Sync</h2>
        <button id="fetch_records" class="button button-primary">Fetch All Records</button>
        
        <table class="widefat striped">
            <thead>
                <tr>
                    <th>API Name</th>
                    <th>Endpoint</th>
                    <th>Status</th>
                    <th>Reset</th>
                </tr>
            </thead>
            <tbody id="api_sync_status">
                <?php 
                $apis = [
                    ['name' => 'Home Page', 'endpoint' => 'api/EndUserProfile/Home'],
                    ['name' => 'Visit Tracking Api', 'endpoint' => 'api/EndUserProfile/VisitTrackingData'],
                    ['name' => 'Orders', 'endpoint' => '/api/orders'],
                    ['name' => 'Products', 'endpoint' => '/api/products'],
                    ['name' => 'Offers', 'endpoint' => '/api/offers'],
                    ['name' => 'Leaderboard', 'endpoint' => '/api/leaderboard'],
                    ['name' => 'Rewards', 'endpoint' => '/api/rewards']
                ];

                foreach ($apis as $api) {
                    echo "<tr data-endpoint='{$api['endpoint']}'>
                            <td>{$api['name']}</td>
                            <td>{$api['endpoint']}</td>
                            <td class='status'>Failed</td>
                            <td><button class='reset-api button'>Reset</button></td>
                        </tr>";
                }
                ?>
            </tbody>
        </table>

        <!-- Progress Bar -->
        <div style="margin-top: 20px;">
            <label>Progress:</label>
            <progress id="sync_progress" value="0" max="100" style="width: 100%;"></progress>
        </div>

    </div>

    <div class="main-content">
        <h3>Connect Your Plugin With Woocommerce</h3>
    <button type="button" id="sync_woocommerce" class="button-primary" style="margin-top: 30px;">
        Connect WooCommerce with Plugin

    <span id="spinner" class="spinner" style="display: none;"></span>

    </button>

    <div id="woocommerce_keys_section" style="display: none; margin-top: 30px;">
        <h3>API Credentials</h3>

        <label>Consumer Key:</label>
        <div style="position: relative;">
            <input type="password" id="consumer_key" readonly>
            <button type="button" onclick="toggleVisibility('consumer_key', this)">View</button>
        </div>

        <label>Consumer Secret:</label>
        <div style="position: relative;">
            <input type="password" id="consumer_secret" readonly>
            <button type="button" onclick="toggleVisibility('consumer_secret', this)">View</button>
        </div>
    </div>
            </div>
    </div>


    <!-- JavaScript for Fetching APIs -->
    <script>
    document.getElementById('fetch_records').addEventListener('click', function() {
        let rows = document.querySelectorAll("#api_sync_status tr");
        let progressBar = document.getElementById("sync_progress");
        let completed = 0;
        let total = rows.length;

        rows.forEach(row => {
            let endpoint = row.getAttribute("data-endpoint");

            fetch("<?php echo esc_url(admin_url('admin-ajax.php')); ?>", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: "action=fetch_api_data&endpoint=" + encodeURIComponent(endpoint)
            })
            .then(response => response.json())
            .then(data => {
                row.querySelector(".status").textContent = data.success ? "Success" : "Failed";
                row.querySelector(".status").style.color = data.success ? "green" : "red";
                completed++;
                progressBar.value = (completed / total) * 100;
            });
        });
    });

    // Reset API Sync
    document.querySelectorAll(".reset-api").forEach(button => {
        button.addEventListener("click", function() {
            let row = this.closest("tr");
            row.querySelector(".status").textContent = "Failed";
            row.querySelector(".status").style.color = "red";
        });
    });
    </script>

    <style>
        .spinner {
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-top: 3px solid white;
            border-radius: 50%;
            width: 15px;
            height: 15px;
            display: inline-block;
            vertical-align: middle;
            animation: spin 0.8s linear infinite;
            margin-left: 8px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>

    <script>
    document.getElementById("sync_woocommerce").addEventListener("click", function () {
        let button = this;
        let spinner = document.getElementById("spinner");
        
        // Remove existing error messages
        let existingError = document.getElementById("error_message");
        if (existingError) {
            existingError.remove();
        }

        // Disable button and show spinner
        button.disabled = true;
        spinner.style.display = "inline-block";
        button.innerHTML = "Connecting... <span id='spinner' class='spinner'></span>";

        let formData = new FormData();
        formData.append("action", "handle_woocommerce_keys");

        fetch(ajaxurl, {
            method: "POST",
            body: formData,
        })
        .then(response => response.json())
        .then(data => {
            // Hide spinner and re-enable button
            spinner.style.display = "none";
            button.innerHTML = "Connect WooCommerce with Plugin";
            button.disabled = false;

            if (data.success) {
                document.getElementById("consumer_key").value = data.consumer_key;
                document.getElementById("consumer_secret").value = data.consumer_secret;
                document.getElementById("woocommerce_keys_section").style.display = "block";
            } else {
                showErrorBeforeButton(data?.data?.message);
            }
        })
        .catch(error => {
            spinner.style.display = "none";
            button.innerHTML = "Connect WooCommerce with Plugin";
            button.disabled = false;
            console.error("AJAX Error:", error);
            showErrorBeforeButton("An error occurred. Please try again.");
        });
    });

    function showErrorBeforeButton(message) {
        let errorDiv = document.createElement("div");
        errorDiv.id = "error_message";
        errorDiv.style.color = "red";
        errorDiv.style.marginBottom = "10px";
        errorDiv.textContent = "Error: " + message;

        let button = document.getElementById("sync_woocommerce");
        button.parentNode.insertBefore(errorDiv, button);
    }

    </script>

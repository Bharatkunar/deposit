<?php include(plugin_dir_path(__FILE__) . '../commons/header.php'); ?>
<div class="wrap">
    <!-- Tabs Navigation -->
    <nav class="nav-tab-wrapper">
        <a href="#enabled-games" class="nav-tab nav-tab-active">Games Enabled on Web</a>
        <a href="#active-games" class="nav-tab">Games Currently Being Played</a>
    </nav>

    <!-- Active Games Section -->
    <div id="enabled-games" class="tab-content" style="display: block;">
        <h2>Active Games</h2>
        <?php if (!empty($enabled)) : ?>
            <table class="table table-striped table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>Game</th>
                        <th>Game Sessions</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($enabled as $com) : ?>
                        <tr>
                            <td><?php echo esc_html($com['gameName']); ?></td>
                            <td><a href="?page=game-activity&view=sessions&game_id=<?php echo $com['gameUuid']  ?>">view sessions</a></td>
                            <td><?php echo esc_html($com['transactionTime']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p>No active games found.</p>
        <?php endif; ?>
        <?php include(plugin_dir_path(__FILE__) . '../commons/pagination.php'); ?>

    </div>

    <!-- Completed Games Section -->
    <div id="active-games" class="tab-content" style="display: none;">
        <h2>Games Currently Being Played</h2>
        <?php if (!empty($started)) : ?>
            <table class="table table-striped table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>Game</th>
                        <th>Language</th>
                        <th>Date</th>
                        <th>session</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($started as $st) : ?>
                        <tr>
                            <td><?php echo esc_html($st['gameName']); ?></td>
                            <td><?php echo esc_html($st['gameLanguage']); ?></td>
                            <td><?php echo esc_html($st['transactionTime']); ?></td>
                            <td><a href="?page=game-activity&view=sessions&game_id=<?php echo $com['gameUuid']  ?>">view sessions</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p>No completed games found.</p>
        <?php endif; ?>
    </div>


    <div id="completed-games" class="tab-content" style="display: none;">
        <h2>Completed Games</h2>
        <?php if (!empty($completed)) : ?>
            <table class="table table-striped table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Game</th>
                        <th>Status</th>
                        <th>Language</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($completed as $st) : ?>
                        <tr>
                            <td><?php echo esc_html($st->id); ?></td>
                            <td><?php echo esc_html($st->name); ?></td>
                            <td><?php echo esc_html($st->enabled); ?></td>
                            <td><?php echo esc_html($st->language); ?></td>
                            <td><?php echo esc_html($st->created_at); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p>No completed games found.</p>
        <?php endif; ?>
    </div>


</div>

<?php include(plugin_dir_path(__FILE__) . '../commons/header.php'); ?>

<div class="wrap">
    <!-- Tabs Navigation -->
  
    <!-- Active Games Section -->
    <div id="enabled-games" class="tab-content" style="display: block;">
        <h2>Active Games</h2>
        <?php if (!empty($transactions)) : ?>
            <table class="table table-striped table-bordered">
                <thead class="thead-dark">
                    <tr>
                        
                        <th>bet amount</th>
                        <th>win amount</th>
                        <th>net amount</th>
                        <th>currency</th>
                        <th>Player Name</th>
                        <th>Round ID</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($transactions as $com) : 
                        ?>
                        <tr>
                            <td><?php echo esc_html($com['betAmount']); ?></td>
                            <td><?php echo esc_html($com['winAmount']); ?></td>
                            <td><?php echo esc_html($com['netAmount']); ?></td>
                            <td><?php echo esc_html($com['currency']); ?></td>
                            <td><?php echo esc_html($com['fullName']); ?></td>
                            <td><?php echo esc_html($com['roundId']); ?></td>
                            <td><?php echo esc_html($com['transactionTime']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p>No active games found.</p>
        <?php endif; ?>
    </div>

</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const tabs = document.querySelectorAll('.nav-tab');
        const contents = document.querySelectorAll('.tab-content');

        tabs.forEach(tab => {
            tab.addEventListener('click', function (e) {
                e.preventDefault();
                // Remove active class from all tabs and hide all content
                tabs.forEach(t => t.classList.remove('nav-tab-active'));
                contents.forEach(content => content.style.display = 'none');

                // Add active class to clicked tab and show the corresponding content
                this.classList.add('nav-tab-active');
                // const target = document.querySelector(this.getAttribute('href'));
                // target.style.display = 'block';
            });
        });
    });
</script>

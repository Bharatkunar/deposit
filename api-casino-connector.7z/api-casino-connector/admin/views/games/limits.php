<?php include(plugin_dir_path(__FILE__) . '../commons/header.php'); ?>

<div class="wrap">

    <?php if (!empty($limits)) : ?>
        <table class="table table-striped table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>Amount</th>
                    <th>Currency</th>
                    <th>Providers</th> <!-- Fixed width for Providers column -->
                </tr>
            </thead>
            <tbody>
                <?php foreach ($limits as $game) : ?>
                    <tr>
                        <td><?php echo esc_html($game['amount']); ?></td>
                        <td><?php echo esc_html($game['currency']); ?></td>
                        <td  style="max-width: 250px !important; overflow:scroll"><?php echo esc_html(implode('.', $game['providers'])); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else : ?>
        <p>No games found.</p>
    <?php endif; ?>

</div>

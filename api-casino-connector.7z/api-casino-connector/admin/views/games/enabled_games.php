<?php include(plugin_dir_path(__FILE__) . '../commons/header.php'); ?>

<div class="wrap">
    <div class="wrap">
        <?php if (!empty($games['items'])) : ?>
            <table class="table table-striped table-bordered">
                <thead class="thead-dark">
                        <th>uuid</th>
                        <th>name</th>
                        <th>type</th>
                        <th>provider</th>
                        <th>technology</th>
                        <th>lobby</th>
                        <th>Mobile</th>
                        <th>Free Spins</th>
                        <th>label</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($games['items'] as $game) : ?>
                        <tr>
                            <td><?php echo esc_html($game['uuid']); ?></td>
                            <td><?php echo esc_html($game['name']); ?></td>
                            <td><?php echo esc_html($game['type']); ?></td>
                            <td><?php echo esc_html($game['provider']); ?></td>
                            <td><?php echo esc_html($game['technology']); ?></td>
                            <td><?php echo esc_html($game['has_lobby']); ?></td>
                            <td><?php echo esc_html($game['is_mobile']); ?></td>
                            <td><?php echo esc_html($game['has_freespins']); ?></td>
                            <td><?php echo esc_html($game['has_tables']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div class="pagination">
                <?php if (isset($games['_links']['prev'])) : ?>
                    <a href="?page=games&currentPage=<?php echo $games['_meta']['currentPage'] - 1; ?>" class="button">Prev</a>
                <?php endif; ?>
                <span>Page <?php echo $games['_meta']['currentPage']; ?> of <?php echo $games['_meta']['pageCount']; ?></span>
                <?php if (isset($games['_links']['next'])) : ?>
                    <a href="?page=games&currentPage=<?php echo $games['_meta']['currentPage'] + 1; ?>" class="button">Next</a>
                <?php endif; ?>
            </div>
        <?php else : ?>
            <p>No games found.</p>
        <?php endif; ?>
    </div>
</div>

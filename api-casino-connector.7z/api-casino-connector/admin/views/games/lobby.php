<?php include(plugin_dir_path(__FILE__) . '../commons/header.php'); ?>

<div class="wrap">
    <hr class="wp-header-end">
    <?php if (!empty($lobby)) : ?>
        <table class="table table-striped table-bordered">
            <thead class="thead-dark">
                    <th>Name</th>
                    <th>Dealer Name</th>
                    <th>Open Time</th>
                    <th>Close Time</th>
                    <th>Technology</th>
                    <th>Created At</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($lobby as $game) : ?>
                    <tr>
                        <td><?php echo esc_html($game->name); ?></td>
                        <td><?php echo esc_html($game->dealerName); ?></td>
                        <td><?php echo esc_html($game->openTime); ?></td>
                        <td><?php echo esc_html($game->closeTime); ?></td>
                        <td><?php echo esc_html($game->technology); ?></td>
                        <td><?php echo esc_html($game->created_at); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else : ?>
        <div class="notice notice-warning">
            <p>No lobby found.</p>
        </div>
    <?php endif; ?>
</div>

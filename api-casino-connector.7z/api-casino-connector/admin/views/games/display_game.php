
<?php include(plugin_dir_path(__FILE__) . '../commons/header.php'); ?>
<div class="wrap">

    <!-- Button to Create New Shortcode -->
    <a href="admin.php?page=game-setup&view=short_code" class="button button-primary" style="margin-bottom: 20px;">Create New Shortcode</a>

    <!-- Table to Display Existing Shortcodes -->
    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th scope="col" style="width:40%">Shortcode</th>
                <th scope="col" >Title</th>
                <th scope="col">Games</th>
                <th scope="col">rows</th>
                <th scope="col">columns</th>
                <th scope="col">edit</th>
                <th scope="col">delete</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Fetch and display existing shortcodes
            if (!empty($codes)) :
                foreach ($codes as $code) :
                ?>
                    <tr>
                        <td><?php echo esc_html($code->shortcode); ?></td>
                        <td><?php echo esc_html($code->shortcode_title); ?></td>
                        <td><?php echo esc_html($code->total_records); ?></td>
                        <td><?php echo esc_html($code->num_of_rows); ?></td>
                        <td><?php echo esc_html($code->num_of_columns); ?></td>
                        <td><a href="?page=game-setup&view=edit_code&edit_id=<?php echo $code->id; ?>">edit</a></td>
                        <td><a href="?page=game-setup&view=delete&delete_id=<?php echo $code->id; ?>">delete</a></td>
                    </tr>
            <?php
                endforeach;
            else :
            ?>
                <tr>
                    <td colspan="5">No shortcodes found. Create a new one to get started!</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>



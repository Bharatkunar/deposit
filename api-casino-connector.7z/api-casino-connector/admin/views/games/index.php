
<?php include(plugin_dir_path(__FILE__) . '../commons/header.php'); ?>

<div class="wrap">

    <!-- Filter Form -->
    <form method="GET" action="<?php echo admin_url('admin.php'); ?>" class="mb-4">
        <input type="hidden" name="page" value="games" />
        <input type="hidden" name="action" value="game_filter_form" />

        <!-- Add current page to form -->
        <input type="hidden" name="currentPage" value="<?php echo isset($_GET['currentPage']) ? $_GET['currentPage'] : 1; ?>" />

        <div class="row">
            <div class="col-md-3">
                <label for="type" class="form-label">Type:</label>
                <select name="type" id="type" class="form-select">
                    <option value="All">All</option>
                    <?php foreach ($type as $t): ?>
                        <option value="<?php echo $t->id; ?>" <?php echo isset($_GET['type']) && $_GET['type'] == $t->id ? 'selected' : ''; ?>>
                            <?php echo $t->name; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-3">
                <label for="provider" class="form-label">Provider:</label>
                <select name="provider" id="provider" class="form-select">
                    <option value="">All</option>
                    <?php foreach ($provider as $p): ?>
                        <option value="<?php echo $p->id; ?>" <?php echo isset($_GET['provider']) && $_GET['provider'] == $p->id ? 'selected' : ''; ?>>
                            <?php echo $p->name; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-3">
                <label for="technology" class="form-label">Technology:</label>
                <select name="technology" id="technology" class="form-select">
                    <option value="">All</option>
                    <?php foreach ($technology as $tec): ?>
                        <option value="<?php echo $tec->id; ?>" <?php echo isset($_GET['technology']) && $_GET['technology'] == $tec->id ? 'selected' : ''; ?>>
                            <?php echo $tec->name; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-3">
                <label for="enabled" class="form-label">Active/Deactive:</label>
                <select name="enabled" id="enabled" class="form-select">
                    <option value="All">All</option>
                    <option value="1" <?php echo isset($_GET['enabled']) && $_GET['enabled'] === '1' ? 'selected' : ''; ?>>Active</option>
                    <option value="0" <?php echo isset($_GET['enabled']) && $_GET['enabled'] === '0' ? 'selected' : ''; ?>>Deactive</option>
                </select>
            </div>
        </div>

        <div class="mt-3 d-flex align-items-center">
            <button type="submit" class="btn btn-primary me-3">Filter</button>
            <span class="text-muted"><?php echo $current_total; ?> of <?php echo $total_records; ?></span>
        </div>
    </form>

    <!-- Game Table -->
    <?php if (!empty($games)) : ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <div class="d-flex mb-3">
                <button type="button" id="select-all" class="btn btn-secondary me-2">Select All</button>
                <button type="submit" name="activate" value="1" class="btn btn-success me-2">Activate Selected</button>
                <button type="submit" name="deactivate" value="0" class="btn btn-danger">Deactivate Selected</button>
            </div>

            <table class="table table-striped table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>Select</th>
                        <th>Status</th>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Provider</th>
                        <th>Technology</th>
                        <th>Lobby</th>
                        <th>Mobile</th>
                        <th>Free Spins</th>
                        <th>Label</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($games as $game) : ?>
                        <tr>
                            <td>
                            <input type="checkbox" class="game-checkbox" name="selected_games[]" value="<?php echo esc_attr($game->uuid); ?>">
                            </td>
                            <td><?php echo esc_html($game->enabled) == 1 ? 'active' : 'deactive'; ?></td>
                            <td><?php echo esc_html($game->name); ?></td>
                            <td><?php echo esc_html($game->type_name); ?></td>
                            <td><?php echo esc_html($game->provider_name); ?></td>
                            <td><?php echo esc_html($game->technology_name); ?></td>
                            <td><?php echo $game->has_lobby?"<a href='?page=games&currentPage&lobby=$game->id' >View Lobby</a>":esc_html($game->has_lobby);  ?></td>
                            <td><?php echo esc_html($game->is_mobile); ?></td>
                            <td><?php echo esc_html($game->has_freespins); ?></td>
                            <td><?php echo esc_html($game->has_tables); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php wp_nonce_field('update_enabled_status_nonce', 'enabled_status_nonce'); ?>
            <input type="hidden" name="action" value="update_enabled_status">
        </form>

        <?php include(plugin_dir_path(__FILE__) . '../commons/pagination.php'); ?>


        <!-- Pagination -->
        <!-- Add your pagination logic here -->
    <?php else : ?>
        <p class="alert alert-warning mt-3">No games found for the selected filters.</p>
    <?php endif; ?>
</div>


<?php include(plugin_dir_path(__FILE__) . '../commons/header.php'); ?>
<div class="wrap">
<a href="admin.php?page=game-setup&view=short_code" class="button button-primary" style="margin-bottom: 20px;">Create New Shortcode</a>

    <!-- Tabs Navigation -->
    <nav class="nav-tab-wrapper">
        <a href="#custom-shortcodes"   class="nav-tab nav-tab-active">Custom Shortcodes</a>
        <a href="#casino-shortcodes"   class="nav-tab">Casino Shortcodes</a>
        <a href="#loyalty-shortcodes" class="nav-tab">Loyalty Shortcodes</a>
    </nav>

    <!-- Active Games Section -->
    <div id="custom-shortcodes" class="tab-content" style="display: block;">
        <h2>Custom Shortcodes</h2>
        <table class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th scope="col" style="width:40%">Shortcode</th>
                <th scope="col">Title</th>
                <th scope="col">Games</th>
                <th scope="col">rows</th>
                <th scope="col">columns</th>
                <th scope="col">edit</th>
                <th scope="col">delete</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Fetch and display existing shortcodes
            if (!empty($codes)) :
                foreach ($codes as $code) :
                ?>
                    <tr>
                        <td><?php echo esc_html($code->shortcode); ?></td>
                        <td><?php echo esc_html($code->shortcode_title); ?></td>
                        <td><?php echo esc_html($code->total_records); ?></td>
                        <td><?php echo esc_html($code->num_of_rows); ?></td>
                        <td><?php echo esc_html($code->num_of_columns); ?></td>
                        <td><a href="?page=game-setup&view=edit_code&edit_id=<?php echo $code->id; ?>">edit</a></td>
                        <td><a href="?page=game-setup&view=delete&delete_id=<?php echo $code->id; ?>">delete</a></td>
                    </tr>
            <?php
                endforeach;
            else :
            ?>
                <tr>
                    <td colspan="5">No shortcodes found. Create a new one to get started!</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
        <?php include(plugin_dir_path(__FILE__) . '../commons/pagination.php'); ?>

    </div>

    <!-- Completed Games Section -->
    <div id="casino-shortcodes" class="tab-content" style="display: none;">
        <h2>Casino Shortcodes</h2>
        <table class="table table-striped table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>Shortcode</th>
                    <th>Description</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Get all registered shortcodes
                

                if (!empty($shortcodes)) {
                    foreach ($shortcodes as $shortcode => $details) {
                        echo '<tr>';
                        echo '<td>[' . esc_html($shortcode) . ']</td>';
                        echo '<td>' . (isset($details['description']) ? esc_html($details['description']) : 'No description available') . '</td>';
                        echo '</tr>';
                    }
                } else {
                    echo '<tr><td colspan="2">No shortcodes found.</td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
    <div id="loyalty-shortcodes" class="tab-content" style="display: none;">
        <h2>Loyalty Shortcodes</h2>
        <?php if (!empty($loyaltyCodes)) : ?>
            <table class="table table-striped table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>Shortcode</th>
                        <th>Description</th>
                        <th>Active</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        if (!empty($loyaltyCodes)) {
                            foreach ($loyaltyCodes as $shortcode => $details) {
                                echo '<tr>';
                                echo '<td>[' . esc_html($shortcode) . ']</td>';
                                echo '<td>' . (isset($details['description']) ? esc_html($details['description']) : 'No description available') . '</td>';
                                echo '</tr>';
                            }
                        } else {
                            echo '<tr><td colspan="2">No shortcodes found.</td></tr>';
                        }
                    ?>
                </tbody>
            </table>
        <?php else : ?>
            <p>No completed games found.</p>
        <?php endif; ?>
    </div>


</div>

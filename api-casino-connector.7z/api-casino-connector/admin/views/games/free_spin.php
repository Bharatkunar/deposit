<?php include(plugin_dir_path(__FILE__) . '../commons/header.php'); ?>

    <div class="wrap">

    <?php if (!empty($freeSpins)) : ?>
        <table class="table table-striped table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>amount</th>
                    <th>currency</th>
                    <th colspan='5'>Providers<th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($freeSpins as $game) : ?>
                    <tr>
                        <td><?php echo esc_html($game['amount']); ?></td>
                        <td><?php echo esc_html($game['currency']); ?></td>
                        <td colspan='5' style='width:100%'><?php echo esc_html(implode(',',$game['providers'])); ?></td>
             
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
       
    <?php else : ?>
        <p>No Free Spins</p>
    <?php endif; ?>
</div>


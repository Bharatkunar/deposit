<?php include(plugin_dir_path(__FILE__) . '../commons/header.php'); ?>

<div class="wrap">

    <!-- Form to Create a New Shortcode -->
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="casino_store_short_code" />
        <?php wp_nonce_field('casino_store_short_code_nonce', 'casino_store_short_code_nonce_field'); ?>

        <table class="form-table">
            <!-- Select Game Type -->
            <tr valign="top">
                <th scope="row"><label for="game_type">Select Game Type</label></th>
                <td>
                    <?php foreach ($type as $t): ?>
                        <label>
                            <input 
                                type="checkbox" 
                                name="type[]" 
                                value="<?php echo $t->id; ?>" 
                                <?php echo isset($_GET['type']) && in_array($t->id, (array) $_GET['type']) ? 'checked' : ''; ?>
                            >
                            <?php echo $t->name; ?>
                        </label><br>
                    <?php endforeach; ?>
                </td>
            </tr>

            <!-- Select Game Technology -->
            <tr valign="top">
                <th scope="row"><label for="game_technology">Select Game Technology</label></th>
                <td>
                    <?php foreach ($technology as $t): ?>
                        <label>
                            <input 
                                type="checkbox" 
                                name="technology[]" 
                                value="<?php echo $t->id; ?>" 
                                <?php echo isset($_GET['technology']) && in_array($t->id, (array) $_GET['technology']) ? 'checked' : ''; ?>
                            >
                            <?php echo $t->name; ?>
                        </label><br>
                    <?php endforeach; ?>
                </td>
            </tr>

            <!-- Select Game Provider -->
            <tr valign="top">
                <th scope="row"><label for="game_provider">Select Game Provider</label></th>
                <td>
                    <?php foreach ($provider as $p): ?>
                        <label>
                            <input 
                                type="checkbox" 
                                name="provider[]" 
                                value="<?php echo $p->id; ?>" 
                                <?php echo isset($_GET['provider']) && in_array($p->id, (array) $_GET['provider']) ? 'checked' : ''; ?>
                            >
                            <?php echo $p->name; ?>
                        </label><br>
                    <?php endforeach; ?>
                </td>
            </tr>

            <tr valign="top">
                <th scope="row"><label>Total Active Games Available:</label></th>
                <td>
                    <input type="text" id="total_games" value="<?php echo $current_total; ?>" readonly class="form-control">
                </td>
            </tr>

            <!-- Total Records -->
            <tr valign="top">
                <th scope="row"><label for="total_records">Total Records</label></th>
                <td>
                    <input type="number" id="total_records" name="total_records" min="1" value="<?php echo $singleShortCode[0]->total_records; ?>" required />
                    <p class="description">Total number of records to display.</p>
                </td>
            </tr>

            <!-- Rows -->
            <tr valign="top">
                <th scope="row"><label for="rows">Rows</label></th>
                <td>
                    <input type="number" id="rows" name="num_of_rows" min="1" max="10" value="<?php echo $singleShortCode[0]->num_of_rows; ?>" onchange="adjustColumns()" required />
                    <p class="description">Number of rows. Columns will be adjusted automatically.</p>
                </td>
            </tr>

            <!-- Columns -->
            <tr valign="top">
                <th scope="row"><label for="columns">Columns</label></th>
                <td>
                    <input type="number" id="columns" name="num_of_columns" readonly value="<?php echo $singleShortCode[0]->num_of_columns; ?>" />
                    <p class="description">Columns calculated based on total records and rows.</p>
                </td>
            </tr>

            <!-- Slider Option -->
            <tr valign="top">
                <th scope="row"><label for="slider_option">Slider Option</label></th>
                <td>
                    <label>
                        <input type="radio" id="slider_yes" name="use_slider" value="yes" /> Yes
                    </label>
                    <label>
                        <input type="radio" id="slider_no" name="use_slider" value="no" checked /> No
                    </label>
                    <div id="slider_type_options" style="display: none; margin-top: 10px;">
                        <label>
                            <input type="radio" id="slider_type_auto" name="slider_type" value="1" checked /> Auto
                        </label>
                        <label>
                            <input type="radio" id="slider_type_manual" name="slider_type" value="0" /> Manual
                        </label>
                        <p class="description">Choose the slider type: Auto for automatic scrolling or Manual for user control.</p>
                    </div>
                </td>
            </tr>

        </table>

        <!-- Save Shortcode Button -->
        <?php submit_button('Save Shortcode'); ?>
    </form>
</div>


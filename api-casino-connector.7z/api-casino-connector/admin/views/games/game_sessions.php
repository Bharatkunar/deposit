<?php include(plugin_dir_path(__FILE__) . '../commons/header.php'); ?>
<div class="wrap">
    <h1>Game Sessions</h1>
    <!-- Tabs Navigation -->
  
    <!-- Active Games Section -->
    <div id="enabled-games" class="tab-content" style="display: block;">
        <form method="GET" action="" class="row mb-4">
                <input type="hidden" name="page" value="game-activity">
                
                <div class="col-md-4">
                    <label for="date_from" class="form-label">Date From:</label>
                    <input type="date" name="date_from" id="date_from" class="form-control" value="<?php echo isset($_GET['date_from']) ? esc_attr($_GET['date_from']) : ''; ?>">
                </div>

                <div class="col-md-4">
                    <label for="date_to" class="form-label">Date To:</label>
                    <input type="date" name="date_to" id="date_to" class="form-control" value="<?php echo isset($_GET['date_to']) ? esc_attr($_GET['date_to']) : ''; ?>">
                </div>

                <div class="col-md-4 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">Search</button>
                </div>
            </form>
            <?php if (!empty($sessions)) : ?>
            <table class="table table-striped table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>Game</th>
                        <th>Player Name</th>
                        <th>Session</th>
                        <th>Game Activity</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($sessions as $com) : 

                 
                        ?>
                        <tr>
                            <td><?php echo esc_html($com['gameName']); ?></td>
                            <td><?php echo esc_html($com['fullName']); ?></td>
                            <td><?php echo esc_html($com['sessionId']); ?></td>
                            <td><a href="?page=game-activity&view=transaction_logs&game_id=<?php echo $com['gameUuid'] ;?>&session_id=<?php echo $com['sessionId']  ?>">view logs</a></td>
                            <td><?php echo esc_html($com['transactionTime']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p>No active games found.</p>
        <?php endif; ?>
    </div>

</div>

<!-- <script>
    document.addEventListener('DOMContentLoaded', function () {
        const tabs = document.querySelectorAll('.nav-tab');
        const contents = document.querySelectorAll('.tab-content');

        tabs.forEach(tab => {
            tab.addEventListener('click', function (e) {
                e.preventDefault();
                // Remove active class from all tabs and hide all content
                tabs.forEach(t => t.classList.remove('nav-tab-active'));
                contents.forEach(content => content.style.display = 'none');

                // Add active class to clicked tab and show the corresponding content
                this.classList.add('nav-tab-active');
                // const target = document.querySelector(this.getAttribute('href'));
                // target.style.display = 'block';
            });
        });
    });
</script> -->

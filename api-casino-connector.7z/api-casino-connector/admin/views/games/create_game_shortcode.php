<?php include(plugin_dir_path(__FILE__) . '../commons/header.php'); ?>
<div class="wrap">
    <!-- Form to Create a New Shortcode -->
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="casino_store_short_code" />
        <?php wp_nonce_field('casino_store_short_code_nonce', 'casino_store_short_code_nonce_field'); ?>
        
        <table class="form-table">
            <tr valign="top">
                <th scope="row"><label>Game Title:</label></th>
                <td>
                    <input type="text" id="shortcode_title" name="shortcode_title" class="form-control">
                </td>
            </tr>
            <tr valign="top">
                <th scope="row"><label for="slider_option">Show Title</label></th>
                <td>
                    <label>
                        <input type="radio" name="show_title" value='1' /> Yes
                    </label>
                    <label>
                        <input type="radio" name="show_title" value="0" checked /> No
                    </label>
                </td>
            </tr>
               
            <tr valign="top">
                <th scope="row"><label>Select Mode</label></th>
                <td>
                    <select name="active" class='form-control'>
                        <option value='1'>Online</option>
                        <option value='0'>Offline</option>    
                    </select>
                </td>
            </tr>   
            <!-- Select Game Type -->
            <tr valign="top">
                <th scope="row"><label for="game_type">Select Game Type</label></th>
                <td>
                    <?php foreach ($type as $t): ?>
                        <label>
                            <input 
                                type="checkbox" 
                                name="type[]"
                                    
                                value="<?php echo  $t->id; ?>" 
                                <?php echo isset($_GET['type']) && in_array($t->id, (array) $_GET['type']) ? 'checked' : ''; ?>
                            >
                            <?php echo ucfirst($t->name); ?>
                        </label><br>
                    <?php endforeach; ?>
                </td>
            </tr>

            <!-- Select Game Technology -->
            <tr valign="top">
                <th scope="row"><label for="game_technology">Select Game Technology</label></th>
                <td>
                    <?php foreach ($technology as $t): ?>
                        <label>
                            <input 
                                type="checkbox" 
                                name="technology[]" 
                                value="<?php echo $t->id; ?>" 
                                <?php echo isset($_GET['technology']) && in_array($t->id, (array) $_GET['technology']) ? 'checked' : ''; ?>
                            >
                            <?php echo $t->name; ?>
                        </label><br>
                    <?php endforeach; ?>
                </td>
            </tr>

            <!-- Select Game Provider -->
            <tr valign="top">
                <th scope="row"><label for="game_provider">Select Game Provider</label></th>
                <td>
                    <?php foreach ($provider as $p): ?>
                        <label>
                            <input 
                                type="checkbox" 
                                name="provider[]" 
                                value="<?php echo $p->id; ?>" 
                                <?php echo isset($_GET['provider']) && in_array($p->id, (array) $_GET['provider']) ? 'checked' : ''; ?>
                            >
                            <?php echo $p->name; ?>
                        </label><br>
                    <?php endforeach; ?>
                </td>
            </tr>

            <tr valign="top">
                <th scope="row"><label for="total_records">Total Records</label></th>
                <td>
                    <input type="number" id="total_records" name="total_records" min="1" 
                        value="<?php echo $active; ?>" required />
                    <p class="description">Total number of records to display.</p>
                </td>
            </tr>


            <!-- Total Records
            <tr valign="top">
            <th scope="row"><label for="total_records">Total Records</label></th>
                <td>
                    <input type="number" id="total_records" name="total_records" min="1" value="50" required />
                    <p class="description">Total number of records to display.</p>
                </td>
            </tr> -->

            <!-- Rows -->
            <tr valign="top">
                <th scope="row"><label for="rows">Rows</label></th>
                <td>
                    <input type="number" id="rows" name="num_of_rows" min="1" max="10" value="1" onchange="adjustColumns()" required />
                    <p class="description">Number of rows. Columns will be adjusted automatically.</p>
                    <p id="warning-text" style="color: red; display: none;">*7 columns are required to use the slider feature.</p>
                </td>
            </tr>

            <!-- Columns -->
            <tr valign="top">
                <th scope="row"><label for="columns">Columns</label></th>
                <td>
                    <input type="number" id="columns" name="num_of_columns" readonly value="50" />
                    <p class="description">Columns calculated based on total records and rows.</p>
                    <p></p>
                </td>
            </tr>

            <!-- Slider Option -->
            <tr valign="top">
                <th scope="row"><label for="slider_option">Slider Option</label></th>
                <td>
                    <label>
                        <input type="radio" id="slider_yes" name="use_slider" value="yes" /> Yes
                    </label>
                    <label>
                        <input type="radio" id="slider_no" name="use_slider" value="no" checked /> No
                    </label>
                    <div id="slider_type_options" style="display: none; margin-top: 10px;">
                        <label>
                            <input type="radio" id="slider_type_auto" name="slider_type" value="1" checked /> Auto
                        </label>
                        <label>
                            <input type="radio" id="slider_type_manual" name="slider_type" value="0" /> Manual
                        </label>
                        <p class="description">Choose the slider type: Auto for automatic scrolling or Manual for user control.</p>
                    </div>
                </td>
            </tr>

        </table>

        <!-- Save Shortcode Button -->
        <?php submit_button('Save Shortcode'); ?>
    </form>
</div>
<script>
    let activeGames = <?php echo json_encode($active); ?>;
    let inactiveGames = <?php echo json_encode($inactive); ?>;
</script>


<?php include(plugin_dir_path(__FILE__) . '../commons/header.php'); ?>
<div class="container mt-4">
    <form method="POST" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="bg-light p-4 rounded shadow-sm">
        <?php wp_nonce_field('casino_login_nonce', 'casino_add_balance_nonce_field'); ?>
        <input type="hidden" name="action" value="casino_add_balance_nonce_field">
        <input type="hidden" name="customer_id" value="<?php echo $_REQUEST['customer_id'];  ?>">
        
        <?php if (isset($_GET['message']) && !empty($_GET['message'])): ?>
            <div class="alert <?= $_GET['status'] === 'error' ? 'alert-danger' : 'alert-success'; ?>" role="alert">
                <?= htmlspecialchars($_GET['message']); ?>
            </div>
        <?php endif; ?>
        
        <div class="mb-3">
            <label for="currentBalance" class="form-label">Last Balance</label>
            <input type="number" id="currentBalance" name="current_balance" value="<?php echo $_REQUEST['currentBalance'] ? $_REQUEST['currentBalance'] : 0; ?>" readonly class="form-control">
        </div>
        
        <div class="mb-3">
            <label for="balance" class="form-label">New Balance</label>
            <input type="number" name="balance_to_add" id="balance" required class="form-control">
        </div>
        
        <button type="submit" class="btn btn-primary">Add Balance</button>
    </form>
</div>

<?php include(plugin_dir_path(__FILE__) . '../commons/header.php'); ?>
<div class="wrap">
    <?php if (!empty($game_users)) : ?>
        <table class="table table-striped table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>id</th>
                    <th>customer name</th>
                    <th>email</th>
                    <th>balance</th>
                    <th>Game History</th>
                    <th>Transaction</th>
                    <th>Balance</th>
                    <th>created at</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($game_users as $user) : 
                        
                    ?>
                    <tr>
                        <td><?php echo esc_html($user->ID); ?></td>
                        <td><?php echo esc_html($user->user_nicename); ?></td>
                        <td><?php echo esc_html($user->user_email); ?></td>
                        <td><?php echo esc_html($user->customer_balance); ?></td>
                        <td><a href="?page=customers&view=game_history&customer_id=<?php echo $user->ID ?>">view history</a></td>
                        <td><a href="?page=customers&view=transaction&customer_id=<?php echo $user->ID ?>">view transaction</a></td>
                        <td><a href="?page=customers&view=balance&customer_id=<?php echo $user->ID ?>&currentBalance=<?php echo $user->customer_balance ?>">Add Balance</a></td>

                        <td><?php echo esc_html($user->user_registered); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else : ?>
        <p>No games found.</p>
    <?php endif; ?>

    </div>
<?php include(plugin_dir_path(__FILE__) . '../commons/header.php'); ?>
<div class="wrap">
    <?php if (!empty($customers)) : ?>
        <table class="table table-striped table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>id</th>
                    <th>Game</th>
                    <th>status</th>
                    <th>language</th>
                    <th>date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($customers as $user) : 
                        
                    ?>
                    <tr>
                        <td><?php echo esc_html($user->id); ?></td>
                        <td><?php echo esc_html($user->name); ?></td>
                        <td><?php echo esc_html($user->status); ?></td>
                        <td><?php echo esc_html($user->language); ?></td>
                        <td><?php echo esc_html($user->created_at); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else : ?>
        <p>No games found.</p>
    <?php endif; ?>
</div>

<?php include(plugin_dir_path(__FILE__) . '../commons/header.php'); ?>

<div class="wrap">
    <?php if (!empty($customers)) : ?>
        <table class="table table-striped table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>id</th>
                    <th>last balance</th>
                    <th>current balance</th>
                    <th>type</th>
                    <th>created at</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($customers as $user) : 
                        
                    ?>
                    <tr>
                        <td><?php echo esc_html($user->id); ?></td>
                        <td><?php echo esc_html($user->last_balance); ?></td>
                        <td><?php echo esc_html($user->current_balance); ?></td>
                        <td><?php echo esc_html($user->type); ?></td>
                        <td><?php echo esc_html($user->created_at); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else : ?>
        <p>No games found.</p>
    <?php endif; ?>
</div>

